"""
XSHEILD Real-Time Filesystem Watcher (Hardened Edition)
Owner: Future Finger Technologies
Surveillance using Windows ReadDirectoryChangesW kernel notifications via watchdog.
Bounded threadpool execution, on_moved event handling, and file-lock retry backoff.

IMPORTANT ARCHITECTURAL NOTE ON REAL-TIME PROTECTION BOUNDARIES:
This module operates in user-mode (Ring 3) via the Win32 ReadDirectoryChangesW API.
It detects files immediately upon creation, modification, or renaming in monitored ingress directories
(Downloads, Desktop, Temp), but CANNOT intercept file execution before the Windows NT kernel loader maps it.
True pre-execution blocking requires a Windows File System Minifilter Driver (FLTMGR.sys) operating
at altitude 320000-329999, requiring the Windows Driver Kit (WDK) and Microsoft WHQL attestation signing.
"""

import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, List, Callable, Dict, Set
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

from src.core.scanner import AntivirusScanner
from src.core.quarantine import QuarantineManager
from src.core.models import DetectionResult, ThreatSeverity
from src.core.exclusions import exclusion_manager


class ThreatDetectedEvent:
    """Encapsulates a real-time detection event."""
    def __init__(self, result: DetectionResult, action_taken: str):
        self.result = result
        self.action_taken = action_taken
        self.timestamp = result.timestamp


class RealtimeFileHandler(FileSystemEventHandler):
    """
    Handles filesystem creation, modification, and rename events with debouncing,
    bounded thread execution, and file-lock retry backoff.
    """

    def __init__(
        self,
        scanner: AntivirusScanner,
        quarantine_mgr: Optional[QuarantineManager] = None,
        auto_quarantine: bool = True,
        on_threat_callback: Optional[Callable[[ThreatDetectedEvent], None]] = None,
        executor: Optional[ThreadPoolExecutor] = None
    ):
        super().__init__()
        self.scanner = scanner
        self.quarantine_mgr = quarantine_mgr
        self.auto_quarantine = auto_quarantine
        self.on_threat_callback = on_threat_callback
        self.executor = executor or ThreadPoolExecutor(max_workers=4, thread_name_prefix="XSheildRTWorker")
        self._debounce_window_sec = 0.2
        self._recent_events: Dict[str, float] = {}
        self._lock = threading.Lock()

    def _should_process(self, path: str) -> bool:
        now = time.time()
        abs_p = os.path.abspath(path).lower()

        # Ignore temporary partial download files and vault artifacts
        if abs_p.endswith((".crdownload", ".part", ".tmp", ".xquar")):
            return False

        # Exclusions Allowlist Check
        if exclusion_manager.is_path_excluded(path):
            return False

        with self._lock:
            last_time = self._recent_events.get(abs_p, 0.0)
            if now - last_time < self._debounce_window_sec:
                return False
            self._recent_events[abs_p] = now
            if len(self._recent_events) > 5000:
                self._recent_events = {
                    k: v for k, v in self._recent_events.items() if now - v < 10.0
                }
            return True

    def _handle_path(self, path: str):
        if not os.path.isfile(path):
            return

        # Retry loop for file lock backoff and multi-stage writes (e.g. create -> write bytes)
        max_retries = 5
        result = None
        for attempt in range(max_retries):
            try:
                time.sleep(0.06 * (attempt + 1))
                if not os.path.isfile(path):
                    return
                # If file is empty, pause slightly as writer may still be flushing payload
                if os.path.getsize(path) == 0 and attempt < 3:
                    continue
                result = self.scanner.scan_file(path, use_cache=False)
                if result and result.is_threat:
                    break
            except PermissionError:
                if attempt == max_retries - 1:
                    return
            except Exception:
                return

        if not result or not result.is_threat:
            # Check for ransomware extensions or rapid mass encryption behavior
            try:
                from src.core.ransomware_shield import ransomware_shield
                rw_incident = ransomware_shield.evaluate_file_write(path)
                if rw_incident:
                    from src.core.models import DetectionResult, ThreatSeverity, DetectionCategory
                    result = DetectionResult(
                        file_path=path,
                        is_threat=True,
                        detection_name=f"Ransomware.{rw_incident.threat_category}",
                        severity=ThreatSeverity.CRITICAL,
                        category=DetectionCategory.RANSOMWARE,
                        detection_source="RansomwareShield.Behavioral"
                    )
            except Exception:
                pass

        if not result or not result.is_threat:
            return

        action = "ALERTED"
        if self.auto_quarantine and self.quarantine_mgr:
            try:
                self.quarantine_mgr.quarantine_file(path, result)
                action = "QUARANTINED"
            except Exception as q_err:
                action = f"QUARANTINE_FAILED: {q_err}"

        event = ThreatDetectedEvent(result, action_taken=action)
        if self.on_threat_callback:
            self.on_threat_callback(event)

        # Trigger native Windows Action Center Toast Notification
        try:
            from src.core.notifications import notification_service
            notification_service.show_threat_alert(
                filename=path,
                threat_name=result.threat_name or "Malicious Payload",
                action=action
            )
        except Exception:
            pass

        # Trigger futuristic non-intrusive cyber audio cue
        try:
            from src.core.audio import sound_engine
            sound_engine.play_threat_intercepted()
        except Exception:
            pass

    def _safe_submit(self, path: str):
        try:
            self.executor.submit(self._handle_path, path)
        except RuntimeError:
            pass

    def on_created(self, event: FileSystemEvent):
        if not event.is_directory and self._should_process(event.src_path):
            self._safe_submit(event.src_path)

    def on_modified(self, event: FileSystemEvent):
        if not event.is_directory and self._should_process(event.src_path):
            self._safe_submit(event.src_path)

    def on_moved(self, event: FileSystemEvent):
        """Catches file renames and moves into monitored directories."""
        dest_p = getattr(event, "dest_path", None)
        if dest_p and not event.is_directory and self._should_process(dest_p):
            self._safe_submit(dest_p)


class RealtimeProtectionEngine:
    """Orchestrates filesystem surveillance across configured directories."""

    def __init__(
        self,
        scanner: Optional[AntivirusScanner] = None,
        quarantine_mgr: Optional[QuarantineManager] = None,
        auto_quarantine: bool = True
    ):
        self.scanner = scanner or AntivirusScanner()
        self.quarantine_mgr = quarantine_mgr or QuarantineManager()
        self.auto_quarantine = auto_quarantine
        self._observer: Optional[Observer] = None
        self._executor: Optional[ThreadPoolExecutor] = None
        self._monitored_paths: Set[str] = set()
        self._threat_history: List[ThreatDetectedEvent] = []
        self._is_running = False
        self._lock = threading.Lock()
        self.callbacks: List[Callable[[ThreatDetectedEvent], None]] = []

    def register_threat_listener(self, callback: Callable[[ThreatDetectedEvent], None]) -> None:
        self.callbacks.append(callback)

    def _on_threat_dispatched(self, event: ThreatDetectedEvent) -> None:
        with self._lock:
            self._threat_history.append(event)
        for cb in self.callbacks:
            try:
                cb(event)
            except Exception:
                pass

    def start_protection(self, paths: Optional[List[str]] = None) -> None:
        """Starts real-time monitoring across specified paths or standard ingress points."""
        with self._lock:
            if self._is_running:
                return

            if not paths:
                user_home = os.path.expanduser("~")
                paths = [
                    os.path.join(user_home, "Downloads"),
                    os.path.join(user_home, "Desktop"),
                    os.environ.get("TEMP", os.path.join(user_home, "AppData", "Local", "Temp"))
                ]

            self._executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="XSheildRTWorker")
            self._observer = Observer()
            handler = RealtimeFileHandler(
                scanner=self.scanner,
                quarantine_mgr=self.quarantine_mgr,
                auto_quarantine=self.auto_quarantine,
                on_threat_callback=self._on_threat_dispatched,
                executor=self._executor
            )

            for p in paths:
                if os.path.exists(p) and os.path.isdir(p):
                    self._observer.schedule(handler, p, recursive=True)
                    self._monitored_paths.add(p)

            self._observer.start()
            self._is_running = True

    def stop_protection(self) -> None:
        """Stops active background watcher and shuts down worker pool."""
        with self._lock:
            if not self._is_running or not self._observer:
                return
            self._observer.stop()
            self._observer.join(timeout=2.0)
            self._observer = None

            if self._executor:
                self._executor.shutdown(wait=False)
                self._executor = None

            self._is_running = False
            self._monitored_paths.clear()

    @property
    def is_active(self) -> bool:
        return self._is_running

    @property
    def monitored_paths(self) -> List[str]:
        return list(self._monitored_paths)

    @property
    def threat_history(self) -> List[ThreatDetectedEvent]:
        with self._lock:
            return list(self._threat_history)
