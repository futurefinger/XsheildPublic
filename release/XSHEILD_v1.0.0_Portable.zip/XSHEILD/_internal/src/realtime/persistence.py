"""
XSHEILD Startup & Persistence Surveillance
Owner: Future Finger Technologies
Audits Windows Run/RunOnce registry keys and Startup folders for unauthorized persistence or hijacked binaries.
"""

import os
import re
import shlex
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field

from src.core.scanner import AntivirusScanner
from src.core.models import DetectionResult, ThreatSeverity

try:
    import winreg
    WINREG_AVAILABLE = True
except ImportError:
    WINREG_AVAILABLE = False


@dataclass
class PersistenceEntry:
    location: str
    entry_name: str
    raw_command: str
    target_executable: Optional[str] = None
    exists_on_disk: bool = False
    is_suspicious: bool = False
    reasons: List[str] = field(default_factory=list)
    scan_result: Optional[DetectionResult] = None


def extract_executable_path(raw_command: str) -> Optional[str]:
    """Extracts candidate executable path from raw command line string."""
    if not raw_command:
        return None

    cleaned = raw_command.strip()

    # If wrapped in quotes, extract inside quotes
    if cleaned.startswith('"'):
        end_idx = cleaned.find('"', 1)
        if end_idx != -1:
            return cleaned[1:end_idx]

    # If .exe is present, try finding .exe boundary
    lower = cleaned.lower()
    if ".exe" in lower:
        idx = lower.find(".exe") + 4
        candidate = cleaned[:idx]
        # Check if candidate exists on disk
        if os.path.isfile(os.path.expandvars(candidate)):
            return candidate

    # Otherwise take first token
    tokens = cleaned.split()
    if tokens:
        return tokens[0]

    return None


class PersistenceAuditor:
    """Scans and evaluates autorun persistence mechanisms."""

    def __init__(self, scanner: Optional[AntivirusScanner] = None):
        self.scanner = scanner or AntivirusScanner()

    def audit_all(self) -> List[PersistenceEntry]:
        """Performs full audit of registry run keys and Startup directories."""
        entries: List[PersistenceEntry] = []

        if WINREG_AVAILABLE:
            entries.extend(self._audit_registry_key(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                "HKCU_Run"
            ))
            entries.extend(self._audit_registry_key(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
                "HKCU_RunOnce"
            ))
            entries.extend(self._audit_registry_key(
                winreg.HKEY_LOCAL_MACHINE,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                "HKLM_Run"
            ))
            entries.extend(self._audit_registry_key(
                winreg.HKEY_LOCAL_MACHINE,
                r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
                "HKLM_RunOnce"
            ))

        # Startup Folder Audit
        appdata = os.environ.get("APPDATA")
        if appdata:
            startup_dir = os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup")
            entries.extend(self._audit_startup_folder(startup_dir))

        return entries

    def _audit_registry_key(self, root_key, subkey_path: str, location_tag: str) -> List[PersistenceEntry]:
        entries: List[PersistenceEntry] = []
        try:
            with winreg.OpenKey(root_key, subkey_path, 0, winreg.KEY_READ) as key:
                num_values = winreg.QueryInfoKey(key)[1]
                for i in range(num_values):
                    name, val, _ = winreg.EnumValue(key, i)
                    entry = self._evaluate_entry(location_tag, name, str(val))
                    entries.append(entry)
        except (OSError, PermissionError):
            pass
        return entries

    def _audit_startup_folder(self, folder_path: str) -> List[PersistenceEntry]:
        entries: List[PersistenceEntry] = []
        if not os.path.isdir(folder_path):
            return entries

        try:
            for item in os.listdir(folder_path):
                full_p = os.path.join(folder_path, item)
                if item.lower() == "desktop.ini":
                    continue
                entry = self._evaluate_entry("Startup_Folder", item, full_p)
                entries.append(entry)
        except Exception:
            pass
        return entries

    def _evaluate_entry(self, location: str, name: str, raw_command: str) -> PersistenceEntry:
        target_exe = extract_executable_path(raw_command)
        exists = False
        reasons: List[str] = []
        is_suspicious = False
        scan_res = None

        if target_exe:
            # Expand environment variables (%USERPROFILE%, %TEMP%, etc.)
            expanded = os.path.expandvars(target_exe)
            if os.path.isfile(expanded):
                exists = True
                target_exe = expanded
                # Fast scanner check: only scan if cached or small file (< 5MB) to keep UI ultra-responsive
                try:
                    fsize = os.path.getsize(expanded)
                    if fsize < 5 * 1024 * 1024:
                        scan_res = self.scanner.scan_file(expanded, use_cache=True)
                        if scan_res.is_threat:
                            # Exclude legitimate vendor binaries located in Program Files flagged solely by PE anomaly heuristics
                            is_heuristic_pe = scan_res.detection_name.startswith("Heuristic.PE.")
                            is_in_program_files = "program files" in expanded.lower()
                            known_apps = {"firefox.exe", "chrome.exe", "msedge.exe", "brave.exe", "opera.exe", "onedrive.exe"}
                            exe_base = os.path.basename(expanded).lower()
                            if is_heuristic_pe and is_in_program_files and exe_base in known_apps:
                                pass
                            else:
                                is_suspicious = True
                                reasons.append(f"Threat detected by scanner: {scan_res.detection_name} ({scan_res.severity.value})")
                except Exception:
                    pass

                # Check if running from temp or download directories
                norm_lower = expanded.lower()
                if "temp" in norm_lower or "downloads" in norm_lower:
                    is_suspicious = True
                    reasons.append("Binary resides in temporary/downloads directory")

            else:
                reasons.append("Referenced executable target does not exist on disk")

        # Check for unquoted spaces in command line
        if raw_command and " " in raw_command and not raw_command.startswith('"'):
            # Only flag if path has space before .exe
            exe_part = raw_command.split(".exe")[0] if ".exe" in raw_command.lower() else ""
            if " " in exe_part:
                reasons.append("Unquoted path vulnerability: command contains spaces without surrounding quotes")

        return PersistenceEntry(
            location=location,
            entry_name=name,
            raw_command=raw_command,
            target_executable=target_exe,
            exists_on_disk=exists,
            is_suspicious=is_suspicious,
            reasons=reasons,
            scan_result=scan_res
        )
