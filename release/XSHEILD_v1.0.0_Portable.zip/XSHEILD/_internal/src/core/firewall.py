"""
XSHEILD Advanced Firewall & Network Protection Engine
Owner: Future Finger Technologies
Monitors inbound/outbound connections, blocks malicious C2 IPs via Windows Firewall,
audits hosts file for DNS hijack attempts, and manages custom security rules.
"""

import os
import sys
import re
import json
import time
import math
import ctypes
import socket
import logging
import subprocess
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from src.core.logger import get_logger

logger = get_logger("core.firewall")

DEFAULT_FIREWALL_RULES_PATH = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "firewall_rules.json"
)

DEFAULT_NETWORK_LOG_PATH = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "network_events.json"
)

# Curated C2 / Botnet IP threat definitions (known adversary infrastructure)
KNOWN_MALICIOUS_IPS: Set[str] = {
    "185.220.101.5", "194.26.29.112", "45.154.255.88", "91.240.118.172",
    "193.106.191.162", "45.146.165.37", "185.196.220.34", "195.123.245.24",
    "89.208.103.241", "179.43.175.51", "104.244.76.13", "198.54.117.200",
    "185.143.223.12", "194.135.25.179", "185.244.25.211", "91.92.247.93",
    "195.133.40.71", "45.140.146.166", "176.113.115.149", "193.233.20.29",
    "82.115.223.11", "194.87.68.210", "45.130.83.155", "185.161.248.88"
}

# Suspicious outbound port targets commonly abused by malware/RATs
SUSPICIOUS_OUTBOUND_PORTS: Set[int] = {
    4444, 5555, 6666, 6667, 1337, 31337, 8888, 9999, 7777, 8443, 2222
}


@dataclass
class NetworkConnection:
    protocol: str
    local_address: str
    local_port: int
    remote_address: str
    remote_port: int
    state: str
    pid: int
    process_name: str
    is_suspicious: bool
    suspicious_reason: Optional[str]


@dataclass
class NetworkEvent:
    event_id: str
    timestamp: str
    event_type: str
    remote_ip: str
    remote_port: int
    pid: Optional[int]
    process_name: Optional[str]
    action_taken: str
    details: str


class AdvancedFirewallManager:
    """
    Manages active connection surveillance, Windows Firewall rule enforcement,
    and DNS hosts-file tamper protection.
    """

    def __init__(
        self,
        rules_path: Optional[str] = None,
        log_path: Optional[str] = None
    ):
        self.rules_path = rules_path or DEFAULT_FIREWALL_RULES_PATH
        self.log_path = log_path or DEFAULT_NETWORK_LOG_PATH
        self.is_active = True
        self._custom_blocked_ips: Set[str] = set()
        self._custom_allowed_ips: Set[str] = set()
        self._ensure_storage_exists()
        self._load_rules()

    def _ensure_storage_exists(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.rules_path), exist_ok=True)
            if not os.path.exists(self.rules_path):
                self._save_rules({"blocked_ips": [], "allowed_ips": []})
            if not os.path.exists(self.log_path):
                self._save_log([])
        except Exception:
            pass

    def _load_rules(self) -> None:
        try:
            with open(self.rules_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._custom_blocked_ips = set(data.get("blocked_ips", []))
                self._custom_allowed_ips = set(data.get("allowed_ips", []))
        except Exception:
            self._custom_blocked_ips = set()
            self._custom_allowed_ips = set()

    def _save_rules(self, data: Dict[str, Any]) -> None:
        temp_p = self.rules_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        import shutil
        for attempt in range(5):
            try:
                os.replace(temp_p, self.rules_path)
                return
            except (PermissionError, OSError):
                if attempt == 4:
                    try:
                        shutil.copyfile(temp_p, self.rules_path)
                        try:
                            os.remove(temp_p)
                        except OSError:
                            pass
                        return
                    except Exception:
                        pass
                time.sleep(0.05 * (attempt + 1))

    def _load_log(self) -> List[Dict[str, Any]]:
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_log(self, events: List[Dict[str, Any]]) -> None:
        temp_p = self.log_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(events, f, indent=2)
        import shutil
        for attempt in range(5):
            try:
                os.replace(temp_p, self.log_path)
                return
            except (PermissionError, OSError):
                if attempt == 4:
                    try:
                        shutil.copyfile(temp_p, self.log_path)
                        try:
                            os.remove(temp_p)
                        except OSError:
                            pass
                        return
                    except Exception:
                        pass
                time.sleep(0.05 * (attempt + 1))

    def log_network_event(self, event: NetworkEvent) -> None:
        events = self._load_log()
        events.insert(0, asdict(event))
        if len(events) > 500:
            events = events[:500]
        self._save_log(events)
        logger.info(f"FIREWALL EVENT: [{event.event_type}] {event.remote_ip}:{event.remote_port} - {event.action_taken}")

    def get_network_events(self) -> List[Dict[str, Any]]:
        return self._load_log()

    def get_active_connections(self) -> List[NetworkConnection]:
        """
        Enumerates live TCP connections using native Windows netstat without requiring third-party libraries.
        Identifies remote IP, local/remote ports, PID, and evaluates against threat definitions.
        """
        connections: List[NetworkConnection] = []
        try:
            cmd = ["netstat", "-ano", "-p", "tcp"]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0

            output = subprocess.check_output(cmd, startupinfo=startupinfo, text=True, stderr=subprocess.DEVNULL)
            for line in output.splitlines():
                parts = line.strip().split()
                if len(parts) >= 5 and parts[0].upper() == "TCP":
                    local = parts[1]
                    remote = parts[2]
                    state = parts[3]
                    pid_str = parts[4]

                    try:
                        pid = int(pid_str)
                    except ValueError:
                        continue

                    # Parse IP and port
                    remote_ip = remote.rsplit(":", 1)[0].strip("[]")
                    try:
                        remote_port = int(remote.rsplit(":", 1)[1])
                    except (IndexError, ValueError):
                        remote_port = 0

                    local_ip = local.rsplit(":", 1)[0].strip("[]")
                    try:
                        local_port = int(local.rsplit(":", 1)[1])
                    except (IndexError, ValueError):
                        local_port = 0

                    # Evaluate suspicious traits
                    is_suspicious = False
                    reason = None

                    if remote_ip in KNOWN_MALICIOUS_IPS or remote_ip in self._custom_blocked_ips:
                        is_suspicious = True
                        reason = f"Remote IP {remote_ip} is flagged as Malicious C2 / Botnet Infrastructure"
                    elif remote_port in SUSPICIOUS_OUTBOUND_PORTS and remote_ip not in ("0.0.0.0", "127.0.0.1", "*"):
                        is_suspicious = True
                        reason = f"Outbound connection to suspicious non-standard port {remote_port}"

                    conn = NetworkConnection(
                        protocol="TCP",
                        local_address=local_ip,
                        local_port=local_port,
                        remote_address=remote_ip,
                        remote_port=remote_port,
                        state=state,
                        pid=pid,
                        process_name=f"PID_{pid}",
                        is_suspicious=is_suspicious,
                        suspicious_reason=reason
                    )
                    connections.append(conn)
        except Exception as e:
            logger.debug(f"Error enumerating active connections: {e}")

        return connections

    def audit_hosts_file(self) -> Dict[str, Any]:
        r"""
        Audits the Windows hosts file (C:\Windows\System32\drivers\etc\hosts)
        for malicious DNS redirection or attempts to block security update endpoints.
        """
        hosts_path = os.path.join(
            os.environ.get("WINDIR", "C:\\Windows"),
            "System32", "drivers", "etc", "hosts"
        )
        if not os.path.exists(hosts_path):
            return {"status": "CLEAN", "hosts_exists": False, "suspicious_entries": []}

        PROTECTED_SECURITY_DOMAINS = {
            "microsoft.com", "windowsupdate.com", "update.microsoft.com",
            "futurefingertechnologies.com", "github.com", "razorpay.com"
        }

        suspicious = []
        try:
            with open(hosts_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        ip = parts[0]
                        domain = parts[1].lower()
                        # Detect loopback redirection of legitimate security domains
                        if ip in ("127.0.0.1", "0.0.0.0"):
                            for sec_dom in PROTECTED_SECURITY_DOMAINS:
                                if sec_dom in domain:
                                    suspicious.append({
                                        "ip": ip,
                                        "domain": domain,
                                        "reason": f"Security domain '{domain}' hijacked to loopback address {ip}"
                                    })
        except Exception as err:
            return {"status": "ERROR", "error": str(err), "suspicious_entries": []}

        status = "HIJACK_DETECTED" if suspicious else "CLEAN"
        return {
            "status": status,
            "hosts_exists": True,
            "hosts_path": hosts_path,
            "suspicious_entries": suspicious
        }

    def block_ip(self, ip_address: str, reason: str = "User/Threat blocked") -> bool:
        """Adds IP to custom blocklist and enforces via Windows Advanced Firewall rule."""
        # Validate IPv4 format
        try:
            socket.inet_aton(ip_address)
        except socket.error:
            logger.warning(f"Invalid IP address format: {ip_address}")
            return False

        self._custom_blocked_ips.add(ip_address)
        self._save_rules({
            "blocked_ips": sorted(list(self._custom_blocked_ips)),
            "allowed_ips": sorted(list(self._custom_allowed_ips))
        })

        # Add Windows Advanced Firewall rule via netsh
        rule_name = f"XSHEILD_BLOCK_{ip_address.replace('.', '_')}"
        try:
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}", "dir=out", "action=block",
                f"remoteip={ip_address}"
            ]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            subprocess.run(cmd, startupinfo=startupinfo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            logger.debug(f"Could not apply netsh rule: {e}")

        # Log event
        import uuid
        self.log_network_event(NetworkEvent(
            event_id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc).isoformat(),
            event_type="IP_BLOCKED",
            remote_ip=ip_address,
            remote_port=0,
            pid=None,
            process_name=None,
            action_taken="BLOCKED",
            details=reason
        ))
        return True

    def unblock_ip(self, ip_address: str) -> bool:
        """Removes IP from custom blocklist and purges Windows Firewall rule."""
        if ip_address in self._custom_blocked_ips:
            self._custom_blocked_ips.remove(ip_address)
            self._save_rules({
                "blocked_ips": sorted(list(self._custom_blocked_ips)),
                "allowed_ips": sorted(list(self._custom_allowed_ips))
            })

        rule_name = f"XSHEILD_BLOCK_{ip_address.replace('.', '_')}"
        try:
            cmd = ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule_name}"]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            subprocess.run(cmd, startupinfo=startupinfo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        return True

    def detect_dns_tunneling(self, domain_or_query: str) -> Tuple[bool, Optional[str]]:
        """
        Detects DNS covert channel data exfiltration and tunneling (e.g. iodine, dnscat2, Cobalt Strike DNS beacons).
        Analyzes label length, Shannon entropy, and nested subdomain levels.
        """
        clean_q = domain_or_query.strip().lower().rstrip(".")
        if not clean_q:
            return False, None

        labels = clean_q.split(".")
        if len(labels) < 2:
            return False, None

        subdomain_part = ".".join(labels[:-2]) if len(labels) > 2 else labels[0]
        full_sub_len = len(subdomain_part)

        # 1. Abnormal label length (DNS tunneling payloads typically exceed 45 chars per label)
        for label in labels[:-2]:
            if len(label) > 48:
                return True, f"Abnormal DNS label length ({len(label)} bytes) characteristic of payload encapsulation"

        # 2. Total subdomain length check
        if full_sub_len > 90:
            return True, f"High-volume DNS query length ({full_sub_len} chars) indicative of data exfiltration"

        # 3. Shannon Entropy analysis on subdomains
        if full_sub_len >= 18:
            prob = [float(subdomain_part.count(c)) / full_sub_len for c in set(subdomain_part)]
            entropy = -sum(p * math.log2(p) for p in prob)
            # High entropy (>= 3.85) in long subdomains strongly indicates encrypted/base32/base64 tunneling
            if entropy >= 3.85:
                return True, f"High Shannon entropy ({entropy:.2f} bits/symbol) in DNS query '{subdomain_part[:30]}...'"

        # 4. Known DNS tunneling signature prefixes
        if any(subdomain_part.startswith(prefix) for prefix in ("dnscat.", "tunnel.", "c2.", "exfil.")):
            return True, f"Known tunneling prefix detected in DNS query: {subdomain_part}"

        return False, None

    def evaluate_port_scan_behavior(self, connections: Optional[List[NetworkConnection]] = None) -> List[Dict[str, Any]]:
        """
        Surveils active connection state tables to detect rapid port reconnaissance,
        lateral movement, or external port scanners probing host services.
        """
        conns = connections if connections is not None else self.get_active_connections()
        findings: List[Dict[str, Any]] = []

        # Group by remote IP and by local PID
        ip_to_ports: Dict[str, Set[int]] = {}
        pid_to_ports: Dict[int, Set[int]] = {}

        for c in conns:
            if c.remote_address not in ("0.0.0.0", "127.0.0.1", "*", "::1", ""):
                ip_to_ports.setdefault(c.remote_address, set()).add(c.remote_port)
            if c.pid > 4:
                pid_to_ports.setdefault(c.pid, set()).add(c.remote_port)

        # External IP hitting multiple destination ports
        for remote_ip, ports in ip_to_ports.items():
            if len(ports) >= 6:
                findings.append({
                    "threat_type": "PORT_SCAN_RECONNAISSANCE",
                    "source": remote_ip,
                    "target_ports_count": len(ports),
                    "ports_sample": sorted(list(ports))[:10],
                    "recommendation": f"Block IP {remote_ip} immediately via Windows Firewall"
                })

        # Local process scanning external network
        for pid, ports in pid_to_ports.items():
            if len(ports) >= 12:
                findings.append({
                    "threat_type": "LOCAL_PROCESS_OUTBOUND_SCANNER",
                    "pid": pid,
                    "target_ports_count": len(ports),
                    "ports_sample": sorted(list(ports))[:10],
                    "recommendation": f"Inspect process PID {pid} for worm or botnet lateral movement"
                })

        return findings

    def enable_panic_isolation(self) -> bool:
        """
        Emergency Host Isolation:
        Instantly halts all non-loopback inbound and outbound TCP/UDP network communication
        to neutralize active ransomware propagation, data exfiltration, or APT lateral movement.
        """
        logger.critical("ENABLING TOTAL HOST PANIC ISOLATION VIA WINDOWS ADVANCED FIREWALL")
        try:
            # Block all outbound except loopback
            cmd_out = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                "name=XSHEILD_PANIC_ISOLATION_OUT", "dir=out", "action=block",
                "remoteip=0.0.0.0-127.0.0.0,127.0.0.2-255.255.255.255"
            ]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            subprocess.run(cmd_out, startupinfo=startupinfo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception as e:
            logger.error(f"Failed enabling panic isolation: {e}")
            return False

    def disable_panic_isolation(self) -> bool:
        """Restores normal network operation after containment."""
        logger.info("Lifting host panic isolation")
        try:
            cmd = ["netsh", "advfirewall", "firewall", "delete", "rule", "name=XSHEILD_PANIC_ISOLATION_OUT"]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            subprocess.run(cmd, startupinfo=startupinfo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            return False

    def is_panic_isolated(self) -> bool:
        """Checks if emergency host isolation rule is currently active."""
        try:
            cmd = ["netsh", "advfirewall", "firewall", "show", "rule", "name=XSHEILD_PANIC_ISOLATION_OUT"]
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            res = subprocess.run(cmd, startupinfo=startupinfo, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            return "XSHEILD_PANIC_ISOLATION_OUT" in res.stdout
        except Exception:
            return False


# Global firewall instance
advanced_firewall = AdvancedFirewallManager()
