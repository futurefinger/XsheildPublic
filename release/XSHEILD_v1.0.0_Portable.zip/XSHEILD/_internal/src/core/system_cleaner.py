"""
XSHEILD Advanced System Cleaner Engine
Owner: Future Finger Technologies
High-performance, safe Windows system optimization module providing CCleaner-equivalent
disk cleanup across system temporary caches, browser data, dump archives, and redundant files.
Truthful reporting based on real Win32 filesystem metrics.
"""

import os
import glob
import shutil
import ctypes
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from src.core.logger import get_logger

logger = get_logger("core.cleaner")


# Win32 Recycle Bin Structs & Constants
class SHQUERYRBINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_ulong),
        ("i64Size", ctypes.c_longlong),
        ("i64NumItems", ctypes.c_longlong),
    ]


SHERB_NOCONFIRMATION = 0x00000001
SHERB_NOPROGRESSUI = 0x00000002
SHERB_NOSOUND = 0x00000004


def format_bytes(bytes_count: int) -> str:
    """Formats byte counts into human-readable truthful binary units."""
    if bytes_count < 0:
        bytes_count = 0
    if bytes_count < 1024:
        return f"{bytes_count} B"
    elif bytes_count < 1024 * 1024:
        return f"{bytes_count / 1024:.1f} KB"
    elif bytes_count < 1024 * 1024 * 1024:
        return f"{bytes_count / (1024 * 1024):.1f} MB"
    else:
        return f"{bytes_count / (1024 * 1024 * 1024):.2f} GB"


@dataclass
class CleanerCategoryMeta:
    category_id: str
    display_name: str
    description: str
    icon: str
    paths_or_targets: List[str] = field(default_factory=list)


class SystemCleaner:
    """
    Production-grade CCleaner alternative designed specifically for Windows environments.
    Analyzes and purges junk files without risking OS stability or user credentials.
    """

    def __init__(self):
        self.local_appdata = os.environ.get("LOCALAPPDATA", "")
        self.appdata = os.environ.get("APPDATA", "")
        self.temp_dir = os.environ.get("TEMP", "")
        self.system_root = os.environ.get("SystemRoot", "C:\\Windows")
        self.program_data = os.environ.get("ProgramData", "C:\\ProgramData")

    def get_supported_categories(self) -> Dict[str, CleanerCategoryMeta]:
        """Returns the dictionary of all cleaner categories and their scan targets."""
        categories: Dict[str, CleanerCategoryMeta] = {}

        # 1. Windows Temporary Files
        win_temp_paths = []
        if self.temp_dir and os.path.exists(self.temp_dir):
            win_temp_paths.append(self.temp_dir)
        sys_temp = os.path.join(self.system_root, "Temp")
        if os.path.exists(sys_temp):
            win_temp_paths.append(sys_temp)
        categories["windows_temp"] = CleanerCategoryMeta(
            category_id="windows_temp",
            display_name="Windows Temporary Files",
            description="Scratch files, orphaned setup temp files, and system cache",
            icon="fa-folder-open",
            paths_or_targets=win_temp_paths
        )

        # 2. Windows Recycle Bin
        categories["recycle_bin"] = CleanerCategoryMeta(
            category_id="recycle_bin",
            display_name="Recycle Bin",
            description="Deleted files awaiting permanent deletion from all local drives",
            icon="fa-trash-alt",
            paths_or_targets=["WIN32_RECYCLE_BIN"]
        )

        # 3. Web Browser Caches (Chrome, Edge, Firefox, Brave, Opera)
        browser_paths = []
        if self.local_appdata:
            # Google Chrome
            browser_paths.extend([
                os.path.join(self.local_appdata, "Google", "Chrome", "User Data", "Default", "Cache"),
                os.path.join(self.local_appdata, "Google", "Chrome", "User Data", "Default", "Code Cache"),
                os.path.join(self.local_appdata, "Google", "Chrome", "User Data", "Default", "GPUCache"),
            ])
            # Microsoft Edge
            browser_paths.extend([
                os.path.join(self.local_appdata, "Microsoft", "Edge", "User Data", "Default", "Cache"),
                os.path.join(self.local_appdata, "Microsoft", "Edge", "User Data", "Default", "Code Cache"),
                os.path.join(self.local_appdata, "Microsoft", "Edge", "User Data", "Default", "GPUCache"),
            ])
            # Brave
            browser_paths.extend([
                os.path.join(self.local_appdata, "BraveSoftware", "Brave-Browser", "User Data", "Default", "Cache"),
                os.path.join(self.local_appdata, "BraveSoftware", "Brave-Browser", "User Data", "Default", "Code Cache"),
            ])
            # Opera GX
            browser_paths.append(os.path.join(self.local_appdata, "Opera Software", "Opera GX Stable", "Cache"))

            # Firefox Cache (Pattern Match)
            ff_profiles = os.path.join(self.local_appdata, "Mozilla", "Firefox", "Profiles")
            if os.path.exists(ff_profiles):
                for prof in glob.glob(os.path.join(ff_profiles, "*")):
                    c2 = os.path.join(prof, "cache2")
                    if os.path.exists(c2):
                        browser_paths.append(c2)

        if self.appdata:
            browser_paths.append(os.path.join(self.appdata, "Opera Software", "Opera Stable", "Cache"))

        categories["browser_caches"] = CleanerCategoryMeta(
            category_id="browser_caches",
            display_name="Web Browser Caches",
            description="Temporary web media, cached scripts, and GPU cache (Chrome, Edge, Firefox, Brave)",
            icon="fa-globe",
            paths_or_targets=[p for p in browser_paths if os.path.exists(p)]
        )

        # 4. Crash Dumps & Windows Error Reports
        dump_paths = []
        if self.local_appdata:
            dump_paths.append(os.path.join(self.local_appdata, "CrashDumps"))
            dump_paths.append(os.path.join(self.local_appdata, "Microsoft", "Windows", "WER", "ReportArchive"))
            dump_paths.append(os.path.join(self.local_appdata, "Microsoft", "Windows", "WER", "ReportQueue"))
        if self.program_data:
            dump_paths.append(os.path.join(self.program_data, "Microsoft", "Windows", "WER", "ReportArchive"))
            dump_paths.append(os.path.join(self.program_data, "Microsoft", "Windows", "WER", "ReportQueue"))
        mini = os.path.join(self.system_root, "Minidump")
        if os.path.exists(mini):
            dump_paths.append(mini)

        categories["crash_dumps"] = CleanerCategoryMeta(
            category_id="crash_dumps",
            display_name="Crash Dumps & Diagnostics",
            description="Application crash memory dumps and queued Windows Error Reports",
            icon="fa-bug",
            paths_or_targets=[p for p in dump_paths if os.path.exists(p)]
        )

        # 5. Windows Update Cache
        wu_cache = os.path.join(self.system_root, "SoftwareDistribution", "Download")
        categories["windows_update"] = CleanerCategoryMeta(
            category_id="windows_update",
            display_name="Windows Update Delivery Cache",
            description="Downloaded packages for already applied Windows Updates",
            icon="fa-cloud-download-alt",
            paths_or_targets=[wu_cache] if os.path.exists(wu_cache) else []
        )

        # 6. Windows Thumbnail & Explorer Cache
        thumb_paths = []
        if self.local_appdata:
            thumb_dir = os.path.join(self.local_appdata, "Microsoft", "Windows", "Explorer")
            if os.path.exists(thumb_dir):
                thumb_paths.append(thumb_dir)
        categories["thumbnails_cache"] = CleanerCategoryMeta(
            category_id="thumbnails_cache",
            display_name="Thumbnail Cache",
            description="Windows Explorer cached image and video previews",
            icon="fa-images",
            paths_or_targets=thumb_paths
        )

        # 7. Application & Tool Junk Caches
        app_cache_paths = []
        if self.appdata:
            app_cache_paths.extend([
                os.path.join(self.appdata, "discord", "Cache"),
                os.path.join(self.appdata, "discord", "Code Cache"),
                os.path.join(self.appdata, "discord", "GPUCache"),
                os.path.join(self.appdata, "Code", "Cache"),
                os.path.join(self.appdata, "Code", "CachedData"),
                os.path.join(self.appdata, "npm-cache"),
            ])
        if self.local_appdata:
            app_cache_paths.extend([
                os.path.join(self.local_appdata, "Spotify", "Storage"),
                os.path.join(self.local_appdata, "pip", "cache"),
            ])
        categories["app_caches"] = CleanerCategoryMeta(
            category_id="app_caches",
            display_name="Application & Dev Caches",
            description="Caches from Discord, Spotify, VS Code, Pip, and NPM",
            icon="fa-cubes",
            paths_or_targets=[p for p in app_cache_paths if os.path.exists(p)]
        )

        # 8. System & Setup Logs
        log_paths = []
        if self.temp_dir and os.path.exists(self.temp_dir):
            log_paths.append(self.temp_dir)
        cbs_logs = os.path.join(self.system_root, "Logs", "CBS")
        if os.path.exists(cbs_logs):
            log_paths.append(cbs_logs)
        panther = os.path.join(self.system_root, "Panther")
        if os.path.exists(panther):
            log_paths.append(panther)

        categories["system_logs"] = CleanerCategoryMeta(
            category_id="system_logs",
            display_name="System & Setup Logs",
            description="Completed CBS servicing logs, installation journals, and debug outputs",
            icon="fa-file-alt",
            paths_or_targets=log_paths
        )

        return categories

    def _query_recycle_bin(self) -> Tuple[int, int]:
        """Queries Win32 shell for exact Recycle Bin size and item count."""
        try:
            rbinfo = SHQUERYRBINFO()
            rbinfo.cbSize = ctypes.sizeof(SHQUERYRBINFO)
            res = ctypes.windll.shell32.SHQueryRecycleBinW(None, ctypes.byref(rbinfo))
            if res == 0:
                return (int(rbinfo.i64Size), int(rbinfo.i64NumItems))
        except Exception as e:
            logger.debug(f"SHQueryRecycleBinW query error: {e}")
        return (0, 0)

    def _empty_recycle_bin(self) -> Tuple[int, int]:
        """Empties Win32 Recycle Bin silently without popups."""
        size, items = self._query_recycle_bin()
        if items == 0 and size == 0:
            return (0, 0)
        try:
            flags = SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
            res = ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, flags)
            if res == 0:
                return (size, items)
        except Exception as e:
            logger.warning(f"SHEmptyRecycleBinW error: {e}")
        return (0, 0)

    def _scan_directory(self, dir_path: str, filter_ext: Optional[List[str]] = None, max_depth: int = 4) -> Tuple[int, int]:
        """Calculates total bytes and file count in a directory safely."""
        total_bytes = 0
        total_files = 0

        if not os.path.exists(dir_path):
            return (0, 0)

        base_depth = dir_path.rstrip(os.sep).count(os.sep)

        try:
            for root, dirs, files in os.walk(dir_path, topdown=True):
                cur_depth = root.count(os.sep) - base_depth
                if cur_depth >= max_depth:
                    dirs[:] = []
                    continue

                for f in files:
                    if filter_ext:
                        ext = os.path.splitext(f)[1].lower()
                        if ext not in filter_ext:
                            continue
                    file_path = os.path.join(root, f)
                    try:
                        sz = os.path.getsize(file_path)
                        total_bytes += sz
                        total_files += 1
                    except (PermissionError, OSError):
                        pass
        except (PermissionError, OSError):
            pass

        return (total_bytes, total_files)

    def _clean_directory(self, dir_path: str, filter_ext: Optional[List[str]] = None) -> Tuple[int, int, int]:
        """Safely cleans files from a target directory, skipping locked/in-use files."""
        freed_bytes = 0
        freed_files = 0
        skipped = 0

        if not os.path.exists(dir_path):
            return (0, 0, 0)

        for root, dirs, files in os.walk(dir_path, topdown=False):
            for f in files:
                if filter_ext:
                    ext = os.path.splitext(f)[1].lower()
                    if ext not in filter_ext:
                        continue
                file_path = os.path.join(root, f)
                try:
                    sz = os.path.getsize(file_path)
                    os.chmod(file_path, 0o777)
                    os.remove(file_path)
                    freed_bytes += sz
                    freed_files += 1
                except (PermissionError, OSError):
                    skipped += 1

            for d in dirs:
                dir_to_remove = os.path.join(root, d)
                try:
                    os.rmdir(dir_to_remove)
                except (PermissionError, OSError):
                    pass

        return (freed_bytes, freed_files, skipped)

    def analyze(self) -> Dict[str, Any]:
        """
        Deep analysis across all categories.
        Returns exact byte sizes, counts, and category breakdowns.
        """
        categories_meta = self.get_supported_categories()
        results: Dict[str, Any] = {}
        total_all_bytes = 0
        total_all_files = 0

        for cat_id, meta in categories_meta.items():
            cat_bytes = 0
            cat_files = 0

            if cat_id == "recycle_bin":
                cat_bytes, cat_files = self._query_recycle_bin()
            elif cat_id == "system_logs":
                for p in meta.paths_or_targets:
                    b, cnt = self._scan_directory(p, filter_ext=[".log", ".dmp", ".etl", ".bak"])
                    cat_bytes += b
                    cat_files += cnt
            elif cat_id == "thumbnails_cache":
                for p in meta.paths_or_targets:
                    b, cnt = self._scan_directory(p, filter_ext=[".db"])
                    cat_bytes += b
                    cat_files += cnt
            else:
                for p in meta.paths_or_targets:
                    b, cnt = self._scan_directory(p)
                    cat_bytes += b
                    cat_files += cnt

            total_all_bytes += cat_bytes
            total_all_files += cat_files

            results[cat_id] = {
                "id": cat_id,
                "name": meta.display_name,
                "description": meta.description,
                "icon": meta.icon,
                "bytes": cat_bytes,
                "files": cat_files,
                "formatted": format_bytes(cat_bytes)
            }

        return {
            "success": True,
            "total_bytes": total_all_bytes,
            "total_files": total_all_files,
            "total_formatted": format_bytes(total_all_bytes),
            "categories": results
        }

    def clean(self, category_ids: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Executes safe cleaning on specified categories (or all if omitted).
        Returns exact metrics on freed space and cleaned files.
        """
        categories_meta = self.get_supported_categories()
        targets = category_ids if category_ids else list(categories_meta.keys())

        cleaned_total_bytes = 0
        cleaned_total_files = 0
        skipped_total = 0
        category_reports: Dict[str, Any] = {}

        for cat_id in targets:
            if cat_id not in categories_meta:
                continue

            meta = categories_meta[cat_id]
            cat_freed_bytes = 0
            cat_freed_files = 0
            cat_skipped = 0

            if cat_id == "recycle_bin":
                b, cnt = self._empty_recycle_bin()
                cat_freed_bytes = b
                cat_freed_files = cnt
            elif cat_id == "system_logs":
                for p in meta.paths_or_targets:
                    b, f, s = self._clean_directory(p, filter_ext=[".log", ".dmp", ".etl", ".bak"])
                    cat_freed_bytes += b
                    cat_freed_files += f
                    cat_skipped += s
            elif cat_id == "thumbnails_cache":
                for p in meta.paths_or_targets:
                    b, f, s = self._clean_directory(p, filter_ext=[".db"])
                    cat_freed_bytes += b
                    cat_freed_files += f
                    cat_skipped += s
            else:
                for p in meta.paths_or_targets:
                    b, f, s = self._clean_directory(p)
                    cat_freed_bytes += b
                    cat_freed_files += f
                    cat_skipped += s

            cleaned_total_bytes += cat_freed_bytes
            cleaned_total_files += cat_freed_files
            skipped_total += cat_skipped

            category_reports[cat_id] = {
                "name": meta.display_name,
                "bytes_freed": cat_freed_bytes,
                "files_freed": cat_freed_files,
                "skipped_files": cat_skipped,
                "formatted": format_bytes(cat_freed_bytes)
            }

        logger.info(f"SystemCleaner completed: freed {format_bytes(cleaned_total_bytes)} across {cleaned_total_files} files.")

        return {
            "success": True,
            "total_bytes_freed": cleaned_total_bytes,
            "total_files_freed": cleaned_total_files,
            "total_skipped": skipped_total,
            "total_formatted": format_bytes(cleaned_total_bytes),
            "categories": category_reports
        }


# Singleton export
system_cleaner = SystemCleaner()
