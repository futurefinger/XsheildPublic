"""
XSHEILD Windows Kernel Minifilter Communication Bridge
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, India
Official Destination: futurefingerindia@gmail.com

Interfaces between user-space XSHEILD engine and XShieldMinifilter.sys driver via FltLib.dll.
Provides seamless user-mode fallback when driver is not yet installed/loaded.
"""

import os
import sys
import ctypes
from ctypes import wintypes
import logging
from typing import Optional, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [KERNEL-BRIDGE] %(message)s")
logger = logging.getLogger("xsheild.kernel_bridge")

XSHIELD_PORT_NAME = "\\XShieldMinifilterPort"

# Command types matching XShieldMinifilter.h
CMD_SCAN_REQUEST = 0x00000001
CMD_BLOCK_OPERATION = 0x00000002
CMD_HEARTBEAT = 0x00000003
CMD_PROTECT_PID = 0x00000004


class XShieldCommandMessage(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("CommandType", wintypes.ULONG),
        ("ProcessId", wintypes.ULONG),
        ("FilePath", wintypes.WCHAR * 1024),
        ("DesiredAccess", wintypes.ULONG),
        ("Flags", wintypes.ULONG),
    ]


class XShieldReplyMessage(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("ActionVerdict", wintypes.ULONG),
        ("Status", wintypes.LONG),
    ]


class KernelMinifilterBridge:
    """Manages kernel driver communication channel and anti-tamper PID registration."""

    def __init__(self, port_name: str = XSHIELD_PORT_NAME):
        self.port_name = port_name
        self.port_handle = wintypes.HANDLE(0)
        self.is_connected = False
        self._fltlib = None
        self._load_fltlib()

    def _load_fltlib(self):
        try:
            self._fltlib = ctypes.windll.fltlib
        except Exception as e:
            logger.debug(f"fltlib.dll not available: {e}. Running in User-Mode Watchdog mode.")
            self._fltlib = None

    def connect(self) -> bool:
        """Attempts connection to XShieldMinifilter communication port."""
        if not self._fltlib:
            return False

        try:
            # HRESULT FilterConnectCommunicationPort(LPCWSTR lpPortName, DWORD dwOptions, LPCVOID lpContext, WORD wSizeOfContext, LPSECURITY_ATTRIBUTES lpSecurityAttributes, HANDLE *hPort)
            h_port = wintypes.HANDLE(0)
            hr = self._fltlib.FilterConnectCommunicationPort(
                wintypes.LPCWSTR(self.port_name),
                0,
                None,
                0,
                None,
                ctypes.byref(h_port)
            )
            if hr == 0:  # S_OK
                self.port_handle = h_port
                self.is_connected = True
                logger.info(f"Connected to XShieldMinifilter kernel port: {self.port_name}")
                self.register_protected_pid(os.getpid())
                return True
            else:
                logger.debug(f"Kernel driver port not active (HRESULT: 0x{hr & 0xFFFFFFFF:08X}). Falling back to Userland Watchdog.")
                return False
        except Exception as e:
            logger.debug(f"Error connecting to kernel port: {e}")
            return False

    def register_protected_pid(self, pid: int) -> bool:
        """Informs kernel driver to block unauthorized termination of the process."""
        if not self.is_connected or not self._fltlib:
            return False

        cmd = XShieldCommandMessage()
        cmd.CommandType = CMD_PROTECT_PID
        cmd.ProcessId = pid
        reply = XShieldReplyMessage()
        bytes_returned = wintypes.DWORD(0)

        try:
            # HRESULT FilterSendMessage(HANDLE hPort, LPVOID lpInBuffer, DWORD dwInBufferSize, LPVOID lpOutBuffer, DWORD dwOutBufferSize, LPDWORD lpBytesReturned)
            hr = self._fltlib.FilterSendMessage(
                self.port_handle,
                ctypes.byref(cmd),
                ctypes.sizeof(cmd),
                ctypes.byref(reply),
                ctypes.sizeof(reply),
                ctypes.byref(bytes_returned)
            )
            return hr == 0
        except Exception as e:
            logger.debug(f"FilterSendMessage error: {e}")
            return False

    def disconnect(self):
        """Closes the port connection."""
        if self.is_connected and self.port_handle:
            try:
                ctypes.windll.kernel32.CloseHandle(self.port_handle)
            except Exception:
                pass
            self.is_connected = False
            self.port_handle = wintypes.HANDLE(0)

    def get_status(self) -> Dict[str, Any]:
        return {
            "driver_connected": self.is_connected,
            "port_name": self.port_name,
            "mode": "KERNEL_MINIFILTER" if self.is_connected else "USERLAND_WATCHDOG_EMULATION",
            "active_protection_level": "RING_0_KERNEL" if self.is_connected else "RING_3_ELEVATED",
            "publisher": "Future Finger Technologies",
            "jurisdiction": "New Delhi, Delhi, India"
        }
