"""
XSHEILD Anti-Clipper & Financial Clipboard Shield
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
Official Contact: futurefingerindia@gmail.com

Features:
1. Real-time Crypto-Clipper Malware Defense:
   - Defends against silent address swap attacks (Laplas Clipper, CryptShuffler, RedLine Stealer).
   - Monitors Windows clipboard for unauthorized mutations of cryptocurrency addresses.
2. Comprehensive Blockchain Address Recognition:
   - Bitcoin (Legacy, SegWit, Bech32 native)
   - Ethereum & EVM Compatible (Polygon, Arbitrum, BSC, Optimism)
   - TRON & USDT TRC-20
   - Solana
   - Monero (XMR)
3. Financial Data & Credit Card Leakage Sentry:
   - Detects raw payment card numbers (Visa, Mastercard, Amex, RuPay) using Luhn check.
4. Auto-Quarantine & Reversion:
   - Preserves genuine copied wallet address and restores it if silent background overwrite occurs.
"""

import os
import sys
import re
import time
import ctypes
import threading
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict

from src.core.logger import get_logger

logger = get_logger("core.clipboard_shield")

# Cryptocurrency Address Regex Patterns
CRYPTO_PATTERNS = {
    "BITCOIN": re.compile(r"\b(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b"),
    "ETHEREUM": re.compile(r"\b(0x[a-fA-F0-9]{40})\b"),
    "USDT_TRON": re.compile(r"\b(T[a-zA-HJ-NP-Z0-9]{33})\b"),
    "SOLANA": re.compile(r"\b([1-9A-HJ-NP-Za-km-z]{32,44})\b"),
    "MONERO": re.compile(r"\b(4[0-9AB][1-9A-HJ-NP-Za-km-z]{93})\b"),
}

# Win32 64-bit API type bindings for safe memory handling
if sys.platform == "win32":
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.OpenClipboard.argtypes = [ctypes.c_void_p]
        user32.OpenClipboard.restype = ctypes.c_int
        user32.CloseClipboard.argtypes = []
        user32.CloseClipboard.restype = ctypes.c_int
        user32.GetClipboardData.argtypes = [ctypes.c_uint]
        user32.GetClipboardData.restype = ctypes.c_void_p
        user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
        user32.SetClipboardData.restype = ctypes.c_void_p
        user32.EmptyClipboard.argtypes = []
        user32.EmptyClipboard.restype = ctypes.c_int
        kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        kernel32.GlobalUnlock.restype = ctypes.c_int
        kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
        kernel32.GlobalAlloc.restype = ctypes.c_void_p
    except Exception:
        pass


def luhn_checksum_valid(card_number_str: str) -> bool:
    """Validates credit card checksum using Luhn algorithm."""
    digits = [int(c) for c in card_number_str if c.isdigit()]
    if len(digits) not in (15, 16):
        return False
    checksum = 0
    reverse_digits = digits[::-1]
    for i, d in enumerate(reverse_digits):
        if i % 2 == 1:
            doubled = d * 2
            checksum += doubled if doubled < 10 else doubled - 9
        else:
            checksum += d
    return (checksum % 10) == 0


@dataclass
class ClipboardAuditResult:
    contains_crypto_address: bool
    detected_crypto_type: Optional[str]
    matched_address_masked: Optional[str]
    contains_payment_card: bool
    is_suspicious_mutation: bool
    status_verdict: str  # "SAFE", "CRYPTO_PROTECTED", "SENSITIVE_FINANCIAL", "CLIPPER_ATTACK_DETECTED"
    details: str


class ClipboardShieldEngine:
    """
    Guards Windows clipboard from Clipper Trojans, banking stealers, and unauthorized modifications.
    """

    def __init__(self):
        self.is_active = True
        self._lock = threading.RLock()
        self._last_legit_address: Optional[str] = None
        self._last_address_type: Optional[str] = None
        self._last_copy_time: float = 0.0
        self._blocked_attacks_count: int = 0
        self._last_audit_result: Optional[ClipboardAuditResult] = None

    def read_windows_clipboard(self) -> Optional[str]:
        """Safely reads plain text from Windows clipboard via Win32 API without throwing exceptions."""
        if sys.platform != "win32":
            return None

        try:
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            if not user32.OpenClipboard(None):
                return None

            try:
                # CF_UNICODETEXT = 13
                h_data = user32.GetClipboardData(13)
                if not h_data:
                    return None

                p_data = kernel32.GlobalLock(h_data)
                if not p_data:
                    return None

                try:
                    text = ctypes.wstring_at(p_data)
                    return text
                finally:
                    kernel32.GlobalUnlock(h_data)
            finally:
                user32.CloseClipboard()
        except Exception:
            return None

    def write_windows_clipboard(self, text: str) -> bool:
        """Writes text back to Windows clipboard safely."""
        if sys.platform != "win32":
            return False

        try:
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            if not user32.OpenClipboard(None):
                return False

            try:
                user32.EmptyClipboard()
                # GMEM_MOVEABLE = 0x0002
                data_bytes = (text + "\0").encode("utf-16le")
                h_data = kernel32.GlobalAlloc(0x0002, len(data_bytes))
                if not h_data:
                    return False

                p_data = kernel32.GlobalLock(h_data)
                if not p_data:
                    return False

                try:
                    ctypes.memmove(p_data, data_bytes, len(data_bytes))
                finally:
                    kernel32.GlobalUnlock(h_data)

                # CF_UNICODETEXT = 13
                user32.SetClipboardData(13, h_data)
                return True
            finally:
                user32.CloseClipboard()
        except Exception:
            return False

    def classify_crypto_address(self, text: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Scans string for supported cryptocurrency addresses.
        Returns: (crypto_type, matched_address)
        """
        clean = text.strip()
        for crypto_name, pattern in CRYPTO_PATTERNS.items():
            match = pattern.search(clean)
            if match:
                addr = match.group(0)
                # Additional validation for Ethereum (length 42 with 0x)
                if crypto_name == "ETHEREUM" and len(addr) != 42:
                    continue
                # Additional validation for TRON (length 34 starts with T)
                if crypto_name == "USDT_TRON" and (len(addr) != 34 or not addr.startswith("T")):
                    continue
                return crypto_name, addr
        return None, None

    def audit_clipboard(self, sample_text: Optional[str] = None) -> ClipboardAuditResult:
        """
        Audits current clipboard text (or provided sample) for crypto addresses,
        financial card numbers, and rapid clipper mutation.
        """
        content = sample_text if sample_text is not None else self.read_windows_clipboard()
        if not content:
            result = ClipboardAuditResult(
                contains_crypto_address=False,
                detected_crypto_type=None,
                matched_address_masked=None,
                contains_payment_card=False,
                is_suspicious_mutation=False,
                status_verdict="SAFE",
                details="Clipboard empty or non-text."
            )
            self._last_audit_result = result
            return result

        now = time.time()
        crypto_type, matched_addr = self.classify_crypto_address(content)

        # Check for card numbers (16-digit card patterns)
        contains_card = False
        card_matches = re.findall(r"\b(?:\d{4}[ -]?){3}\d{4}\b", content)
        for cand in card_matches:
            cleaned_num = cand.replace(" ", "").replace("-", "")
            if luhn_checksum_valid(cleaned_num):
                contains_card = True
                break

        is_mutation = False
        verdict = "SAFE"
        details = "No sensitive or high-risk content detected."
        masked_addr = None

        if matched_addr:
            # Mask middle characters for privacy (e.g. 0x1234...abcd)
            if len(matched_addr) > 10:
                masked_addr = f"{matched_addr[:6]}...{matched_addr[-4:]}"
            else:
                masked_addr = matched_addr

            with self._lock:
                # If a crypto address was recorded recently (< 3.0s ago) and suddenly changed to a DIFFERENT address
                if (
                    self._last_legit_address
                    and self._last_address_type == crypto_type
                    and matched_addr != self._last_legit_address
                    and (now - self._last_copy_time) < 3.0
                ):
                    is_mutation = True
                    self._blocked_attacks_count += 1
                    verdict = "CLIPPER_ATTACK_DETECTED"
                    details = (
                        f"CRITICAL ALERT: Rapid {crypto_type} address swap detected! "
                        f"Original address was replaced within {round(now - self._last_copy_time, 2)}s. "
                        f"Potential Clipper malware active."
                    )
                    logger.warning(details)
                    # Automatically restore original legit address
                    if sample_text is None:
                        self.write_windows_clipboard(self._last_legit_address)
                else:
                    self._last_legit_address = matched_addr
                    self._last_address_type = crypto_type
                    self._last_copy_time = now
                    verdict = "CRYPTO_PROTECTED"
                    details = f"{crypto_type} wallet address recognized and protected from unauthorized hijacking."

        elif contains_card:
            verdict = "SENSITIVE_FINANCIAL"
            details = "Payment card number detected in clipboard. Protect against unauthorized memory sniffers."

        result = ClipboardAuditResult(
            contains_crypto_address=(crypto_type is not None),
            detected_crypto_type=crypto_type,
            matched_address_masked=masked_addr,
            contains_payment_card=contains_card,
            is_suspicious_mutation=is_mutation,
            status_verdict=verdict,
            details=details
        )

        self._last_audit_result = result
        return result

    def get_shield_status(self) -> Dict[str, Any]:
        """Returns live telemetry of Clipboard Guard status and blocked attacks."""
        latest = self._last_audit_result or self.audit_clipboard()
        return {
            "is_active": self.is_active,
            "blocked_attacks_count": self._blocked_attacks_count,
            "latest_verdict": latest.status_verdict,
            "crypto_protected": latest.contains_crypto_address,
            "crypto_type": latest.detected_crypto_type,
            "masked_address": latest.matched_address_masked,
            "details": latest.details
        }


clipboard_shield = ClipboardShieldEngine()
