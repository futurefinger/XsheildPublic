"""
XSHEILD Central Version Authority
Publisher: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
"""

__version__ = "2.6.29"

def get_app_version() -> str:
    """Returns canonical active application version."""
    return __version__
