"""
XSHEILD Cloud AI Sandbox & Behavioral Detonation Engine
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, India
Official Destination: futurefingerindia@gmail.com

Provides static PE analysis, section entropy evaluation, anti-analysis detection,
and cloud sandbox detonation (CAPE/Cuckoo/Future Finger Cloud Sandbox).
"""

import os
import sys
import math
import hashlib
import json
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [SANDBOX] %(message)s")
logger = logging.getLogger("xsheild.sandbox")

SUSPICIOUS_APIS = {
    "VirtualAllocEx": "Process Injection / Memory Allocation",
    "WriteProcessMemory": "Process Memory Tampering",
    "CreateRemoteThread": "Thread Hijacking / Injection (MITRE T1055)",
    "SetWindowsHookEx": "Keystroke / Message Hooking (MITRE T1056.001)",
    "AdjustTokenPrivileges": "Privilege Escalation (MITRE T1078)",
    "OpenProcess": "Target Process Handle Access",
    "InternetOpenUrlA": "C2 Network Beaconing",
    "URLDownloadToFileA": "Dropper Payload Retrieval (MITRE T1105)",
    "CryptEncrypt": "Ransomware Encryption Routine (MITRE T1486)"
}

EVASION_INDICATORS = [
    "IsDebuggerPresent",
    "CheckRemoteDebuggerPresent",
    "OutputDebugString",
    "GetTickCount",
    "QueryPerformanceCounter",
    "VBox",
    "VMware",
    "qemu",
    "wine_get_version"
]


def calculate_entropy(data: bytes) -> float:
    """Calculates Shannon entropy of byte sequence (0.0 to 8.0)."""
    if not data:
        return 0.0
    entropy = 0.0
    length = len(data)
    occurrences = [0] * 256
    for b in data:
        occurrences[b] += 1
    for count in occurrences:
        if count == 0:
            continue
        p = count / length
        entropy -= p * math.log2(p)
    return round(entropy, 3)


class CloudSandboxEngine:
    """Multi-stage static & dynamic behavioral analysis engine."""

    def __init__(self, cloud_hub_url: Optional[str] = None):
        self.cloud_hub_url = (cloud_hub_url or os.environ.get("XSHEILD_CLOUD_URL", "http://127.0.0.1:8300")).rstrip("/")

    def analyze_binary_static(self, file_path: str) -> Dict[str, Any]:
        """Performs comprehensive local static PE inspection."""
        if not os.path.isfile(file_path):
            return {"error": "File not found", "threat_score": 0, "verdict": "ERROR"}

        with open(file_path, "rb") as f:
            content = f.read()

        file_size = len(content)
        file_sha256 = hashlib.sha256(content).hexdigest()
        file_md5 = hashlib.md5(content).hexdigest()
        entropy = calculate_entropy(content)

        # Search for suspicious APIs and evasion patterns
        detected_apis = []
        for api_name, desc in SUSPICIOUS_APIS.items():
            if api_name.encode() in content:
                detected_apis.append({"api": api_name, "behavior": desc})

        detected_evasions = []
        for evasion in EVASION_INDICATORS:
            if evasion.encode() in content:
                detected_evasions.append(evasion)

        # Heuristic scoring
        threat_score = 0
        mitre_tactics = []

        if entropy > 7.3:
            threat_score += 40
            mitre_tactics.append("T1027: Obfuscated/Encrypted Payload (High Entropy)")
        elif entropy > 6.8:
            threat_score += 15

        if len(detected_apis) >= 3:
            threat_score += 45
            mitre_tactics.append("T1055: Process Injection / Memory Manipulation")
        elif len(detected_apis) >= 1:
            threat_score += 20

        if len(detected_evasions) >= 2:
            threat_score += 20
            mitre_tactics.append("T1497: Virtualization/Sandbox Evasion")

        # Cap score at 100
        threat_score = min(100, threat_score)

        if threat_score >= 70:
            verdict = "MALICIOUS"
        elif threat_score >= 35:
            verdict = "SUSPICIOUS"
        else:
            verdict = "BENIGN"

        return {
            "file_name": os.path.basename(file_path),
            "file_path": file_path,
            "file_size": file_size,
            "sha256": file_sha256,
            "md5": file_md5,
            "entropy": entropy,
            "threat_score": threat_score,
            "verdict": verdict,
            "detected_apis": detected_apis,
            "detected_evasions": detected_evasions,
            "mitre_tactics": mitre_tactics,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def submit_to_cloud_detonation(self, file_path: str) -> Dict[str, Any]:
        """Submits suspicious file telemetry to Cloud Detonation Hub."""
        static_report = self.analyze_binary_static(file_path)
        if static_report.get("error"):
            return static_report

        payload = {
            "name": static_report["file_name"],
            "hash": static_report["sha256"],
            "entropy": static_report["entropy"],
            "suspicious_api_count": len(static_report["detected_apis"]),
            "evasion_count": len(static_report["detected_evasions"])
        }

        url = f"{self.cloud_hub_url}/api/v1/sandbox/submit"
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5) as res:
                if res.status == 200:
                    cloud_data = json.loads(res.read().decode("utf-8"))
                    static_report["cloud_sandbox"] = cloud_data
                    # Combine verdicts
                    if cloud_data.get("verdict") == "MALICIOUS":
                        static_report["verdict"] = "MALICIOUS"
                        static_report["threat_score"] = max(static_report["threat_score"], cloud_data.get("threat_score", 85))
                    return static_report
        except Exception as e:
            logger.debug(f"Cloud detonation endpoint unreachable ({e}). Using local static verdict.")

        return static_report
