"""
XSHEILD Legal Consent & Installation Telemetry Dispatcher
Owner: Future Finger Technologies (futurefingerindia@gmail.com)

Manages:
1. Legal Click-Wrap consent verification and persistent audit record.
2. Hardware fingerprinting, system specifications, and IP telemetry capture.
3. Automated dispatch of the installation & legal registration dossier to 'futurefingerindia@gmail.com'.
4. Enforces exclusive New Delhi, India jurisdiction acceptance across all users worldwide.
"""

import os
import sys
import json
import time
import hashlib
import platform
import threading
import urllib.request
import urllib.parse
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Tuple

from src.core.logger import get_logger
from src.core.legal_terms import AGREEMENT_VERSION, PUBLISHER_NAME, OFFICIAL_JURISDICTION, CONTACT_EMAIL
from src.licensing.client import get_hardware_device_id

logger = get_logger("legal_telemetry")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
CONSENT_FILE = os.path.join(CONFIG_DIR, "legal_consent.json")
AUDIT_LOG_FILE = os.path.join(CONFIG_DIR, "legal_consent_audit.json")
TELEMETRY_TXT_FILE = os.path.join(CONFIG_DIR, "installation_telemetry.txt")
RECIPIENT_EMAIL = "futurefingerindia@gmail.com"


def _get_public_ip_telemetry() -> Dict[str, Any]:
    """Retrieves public IP and geo telemetry with fast timeout and offline fallback."""
    telemetry = {
        "ip": "Unknown / Offline",
        "city": "Unknown",
        "region": "Unknown",
        "country": "Unknown",
        "org": "Unknown"
    }

    urls = [
        "https://ipapi.co/json/",
        "https://api.ipify.org?format=json"
    ]

    for url in urls:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "XSHEILD-Endpoint-Sentinel/1.0 (Future Finger Technologies)"}
            )
            with urllib.request.urlopen(req, timeout=3.5) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                if "ip" in data:
                    telemetry["ip"] = data.get("ip", "Unknown")
                    telemetry["city"] = data.get("city", "Unknown")
                    telemetry["region"] = data.get("region", "Unknown")
                    telemetry["country"] = data.get("country_name", data.get("country", "Unknown"))
                    telemetry["org"] = data.get("org", "Unknown")
                    return telemetry
        except Exception:
            continue

    return telemetry


def _dispatch_email_to_futurefinger(record: Dict[str, Any]) -> bool:
    """
    Dispatches a complete installation and legal acceptance dossier
    directly to 'futurefingerindia@gmail.com' via secure HTTPS relay.
    """
    # Resolve public IP asynchronously in background thread without blocking main thread
    try:
        net_info = _get_public_ip_telemetry()
        if net_info and net_info.get("ip") != "Unknown":
            record["network_telemetry"] = net_info
    except Exception:
        pass
    subject = f"[XSHEILD NEW INSTALLATION] {record['user_name']} ({record['user_email']}) - Device: {record['device_id']}"

    email_body = f"""================================================================================
🛡️ XSHEILD NEW CLIENT INSTALLATION & LEGAL CONSENT DOSSIER
Publisher: {PUBLISHER_NAME}
Recipient: {RECIPIENT_EMAIL}
================================================================================

--- 1. CLIENT IDENTIFICATION ---
User Name         : {record['user_name']}
Email Address     : {record['user_email']}
Phone / Org       : {record.get('organization') or 'N/A'}
Hardware Device ID: {record['device_id']}
Client Local Time : {record.get('local_timestamp')}
UTC Consent Time  : {record['utc_timestamp']}

--- 2. SYSTEM SPECIFICATIONS & ENVIRONMENT ---
Computer Name     : {record.get('computer_name')}
Windows Username  : {record.get('username')}
Operating System  : {record.get('os_platform')} ({record.get('os_version')})
System Architecture: {record.get('machine_arch')}
Processor Info    : {record.get('processor')}

--- 3. NETWORK & LOCATION TELEMETRY ---
Public IP Address : {record.get('network_telemetry', {}).get('ip')}
City / Region     : {record.get('network_telemetry', {}).get('city')}, {record.get('network_telemetry', {}).get('region')}
Country Detected  : {record.get('network_telemetry', {}).get('country')}
ISP / Organization: {record.get('network_telemetry', {}).get('org')}

--- 4. LEGAL CONTRACT & JURISDICTION BINDING ---
Agreement Version : {record['agreement_version']}
Mandatory Jurisdiction: {record['jurisdiction']} (ACCEPTED & BOUND WORLDWIDE)
EULA & Terms      : ACCEPTED (True)
Exclusive Delhi   : ACCEPTED (True)
Telemetry Consent : ACCEPTED (True)
Digital Signature : {record['digital_signature']}

--------------------------------------------------------------------------------
This dossier serves as admissible electronic evidence of binding click-wrap 
contract acceptance pursuant to Section 10A of the Indian IT Act, 2000.
================================================================================
"""

    # 1. Save plaintext formatted copy locally
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(TELEMETRY_TXT_FILE, "w", encoding="utf-8") as f:
            f.write(email_body)
    except Exception as e:
        logger.warning(f"Failed to write local telemetry text: {e}")

    # 2. Asynchronous HTTPS post to FormSubmit relay for instant inbox delivery
    relay_endpoint = f"https://formsubmit.co/ajax/{RECIPIENT_EMAIL}"
    payload = {
        "_subject": subject,
        "userName": record['user_name'],
        "userEmail": record['user_email'],
        "organization": record.get('organization') or "Individual",
        "deviceId": record['device_id'],
        "jurisdiction": record['jurisdiction'],
        "agreementVersion": record['agreement_version'],
        "consentTimestamp": record['utc_timestamp'],
        "osPlatform": record.get('os_platform'),
        "publicIp": record.get('network_telemetry', {}).get('ip'),
        "country": record.get('network_telemetry', {}).get('country'),
        "digitalSignature": record['digital_signature'],
        "fullDetails": email_body
    }

    try:
        json_data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            relay_endpoint,
            data=json_data,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "XSHEILD-Legal-Telemetry/1.0"
            }
        )
        with urllib.request.urlopen(req, timeout=7.0) as resp:
            resp_body = resp.read().decode("utf-8")
            logger.info(f"Successfully transmitted installation dossier to {RECIPIENT_EMAIL}: {resp_body[:100]}")
            return True
    except Exception as e:
        logger.warning(f"Direct HTTPS email dispatch notice (will retry on next sync): {e}")
        return False


class LegalConsentManager:
    """Enforces first-launch legal onboarding, Delhi jurisdiction, and telemetric logging."""

    def __init__(self, consent_path: str = CONSENT_FILE):
        self.consent_path = consent_path
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(self.consent_path), exist_ok=True)

    def is_consent_given(self) -> bool:
        """Checks if a valid legal consent agreement is present on this machine."""
        # 1. Check primary persistent consent file
        if os.path.exists(self.consent_path):
            try:
                with open(self.consent_path, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)

                # Mandatory jurisdiction requirement (must be exclusive New Delhi, Delhi, India)
                jur = data.get("jurisdiction", "")
                if not jur.startswith("New Delhi, Delhi, India"):
                    return False

                # A. Statutory/Installer-sealed binding agreement
                if data.get("legal_status") == "FULLY_BOUND_AND_ENFORCEABLE":
                    return True

                # B. Check mandatory fields and signature integrity if present
                if "user_name" in data and "user_email" in data and "digital_signature" in data:
                    raw_sign_string = f"{data['user_name']}:{data['user_email']}:{data.get('device_id', '')}:{data.get('agreement_version', AGREEMENT_VERSION)}"
                    computed_sig = hashlib.sha256(raw_sign_string.encode("utf-8")).hexdigest()
                    if computed_sig == data.get("digital_signature"):
                        return True
                    # Even if device_id shifted due to hardware change, existing agreement remains binding
                    if data.get("user_name") and data.get("user_email"):
                        return True
                elif data.get("user_name") and data.get("user_email"):
                    return True
            except Exception as e:
                logger.warning(f"Error reading consent record: {e}")

        # 2. Check contract audit log as secondary fallback (only for default system profile)
        if self.consent_path == CONSENT_FILE and os.path.isfile(AUDIT_LOG_FILE):
            try:
                with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as af:
                    audits = json.load(af)
                    if audits and len(audits) > 0:
                        return True
            except Exception:
                pass

        # 3. Check contracts folder (only for default system profile)
        if self.consent_path == CONSENT_FILE:
            contracts_dir = os.path.join(CONFIG_DIR, "contracts")
            if os.path.isdir(contracts_dir):
                try:
                    c_files = [f for f in os.listdir(contracts_dir) if f.endswith(".json")]
                    if len(c_files) > 0:
                        return True
                except Exception:
                    pass

        return False

    def get_consent_record(self) -> Optional[Dict[str, Any]]:
        """Returns the active consent record if available."""
        if os.path.exists(self.consent_path):
            try:
                with open(self.consent_path, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)
                    # Normalize missing fields for UI presentation
                    data["user_email"] = data.get("user_email") or f"{data.get('user_name', 'user').lower()}@{data.get('machine_name', 'host').lower()}.local"
                    data["organization"] = data.get("organization") or "Future Finger Technologies"
                    data["jurisdiction"] = data.get("jurisdiction") or OFFICIAL_JURISDICTION
                    return data
            except Exception:
                pass

        # Fallback to latest audit log record
        if os.path.isfile(AUDIT_LOG_FILE):
            try:
                with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as af:
                    audits = json.load(af)
                    if audits and len(audits) > 0:
                        return audits[-1]
            except Exception:
                pass

        return None

    def record_and_dispatch_consent(
        self,
        user_name: str,
        user_email: str,
        organization: str = "",
        checkboxes: Optional[Dict[str, bool]] = None
    ) -> Dict[str, Any]:
        """
        Validates mandatory checkboxes, computes cryptographic signature,
        persists the legal record locally, and initiates background email dispatch to Future Finger Technologies.
        """
        clean_name = user_name.strip()
        clean_email = user_email.strip().lower()

        if not clean_name:
            return {"success": False, "error": "Full Name is mandatory to validate legal license agreement."}

        if not clean_email or "@" not in clean_email or "." not in clean_email:
            return {"success": False, "error": "A valid Email Address is required to register endpoint security."}

        # Validate mandatory legal checkboxes
        c_boxes = checkboxes or {}
        if not c_boxes.get("agree_terms", False):
            return {"success": False, "error": "You must accept the End User License Agreement and Liability Disclaimer."}

        if not c_boxes.get("agree_delhi_jurisdiction", False):
            return {"success": False, "error": "You must accept Exclusive Jurisdiction of Courts in New Delhi, Delhi, India."}

        if not c_boxes.get("agree_telemetry", False):
            return {"success": False, "error": "You must consent to registration telemetry submission to futurefingerindia@gmail.com."}

        with self._lock:
            device_id = get_hardware_device_id()
            now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
            now_local = datetime.now().strftime("%Y-%m-%d %H:%M:%S (Local)")

            # Compute tamper-proof digital signature
            raw_sign_string = f"{clean_name}:{clean_email}:{device_id}:{AGREEMENT_VERSION}"
            digital_signature = hashlib.sha256(raw_sign_string.encode("utf-8")).hexdigest()

            record = {
                "user_name": clean_name,
                "user_email": clean_email,
                "organization": organization.strip(),
                "device_id": device_id,
                "agreement_version": AGREEMENT_VERSION,
                "jurisdiction": OFFICIAL_JURISDICTION,
                "utc_timestamp": now_utc,
                "local_timestamp": now_local,
                "computer_name": os.environ.get("COMPUTERNAME", "Unknown"),
                "username": os.environ.get("USERNAME", "Unknown"),
                "os_platform": platform.platform(),
                "os_version": platform.version(),
                "machine_arch": platform.machine(),
                "processor": platform.processor(),
                "digital_signature": digital_signature,
                "publisher": PUBLISHER_NAME,
                "support_email": RECIPIENT_EMAIL,
                "network_telemetry": {"ip": "Local Endpoint", "city": "India", "country": "India"}
            }

            # 1. Save persistent local consent file
            try:
                temp_p = self.consent_path + ".tmp"
                with open(temp_p, "w", encoding="utf-8") as f:
                    json.dump(record, f, indent=2)
                os.replace(temp_p, self.consent_path)
                logger.info(f"Legal consent recorded for '{clean_name}' ({clean_email}) bound to Delhi, India jurisdiction.")
            except Exception as e:
                logger.error(f"Failed to persist consent JSON: {e}")
                return {"success": False, "error": f"Failed to save legal consent state: {str(e)}"}

            # 2. Append to permanent append-only audit log
            try:
                audit_records = []
                if os.path.isfile(AUDIT_LOG_FILE):
                    try:
                        with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as af:
                            audit_records = json.load(af)
                    except Exception:
                        audit_records = []
                audit_records.append(record)
                with open(AUDIT_LOG_FILE, "w", encoding="utf-8") as af:
                    json.dump(audit_records, af, indent=2)
            except Exception:
                pass

            # 3. Dispatch full dossier to 'futurefingerindia@gmail.com' in background thread
            threading.Thread(
                target=_dispatch_email_to_futurefinger,
                args=(record,),
                daemon=True,
                name="LegalTelemetryEmailThread"
            ).start()

            return {
                "success": True,
                "message": "Legal terms accepted. License activated under New Delhi, India jurisdiction.",
                "record": record
            }


# Global singleton instance
legal_consent_manager = LegalConsentManager()
