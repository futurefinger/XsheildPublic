"""
XSHEILD Viral In-App Referral & Growth Engine
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
Official Contact: futurefingerindia@gmail.com

Mechanic:
"Invite 3 Friends to get 6 Months of XSHEILD Pro Free (180 Days)"
Generates unique user referral links, tracks validated installations,
and unlocks cryptographic entitlement rewards.
"""

import os
import sys
import json
import time
import hashlib
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timezone

from src.licensing.client import get_hardware_device_id, LicensingClient

logger = logging.getLogger("xsheild.referral_engine")

LOCAL_APPDATA = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
REFERRAL_STATE_PATH = os.path.join(LOCAL_APPDATA, "XSHEILD", "referral_state.json")
REFERRALS_TARGET = 3
REWARD_DAYS = 180  # 6 Months Pro


class ReferralEngine:
    """Manages unique referral links, viral tracking, and 6-month Pro reward unlocks."""

    def __init__(self, state_path: str = REFERRAL_STATE_PATH, licensing_client: Optional[LicensingClient] = None):
        self.state_path = state_path
        self.licensing_client = licensing_client or LicensingClient()
        self.hwid = get_hardware_device_id()
        self.referral_code = self._generate_referral_code(self.hwid)
        self.referral_link = f"https://xsheild.futurefinger.in/download?ref={self.referral_code}"
        self._ensure_state()

    @staticmethod
    def _generate_referral_code(hwid: str) -> str:
        clean = hwid.strip().upper()
        h = hashlib.sha256(f"FFT_XSH_REF_{clean}".encode("utf-8")).hexdigest()[:8].upper()
        return f"XSH-REF-{h}"

    def _ensure_state(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
            if not os.path.isfile(self.state_path):
                init_data = {
                    "referral_code": self.referral_code,
                    "referral_link": self.referral_link,
                    "hwid": self.hwid,
                    "referrals_count": 0,
                    "referrals_target": REFERRALS_TARGET,
                    "referred_devices": [],
                    "reward_claimed": False,
                    "reward_claim_date": None,
                    "invited_by": None,
                    "created_at": datetime.now(timezone.utc).isoformat()
                }
                self._save_state(init_data)
        except Exception as e:
            logger.debug(f"Error ensuring referral state: {e}")

    def _load_state(self) -> Dict[str, Any]:
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {
                "referral_code": self.referral_code,
                "referral_link": self.referral_link,
                "hwid": self.hwid,
                "referrals_count": 0,
                "referrals_target": REFERRALS_TARGET,
                "referred_devices": [],
                "reward_claimed": False,
                "reward_claim_date": None,
                "invited_by": None
            }

    def _save_state(self, state: Dict[str, Any]) -> None:
        try:
            tmp = self.state_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
            os.replace(tmp, self.state_path)
        except Exception as e:
            logger.debug(f"Error saving referral state: {e}")

    def get_overview(self) -> Dict[str, Any]:
        """Returns referral status, progress, target, and unlock eligibility."""
        state = self._load_state()
        count = state.get("referrals_count", 0)
        target = state.get("referrals_target", REFERRALS_TARGET)
        progress_pct = min(100.0, round((count / max(1, target)) * 100.0, 1))
        is_eligible = (count >= target) and not state.get("reward_claimed", False)

        entitlement = self.licensing_client.get_entitlement_status()

        return {
            "referral_code": self.referral_code,
            "referral_link": self.referral_link,
            "referrals_count": count,
            "referrals_target": target,
            "progress_percent": progress_pct,
            "is_reward_eligible": is_eligible,
            "reward_claimed": state.get("reward_claimed", False),
            "reward_description": "6 Months XSHEILD Pro License Free (180 Days)",
            "invited_by": state.get("invited_by"),
            "current_plan": entitlement.get("plan", "FREE_EVALUATION"),
            "days_remaining": entitlement.get("days_remaining", 0)
        }

    def add_referral_credit(self, friend_hwid_or_tag: str) -> Dict[str, Any]:
        """
        Adds a verified referral credit when a friend installs XSHEILD using this code.
        """
        state = self._load_state()
        referred = state.setdefault("referred_devices", [])
        if friend_hwid_or_tag not in referred:
            referred.append(friend_hwid_or_tag)
            state["referrals_count"] = len(referred)
            self._save_state(state)
            logger.info(f"[REFERRAL ENGINE] Credited friend referral: {friend_hwid_or_tag}. Total: {len(referred)}")

        return self.get_overview()

    def claim_reward(self) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Unlocks the 6 Months Pro license when 3 friends have been referred.
        """
        state = self._load_state()
        count = state.get("referrals_count", 0)
        target = state.get("referrals_target", REFERRALS_TARGET)

        if count < target:
            return False, f"Requirement not met. You have invited {count}/{target} friends. Need {target - count} more.", self.get_overview()

        if state.get("reward_claimed", False):
            return True, "Reward already claimed. Your 6 months Pro license is currently active.", self.get_overview()

        # Construct a 180-day PRO entitlement token
        from src.licensing.token_verifier import create_signed_token, DEFAULT_HMAC_SECRET

        now = int(time.time())
        expires = now + (REWARD_DAYS * 86400)
        payload = {
            "license_id": f"REF-PRO-{self.referral_code}",
            "device_id": self.hwid,
            "plan": "PRO",
            "seats": 1,
            "customer_email": "referral_partner@xsheild.user",
            "issued_at": now,
            "expires_at": expires,
            "is_trial": False,
            "features": ["REALTIME_SCAN", "RANSOMWARE_SHIELD", "CLOUD_SANDBOX", "USB_SECURITY", "FIREWALL_GUARD"]
        }
        token = create_signed_token(payload, DEFAULT_HMAC_SECRET)

        ok, msg = self.licensing_client.install_license_token(token)
        if ok:
            state["reward_claimed"] = True
            state["reward_claim_date"] = datetime.now(timezone.utc).isoformat()
            self._save_state(state)
            logger.info(f"[REFERRAL ENGINE] 6 Months Pro unlocked successfully for {self.hwid}!")
            return True, "Congratulations! 6 Months of XSHEILD Pro has been activated on your system.", self.get_overview()
        else:
            return False, f"License installation failed: {msg}", self.get_overview()

    def apply_invited_by_code(self, invite_code: str) -> Tuple[bool, str]:
        """
        When a new user inputs an invite code, grants them +15 bonus evaluation days.
        """
        clean_code = invite_code.strip().upper()
        if not clean_code.startswith("XSH-REF-"):
            return False, "Invalid referral code format. Code must begin with XSH-REF-"

        state = self._load_state()
        if state.get("invited_by"):
            return False, f"A referral code has already been applied: {state['invited_by']}"

        if clean_code == self.referral_code:
            return False, "You cannot apply your own referral code."

        state["invited_by"] = clean_code
        self._save_state(state)

        # Grant 15 extra evaluation days
        self.licensing_client.activate_trial(trial_days=29)
        return True, f"Referral code {clean_code} applied! Enjoy 15 bonus days of full XSHEILD Pro evaluation."


# Global instance
referral_engine = ReferralEngine()
