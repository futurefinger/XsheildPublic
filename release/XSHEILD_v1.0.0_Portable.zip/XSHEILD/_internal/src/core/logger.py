"""
XSHEILD Centralized Rotating File Logger & Diagnostics Hub
Owner: Future Finger Technologies

Provides:
1. High-reliability dual rotating log files (%LOCALAPPDATA%\\XSHEILD\\logs\\xsheild.log and errors.log).
2. Automated log rotation (5MB per file, 5 rolling backups).
3. Thread-safe log reading & real-time console tailing for the desktop UI.
4. Exportable sanitized diagnostic support bundles.
"""

import os
import sys
import time
import json
import zipfile
import logging
from logging.handlers import RotatingFileHandler
from typing import List, Dict, Any, Optional

APP_NAME = "XSHEILD"
LOG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD", "logs")
MAIN_LOG_FILE = os.path.join(LOG_DIR, "xsheild.log")
ERROR_LOG_FILE = os.path.join(LOG_DIR, "errors.log")

_logging_initialized = False


def setup_logging(level: int = logging.INFO) -> None:
    """Configures centralized rolling file handlers and standard stream logger."""
    global _logging_initialized
    if _logging_initialized:
        return

    os.makedirs(LOG_DIR, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 1. Main rolling activity log (INFO and above)
    try:
        main_handler = RotatingFileHandler(
            filename=MAIN_LOG_FILE,
            maxBytes=5 * 1024 * 1024,  # 5 MB
            backupCount=5,
            encoding="utf-8"
        )
        main_handler.setLevel(logging.INFO)
        main_handler.setFormatter(formatter)
        root_logger.addHandler(main_handler)
    except Exception as e:
        sys.stderr.write(f"[XSHEILD Logger] Failed to init main log handler: {e}\n")

    # 2. Dedicated errors-only rolling log (WARNING, ERROR, CRITICAL)
    try:
        error_handler = RotatingFileHandler(
            filename=ERROR_LOG_FILE,
            maxBytes=5 * 1024 * 1024,  # 5 MB
            backupCount=5,
            encoding="utf-8"
        )
        error_handler.setLevel(logging.WARNING)
        error_handler.setFormatter(formatter)
        root_logger.addHandler(error_handler)
    except Exception as e:
        sys.stderr.write(f"[XSHEILD Logger] Failed to init error log handler: {e}\n")

    # 3. Stream Handler for terminal/console output in dev mode
    try:
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setLevel(level)
        stream_handler.setFormatter(formatter)
        root_logger.addHandler(stream_handler)
    except Exception:
        pass

    _logging_initialized = True
    logging.getLogger("xsheild.core").info("XSHEILD centralized rotating logging initialized.")


def get_logger(name: str) -> logging.Logger:
    """Returns a named logger configured under the XSHEILD hierarchy."""
    if not _logging_initialized:
        setup_logging()
    return logging.getLogger(f"xsheild.{name}")


def read_recent_logs(lines: int = 80, log_type: str = "all") -> List[str]:
    """
    Reads the tail of the selected log file safely.
    log_type: 'all' -> xsheild.log, 'errors' -> errors.log
    """
    target = ERROR_LOG_FILE if log_type == "errors" else MAIN_LOG_FILE
    if not os.path.isfile(target):
        return [f"[INFO] Log file not yet created at {target}"]

    try:
        with open(target, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
            return [l.strip() for l in all_lines[-lines:]]
    except Exception as e:
        return [f"[ERROR] Failed reading log file: {e}"]


def create_diagnostics_bundle(output_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Creates a zip archive containing sanitized logs, system metadata,
    and recent crash reports for engineering support.
    """
    out_dir = output_dir or os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Downloads")
    os.makedirs(out_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    bundle_name = f"XSHEILD_Diagnostics_{timestamp}.zip"
    bundle_path = os.path.join(out_dir, bundle_name)

    files_included = 0
    try:
        with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            # 1. Include logs
            if os.path.isdir(LOG_DIR):
                for fname in os.listdir(LOG_DIR):
                    fpath = os.path.join(LOG_DIR, fname)
                    if os.path.isfile(fpath) and fname.endswith(".log"):
                        zf.write(fpath, os.path.join("logs", fname))
                        files_included += 1

            # 2. Include crash reports
            crash_dir = os.path.join(os.path.dirname(LOG_DIR), "crash_reports")
            if os.path.isdir(crash_dir):
                for fname in os.listdir(crash_dir):
                    fpath = os.path.join(crash_dir, fname)
                    if os.path.isfile(fpath):
                        zf.write(fpath, os.path.join("crash_reports", fname))
                        files_included += 1

        return {
            "success": True,
            "bundle_path": bundle_path,
            "bundle_name": bundle_name,
            "files_count": files_included
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
