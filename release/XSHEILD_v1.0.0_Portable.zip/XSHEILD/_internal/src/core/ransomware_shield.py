"""
XSHEILD Ransomware Shield & Canary Honeypot Defense Engine
Owner: Future Finger Technologies
Provides real-time mass encryption detection, canary honeypot surveillance,
known ransomware extension matching, and emergency process isolation.
"""

import os
import sys
import time
import math
import uuid
import json
import ctypes
import hashlib
import logging
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from src.core.logger import get_logger

logger = get_logger("core.ransomware_shield")

# Known ransomware extensions
KNOWN_RANSOMWARE_EXTENSIONS: Set[str] = {
    ".locked", ".crypto", ".crypted", ".enc", ".crypt", ".locky",
    ".wanacry", ".wncry", ".stop", ".djvu", ".makop", ".blackcat",
    ".alphv", ".lockbit", ".conti", ".revil", ".ryuk", ".cerber",
    ".phobos", ".dharma", ".gandcrab", ".sodinokibi", ".mallox",
    ".babuk", ".medusa", ".play", ".royal", ".akira", ".bianlian"
}

# Default Canary File Content & Signatures
CANARY_MAGIC = b"XSHEILD_CANARY_INTEGRITY_BEACON_FUTURE_FINGER_2026"

DEFAULT_INCIDENTS_PATH = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "ransomware_incidents.json"
)


@dataclass
class RansomwareIncident:
    incident_id: str
    detected_at: str
    threat_category: str
    offending_process_id: Optional[int]
    offending_process_name: Optional[str]
    target_path: str
    description: str
    entropy_score: float
    action_taken: str


def calculate_shannon_entropy(data: bytes) -> float:
    """Calculates Shannon entropy of byte data (0.0 to 8.0). High values (> 7.5) indicate encryption/packing."""
    if not data:
        return 0.0
    entropy = 0.0
    length = len(data)
    byte_counts = [0] * 256
    for b in data:
        byte_counts[b] += 1
    for count in byte_counts:
        if count > 0:
            p_x = float(count) / length
            entropy -= p_x * math.log2(p_x)
    return round(entropy, 4)


class CanaryHoneypotManager:
    """
    Deploys decoy canary files with cryptographically verified checksums in strategic directories.
    If any canary is altered, renamed, or unlinked, an immediate ransomware alert is raised.
    """

    def __init__(self, canary_roots: Optional[List[str]] = None):
        self.canary_roots = canary_roots or [
            os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD", "canary"),
            os.path.join(os.path.expanduser("~"), "Documents"),
            os.path.join(os.path.expanduser("~"), "Desktop")
        ]
        self._canary_manifest: Dict[str, str] = {}  # path -> expected sha256
        self.deploy_canaries()

    def deploy_canaries(self) -> None:
        """Deploys decoy files with verified content."""
        for root in self.canary_roots:
            try:
                os.makedirs(root, exist_ok=True)
                canary_filename = ".xsh_integrity_beacon.docx"
                canary_path = os.path.join(root, canary_filename)

                # Prepare standard canary payload with randomized salt + static magic
                content = CANARY_MAGIC + b"_" + hashlib.sha256(root.encode("utf-8")).digest()
                with open(canary_path, "wb") as f:
                    f.write(content)

                expected_hash = hashlib.sha256(content).hexdigest()
                self._canary_manifest[canary_path] = expected_hash
            except Exception as e:
                logger.debug(f"Could not deploy canary in {root}: {e}")

    def verify_canaries(self) -> List[Tuple[str, str]]:
        """
        Audits all deployed canary files.
        Returns list of (path, failure_reason) for any modified or deleted canary.
        """
        violations = []
        for path, expected_hash in list(self._canary_manifest.items()):
            if not os.path.exists(path):
                violations.append((path, "CANARY_FILE_DELETED"))
                continue
            try:
                with open(path, "rb") as f:
                    actual_hash = hashlib.sha256(f.read()).hexdigest()
                if actual_hash != expected_hash:
                    violations.append((path, "CANARY_TAMPERED_OR_ENCRYPTED"))
            except Exception as err:
                violations.append((path, f"CANARY_READ_ERROR: {err}"))
        return violations

    def cleanup_canaries(self) -> None:
        """Safely removes deployed canary files during uninstallation or shutdown."""
        for path in self._canary_manifest:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass
        self._canary_manifest.clear()


class RansomwareShield:
    """
    Enterprise-grade Ransomware Shield combining honeypots, rapid encryption heuristics,
    known ransomware extension matching, and process isolation.
    """

    def __init__(self, incidents_path: Optional[str] = None):
        self.incidents_path = incidents_path or DEFAULT_INCIDENTS_PATH
        self.canary_mgr = CanaryHoneypotManager()
        self.is_active = True
        self.emergency_mode = False

        # Sliding window for tracking rapid file modifications: list of (timestamp, filepath)
        self._mod_history: List[Tuple[float, str]] = []
        self._rapid_threshold_count = 15
        self._rapid_threshold_window_sec = 3.0

        self._ensure_incidents_file_exists()

    def _ensure_incidents_file_exists(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.incidents_path), exist_ok=True)
            if not os.path.exists(self.incidents_path):
                self._save_incidents([])
        except Exception:
            pass

    def _load_incidents(self) -> List[Dict[str, Any]]:
        try:
            with open(self.incidents_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_incidents(self, incidents: List[Dict[str, Any]]) -> None:
        temp_p = self.incidents_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(incidents, f, indent=2)
        import shutil
        for attempt in range(5):
            try:
                os.replace(temp_p, self.incidents_path)
                return
            except (PermissionError, OSError):
                if attempt == 4:
                    try:
                        shutil.copyfile(temp_p, self.incidents_path)
                        try:
                            os.remove(temp_p)
                        except OSError:
                            pass
                        return
                    except Exception:
                        pass
                time.sleep(0.05 * (attempt + 1))

    def record_incident(self, incident: RansomwareIncident) -> None:
        """Appends incident to disk-backed log with rotation at 500 records."""
        logger.warning(
            f"RANSOMWARE ALERT [{incident.threat_category}]: "
            f"Process '{incident.offending_process_name}' (PID {incident.offending_process_id}) "
            f"targeting '{incident.target_path}'. Action: {incident.action_taken}"
        )
        incidents = self._load_incidents()
        incidents.insert(0, asdict(incident))
        if len(incidents) > 500:
            incidents = incidents[:500]
        self._save_incidents(incidents)

    def get_incident_history(self) -> List[Dict[str, Any]]:
        return self._load_incidents()

    def check_file_extension(self, file_path: str) -> Optional[str]:
        """Checks if a file extension matches known ransomware patterns."""
        _, ext = os.path.splitext(file_path.lower())
        if ext in KNOWN_RANSOMWARE_EXTENSIONS:
            return f"Ransomware.Extension{ext}"
        return None

    def evaluate_file_write(self, file_path: str, raw_sample: Optional[bytes] = None) -> Optional[RansomwareIncident]:
        """
        Evaluates a file write event for rapid encryption, suspicious entropy spikes,
        or known ransomware extensions.
        """
        if not self.is_active:
            return None

        # Exclude internal WebView2 runtime directories, browser caches, pywebview profiles, and test runs
        norm_path = file_path.replace("\\", "/").lower()
        if any(ign in norm_path for ign in ("ebwebview", "fft_desktop_app_profile", "pytest")):
            return None

        try:
            from src.core.exclusions import exclusion_manager
            if exclusion_manager.is_path_excluded(file_path):
                return None
        except Exception:
            pass

        now = time.time()
        self._mod_history.append((now, file_path))
        # Purge older than sliding window
        self._mod_history = [(ts, p) for ts, p in self._mod_history if now - ts <= self._rapid_threshold_window_sec]

        # 1. Check known ransomware extensions
        ext_threat = self.check_file_extension(file_path)
        if ext_threat:
            incident = RansomwareIncident(
                incident_id=str(uuid.uuid4()),
                detected_at=datetime.now(timezone.utc).isoformat(),
                threat_category="RANSOMWARE_EXTENSION",
                offending_process_id=None,
                offending_process_name=None,
                target_path=file_path,
                description=f"File renamed or written with known ransomware extension: {ext_threat}",
                entropy_score=8.0,
                action_taken="ALERTED_AND_LOGGED"
            )
            self.record_incident(incident)
            return incident

        # 2. Check for rapid mass file write activity
        if len(self._mod_history) >= self._rapid_threshold_count:
            # Check entropy of written payload if available
            entropy = 0.0
            if raw_sample:
                entropy = calculate_shannon_entropy(raw_sample)
            elif os.path.exists(file_path) and os.path.isfile(file_path):
                try:
                    with open(file_path, "rb") as f:
                        entropy = calculate_shannon_entropy(f.read(65536))
                except Exception:
                    pass

            if entropy > 7.45:
                incident = RansomwareIncident(
                    incident_id=str(uuid.uuid4()),
                    detected_at=datetime.now(timezone.utc).isoformat(),
                    threat_category="MASS_ENCRYPTION_ANOMALY",
                    offending_process_id=None,
                    offending_process_name=None,
                    target_path=file_path,
                    description=f"Rapid mass write ({len(self._mod_history)} files in {self._rapid_threshold_window_sec}s) with high entropy ({entropy})",
                    entropy_score=entropy,
                    action_taken="EMERGENCY_SHIELD_TRIGGERED"
                )
                self.record_incident(incident)
                self.emergency_mode = True
                return incident

        return None

    def audit_canary_integrity(self) -> List[RansomwareIncident]:
        """Audits canary honeypots and records incidents for any violations."""
        violations = self.canary_mgr.verify_canaries()
        incidents = []
        for path, reason in violations:
            inc = RansomwareIncident(
                incident_id=str(uuid.uuid4()),
                detected_at=datetime.now(timezone.utc).isoformat(),
                threat_category="CANARY_HONEYPOT_BREACH",
                offending_process_id=None,
                offending_process_name=None,
                target_path=path,
                description=f"Canary beacon breached: {reason}. Ransomware actively attacking user folders.",
                entropy_score=8.0,
                action_taken="CANARY_TRIP_EMERGENCY_ISOLATION"
            )
            self.record_incident(inc)
            incidents.append(inc)
            self.emergency_mode = True
        return incidents

    def isolate_suspicious_process(self, pid: int) -> bool:
        """
        Safely isolates or terminates an offending process by PID to halt active ransomware damage.
        Guards against terminating Windows core system processes using native Win32 kernel32 APIs.
        """
        if pid <= 4 or pid == os.getpid():
            logger.warning(f"Refusing to terminate system PID or self (PID {pid})")
            return False

        PROCESS_TERMINATE = 0x0001
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

        try:
            kernel32 = ctypes.windll.kernel32
            h_process = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE, False, pid)
            if not h_process:
                return False

            # Query process name to prevent terminating protected system binaries
            buf_size = 1024
            buf = ctypes.create_unicode_buffer(buf_size)
            size = ctypes.c_ulong(buf_size)
            pname = "unknown"
            if hasattr(kernel32, "QueryFullProcessImageNameW"):
                if kernel32.QueryFullProcessImageNameW(h_process, 0, buf, ctypes.byref(size)):
                    pname = os.path.basename(buf.value).lower()

            PROTECTED = {
                "csrss.exe", "lsass.exe", "smss.exe", "services.exe",
                "svchost.exe", "wininit.exe", "winlogon.exe", "explorer.exe",
                "xsheild.exe", "python.exe"
            }
            if pname in PROTECTED:
                kernel32.CloseHandle(h_process)
                logger.warning(f"Refusing to terminate protected system process '{pname}' (PID {pid})")
                return False

            success = kernel32.TerminateProcess(h_process, 1) != 0
            kernel32.CloseHandle(h_process)
            logger.info(f"Process '{pname}' (PID {pid}) terminated by Ransomware Shield")
            return success
        except Exception as e:
            logger.debug(f"Could not isolate process PID {pid}: {e}")
            return False

    def evaluate_shadow_copy_threat(self, command_line: str, pid: Optional[int] = None) -> Optional[RansomwareIncident]:
        """
        Detects ransomware precursor attempts to destroy Volume Shadow Copies or disable Windows Recovery.
        """
        if not command_line:
            return None

        cmd_lower = command_line.lower()
        is_threat = False
        desc = ""

        if "vssadmin" in cmd_lower and "delete" in cmd_lower and "shadows" in cmd_lower:
            is_threat = True
            desc = "Attempt to delete Volume Shadow Copies via vssadmin detected (precursor to unrecoverable encryption)"
        elif "wmic" in cmd_lower and "shadowcopy" in cmd_lower and "delete" in cmd_lower:
            is_threat = True
            desc = "Attempt to delete Volume Shadow Copies via WMIC query detected"
        elif "bcdedit" in cmd_lower and ("recoveryenabled no" in cmd_lower or "ignoreallfailures" in cmd_lower):
            is_threat = True
            desc = "Attempt to disable Windows Recovery Environment via bcdedit detected"
        elif "wbadmin" in cmd_lower and "delete" in cmd_lower and "catalog" in cmd_lower:
            is_threat = True
            desc = "Attempt to delete Windows Backup catalog detected"

        if is_threat:
            incident = RansomwareIncident(
                incident_id=str(uuid.uuid4()),
                detected_at=datetime.now(timezone.utc).isoformat(),
                threat_category="SHADOW_COPY_WIPER_ATTEMPT",
                offending_process_id=pid,
                offending_process_name="wiper_utility",
                target_path="System Volume Information / VSS",
                description=desc,
                entropy_score=8.0,
                action_taken="WIPER_COMMAND_FLAGGED_FOR_BLOCK"
            )
            self.record_incident(incident)
            self.emergency_mode = True
            return incident

        return None


# Global singleton
ransomware_shield = RansomwareShield()
