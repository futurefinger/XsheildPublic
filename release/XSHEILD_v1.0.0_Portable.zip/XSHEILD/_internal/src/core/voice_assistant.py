"""
XSHEILD AI Voice Assistant & Autonomous Audio Telemetry Engine
Owner: Future Finger Technologies

Provides real-time synthesized voice notifications for critical endpoint security events:
1. Application Startup Welcome ("Welcome back, Commander. XSHEILD Neural Defense Matrix is active.")
2. External Removable Media (USB) Detection, Scanning & Disinfection
3. Real-Time Threat Interception, Ransomware Blocks & Quarantine
4. System Scan Progress & Integrity Verification
5. Mode Changes (Gaming/Silent Mode, Voice Assistant Toggle)

Engine Design:
- High-performance, zero-latency Windows System.Speech SAPI synthesizer via persistent worker process.
- Dual-channel fallback: Dispatches to Edge WebView2 speech synthesis if UI is active.
- Non-blocking: All utterances queued and dispatched asynchronously.
- Respects user mute preference and Gaming / Silent Mode automatically.
"""

import os
import sys
import json
import logging
import threading
import subprocess
from typing import Optional

logger = logging.getLogger("xsheild.voice_assistant")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
AUDIO_CONFIG_FILE = os.path.join(CONFIG_DIR, "audio_settings.json")


class VoiceAssistant:
    """Singleton voice assistant manager for XSHEILD endpoint security."""

    def __init__(self, config_path: str = AUDIO_CONFIG_FILE):
        self.config_path = config_path
        self._lock = threading.Lock()
        self._enabled = True
        self._proc: Optional[subprocess.Popen] = None
        self._bridge_window = None
        self._load_config()

    def _load_config(self) -> None:
        if os.path.isfile(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._enabled = bool(data.get("voice_enabled", data.get("sound_effects_enabled", True)))
            except Exception as e:
                logger.debug(f"Audio config load notice: {e}")

    def _save_config(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            existing = {}
            if os.path.isfile(self.config_path):
                try:
                    with open(self.config_path, "r", encoding="utf-8") as f:
                        existing = json.load(f)
                except Exception:
                    pass
            existing["voice_enabled"] = self._enabled
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2)
        except Exception as e:
            logger.debug(f"Audio config save notice: {e}")

    @property
    def is_enabled(self) -> bool:
        with self._lock:
            return self._enabled

    def set_enabled(self, enabled: bool) -> bool:
        with self._lock:
            self._enabled = bool(enabled)
            self._save_config()
            return self._enabled

    def toggle(self) -> bool:
        with self._lock:
            self._enabled = not self._enabled
            self._save_config()
            new_state = self._enabled
        
        if new_state:
            self.speak("AI Voice Sentinel activated. Audio telemetry online.")
        else:
            self.stop()
        return new_state

    def set_bridge_window(self, window):
        """Attaches WebView2 window reference for browser-based speech synthesis dispatch."""
        self._bridge_window = window

    def _ensure_worker(self) -> Optional[subprocess.Popen]:
        """Spawns or retrieves the persistent PowerShell speech worker."""
        if sys.platform != "win32":
            return None

        if self._proc is not None and self._proc.poll() is None:
            return self._proc

        try:
            dollar = chr(36)
            ps_script = (
                f"Add-Type -AssemblyName System.Speech; "
                f"{dollar}s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"{dollar}s.Rate = 1; "
                f"{dollar}s.Volume = 95; "
                f"while ({dollar}line = [Console]::In.ReadLine()) {{ "
                f"if ({dollar}line -eq '__EXIT__') {{ break }}; "
                f"try {{ {dollar}s.Speak({dollar}line) | Out-Null; }} catch {{}}; "
                f"}}"
            )

            creationflags = 0
            if hasattr(subprocess, "CREATE_NO_WINDOW"):
                creationflags = subprocess.CREATE_NO_WINDOW

            self._proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                creationflags=creationflags
            )
            return self._proc
        except Exception as e:
            logger.debug(f"Speech worker spawn notice: {e}")
            return None

    def speak(self, text: str, force: bool = False) -> bool:
        """
        Asynchronously speaks the given text via Windows SAPI and UI bridge.
        """
        if not text:
            return False

        if not self._enabled and not force:
            return False

        # Suppress speech during Gaming / Silent Mode
        try:
            from src.core.notifications import gaming_mode_manager
            if gaming_mode_manager.is_active and not force:
                return False
        except Exception:
            pass

        cleaned_text = text.replace('"', '').replace("'", "").replace("\n", " ").strip()
        if not cleaned_text:
            return False

        logger.info(f"[VOICE SENTINEL] Speaking: \"{cleaned_text}\"")

        # 1. Dispatch to UI if active
        if self._bridge_window:
            try:
                js_code = (
                    f"if (window.app && typeof window.app.speak === 'function') {{ "
                    f"window.app.speak({json.dumps(cleaned_text)}); "
                    f"}}"
                )
                self._bridge_window.evaluate_js(js_code)
            except Exception:
                pass

        # 2. Native Windows Speech worker (asynchronous background execution)
        def _speak_thread():
            with self._lock:
                try:
                    worker = self._ensure_worker()
                    if worker and worker.stdin:
                        worker.stdin.write(cleaned_text + "\n")
                        worker.stdin.flush()
                except Exception as ex:
                    logger.debug(f"Native speech dispatch notice: {ex}")
                    # If worker died, reset so next call restarts
                    self._proc = None

        threading.Thread(target=_speak_thread, daemon=True, name="VoiceSpeechWorker").start()
        return True

    def stop(self):
        """Stops current speech and terminates worker."""
        with self._lock:
            if self._proc and self._proc.poll() is None:
                try:
                    self._proc.stdin.write("__EXIT__\n")
                    self._proc.stdin.flush()
                    self._proc.terminate()
                except Exception:
                    pass
                self._proc = None

    # --- Pre-configured Security Voice Events ---

    def speak_welcome(self):
        """Spoken when XSHEILD launches and enters active protection."""
        self.speak("Welcome back, Commander. XSHEILD Neural Defense Matrix is active and protecting your system.")

    def speak_usb_detected(self, drive_letter: str = ""):
        """Spoken when a removable USB drive is physically inserted."""
        drv = f"on drive {drive_letter}" if drive_letter else ""
        self.speak(f"External storage drive detected {drv}. XSHEILD Sentinel is inspecting the drive for threats.")

    def speak_usb_clean(self, drive_letter: str = ""):
        """Spoken when USB drive scan finishes with 0 threats."""
        drv = f"on drive {drive_letter}" if drive_letter else ""
        self.speak(f"External drive {drv} is 100 percent clean and safe to use.")

    def speak_usb_threat(self, drive_letter: str = "", count: int = 1):
        """Spoken when threats on USB drive are intercepted."""
        drv = f"on drive {drive_letter}" if drive_letter else ""
        plural = "threats" if count > 1 else "threat"
        self.speak(f"Security warning! {count} {plural} detected {drv} and neutralized to quarantine.")

    def speak_threat_intercepted(self, threat_name: str = "Malware"):
        """Spoken when real-time protection intercepts a malicious payload."""
        cleaned = threat_name.replace(".exe", "").replace(".dll", "").replace("_", " ")[:30]
        self.speak(f"Security alert! Threat {cleaned} intercepted and neutralized by XSHEILD Neural Defense.")

    def speak_scan_started(self, scan_type: str = "Quick"):
        """Spoken when a scan begins."""
        self.speak(f"Initiating {scan_type.lower()} security scan.")

    def speak_scan_completed(self, threats_found: int = 0):
        """Spoken when a manual or scheduled scan finishes."""
        if threats_found == 0:
            self.speak("Security scan completed. Endpoint integrity nominal. Zero threats detected.")
        else:
            plural = "threats" if threats_found > 1 else "threat"
            self.speak(f"Security alert! Scan completed with {threats_found} {plural} intercepted and quarantined.")

    def speak_shield_armed(self):
        """Spoken when kernel shields are refreshed."""
        self.speak("14 Kernel Defense Shields armed and operational.")


# Global singleton voice assistant
voice_assistant = VoiceAssistant()
