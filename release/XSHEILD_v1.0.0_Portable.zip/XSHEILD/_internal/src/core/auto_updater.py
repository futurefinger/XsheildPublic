"""
XSHEILD Silent Background Threat Intelligence Auto-Updater
Owner: Future Finger Technologies

Runs as a lightweight background daemon:
1. Periodically checks for signed definition packages (default: every 4 hours).
2. Verifies HMAC-SHA256 authenticity prior to ingestion.
3. Automatically updates local dynamic signature cache without user interruption.
4. Emits native Windows Action Center notifications upon successful database updates.
"""

import os
import time
import logging
import threading
from typing import Optional, Dict, Any

from src.core.threat_updater import threat_intel_manager
from src.core.notifications import send_windows_notification

logger = logging.getLogger("xsheild.auto_updater")

DEFAULT_CHECK_INTERVAL_SECONDS = 14400  # 4 Hours


class AutoUpdateDaemon:
    """
    Background worker that keeps threat definitions synchronized with cloud updates.
    """

    def __init__(
        self,
        check_interval_seconds: int = DEFAULT_CHECK_INTERVAL_SECONDS,
        cloud_server_url: Optional[str] = None
    ):
        self.interval = check_interval_seconds
        self.cloud_server_url = cloud_server_url or os.environ.get("XSHEILD_UPDATE_SERVER", "http://127.0.0.1:8000")
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None
        self.last_check_time: Optional[float] = None
        self.last_update_status: str = "Initialized"

    def start(self) -> None:
        """Starts the background auto-updater thread."""
        if self._worker_thread and self._worker_thread.is_alive():
            logger.info("Auto-updater daemon is already running.")
            return

        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._run_loop,
            name="XSheild-AutoUpdater",
            daemon=True
        )
        self._worker_thread.start()
        logger.info(f"Auto-updater daemon started (Interval: {self.interval}s, Server: {self.cloud_server_url})")

    def stop(self, timeout: float = 2.0) -> None:
        """Stops the background auto-updater thread cleanly."""
        self._stop_event.set()
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=timeout)
        logger.info("Auto-updater daemon stopped.")

    def check_now(self) -> Dict[str, Any]:
        """Performs an immediate definition check and auto-apply."""
        self.last_check_time = time.time()
        prev_version = threat_intel_manager.current_version
        prev_sigs = threat_intel_manager.get_total_signatures_count()

        result = threat_intel_manager.check_for_updates(
            cloud_api_url=self.cloud_server_url,
            auto_apply=True
        )

        curr_version = result.get("current_version", prev_version)
        curr_sigs = result.get("total_signatures", prev_sigs)

        if curr_version != prev_version or curr_sigs > prev_sigs:
            msg = f"XSHEILD Threat Intelligence updated to {curr_version} ({curr_sigs} signatures active)."
            self.last_update_status = msg
            logger.info(msg)
            try:
                send_windows_notification(
                    title="XSHEILD Security Update",
                    message=msg
                )
            except Exception as e:
                logger.debug(f"Toast notification skipped: {e}")
        else:
            self.last_update_status = result.get("status", "Up to date")

        return result

    def _run_loop(self) -> None:
        """Daemon execution loop with interruptible sleep."""
        # Initial check shortly after launch (10s delay to allow app to finish initial render)
        if not self._stop_event.wait(timeout=10.0):
            try:
                self.check_now()
            except Exception as e:
                logger.warning(f"Initial definition check error: {e}")

        while not self._stop_event.is_set():
            if self._stop_event.wait(timeout=self.interval):
                break
            try:
                self.check_now()
            except Exception as e:
                logger.warning(f"Periodic definition check error: {e}")


# Global daemon instance
auto_update_daemon = AutoUpdateDaemon()
