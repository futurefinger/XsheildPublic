"""
XSHEILD Scan Cache
Owner: Future Finger Technologies
High-performance clean file cache to eliminate redundant disk I/O on unchanged benign system files.
"""

import os
import threading
from typing import Optional, Dict, Tuple
from collections import OrderedDict


class ScanCache:
    """Thread-safe LRU clean-file cache keyed by (canonical_path, file_size, mtime)."""

    def __init__(self, max_entries: int = 50000):
        self._max_entries = max_entries
        self._lock = threading.Lock()
        # Key: (canonical_path, size, mtime) -> Value: (sha256, timestamp)
        self._cache: OrderedDict[Tuple[str, int, float], Tuple[str, float]] = OrderedDict()

    def get(self, file_path: str) -> Optional[str]:
        """Returns cached SHA-256 if file has not been modified; otherwise None."""
        try:
            stat = os.stat(file_path)
            key = (os.path.abspath(file_path).lower(), stat.st_size, stat.st_mtime)
        except OSError:
            return None

        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
                return self._cache[key][0]
        return None

    def put(self, file_path: str, sha256: str) -> None:
        """Stores clean file metadata in cache."""
        try:
            stat = os.stat(file_path)
            key = (os.path.abspath(file_path).lower(), stat.st_size, stat.st_mtime)
        except OSError:
            return

        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            else:
                if len(self._cache) >= self._max_entries:
                    self._cache.popitem(last=False)  # Evict oldest entry
            self._cache[key] = (sha256, stat.st_mtime)

    def invalidate(self, file_path: str) -> None:
        """Removes an entry from cache if modified or deleted."""
        abs_path = os.path.abspath(file_path).lower()
        with self._lock:
            keys_to_remove = [k for k in self._cache.keys() if k[0] == abs_path]
            for k in keys_to_remove:
                del self._cache[k]

    def clear(self) -> None:
        """Clears all cached clean verdicts."""
        with self._lock:
            self._cache.clear()

    def size(self) -> int:
        with self._lock:
            return len(self._cache)
