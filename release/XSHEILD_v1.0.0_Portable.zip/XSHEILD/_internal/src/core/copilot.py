"""
XSHEILD AI Security Copilot Engine
Owner: Future Finger Technologies
Provides on-device natural language security guidance, incident summarization,
and telemetry-backed remediation recommendations without cloud exfiltration.
"""

import os
import sys
import re
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from src.core.logger import get_logger

logger = get_logger("core.copilot")


@dataclass
class CopilotResponse:
    query: str
    intent: str
    summary: str
    detailed_findings: List[str]
    recommended_actions: List[str]
    system_safety_score: int
    is_actionable: bool
    requires_authorization: bool


class AISecurityCopilot:
    """
    On-device AI assistant providing plain-language explanations of technical findings,
    system performance issues, and threat incidents.
    """

    def __init__(self):
        self.is_active = True

    def process_query(self, user_query: str) -> CopilotResponse:
        """Processes user natural language query and generates context-aware guidance."""
        q = user_query.strip().lower()

        # 1. System Safety Audit / "Is my computer safe?"
        if any(phrase in q for phrase in ["safe", "security status", "am i protected", "is my pc safe", "hack", "virus"]):
            return self._handle_safety_query(user_query)

        # 2. Performance Query / "Why is my computer slow?"
        if any(phrase in q for phrase in ["slow", "lag", "performance", "speed", "freeze", "cpu", "ram"]):
            return self._handle_performance_query(user_query)

        # 3. Ransomware & Attack Query / "What happened during the last attack?"
        if any(phrase in q for phrase in ["attack", "ransomware", "incident", "threat detected", "canary"]):
            return self._handle_attack_query(user_query)

        # 4. Quarantine Query / "Why was this file quarantined?"
        if any(phrase in q for phrase in ["quarantine", "vault", "isolated", "false positive", "restore file"]):
            return self._handle_quarantine_query(user_query)

        # 5. Security Improvement Advice / "How can I improve my PC security?"
        if any(phrase in q for phrase in ["improve", "harden", "recommendation", "settings", "tips", "better"]):
            return self._handle_improvement_query(user_query)

        # Default Fallback Guidance
        return self._handle_general_query(user_query)

    def _handle_safety_query(self, query: str) -> CopilotResponse:
        from src.core.ransomware_shield import ransomware_shield
        from src.core.vulnerability_scanner import vulnerability_scanner
        from src.core.quarantine import QuarantineManager

        q_mgr = QuarantineManager()
        items = q_mgr.list_items()
        vuln = vulnerability_scanner.run_full_vulnerability_audit()

        threats_count = len(items)
        canaries_secure = not ransomware_shield.emergency_mode
        vuln_score = vuln["overall_security_score"]

        findings = [
            f"Real-Time File & Process Surveillance: ACTIVE",
            f"Decoy Canary Honeypots: {'100% SECURE' if canaries_secure else 'BREACH ALERT'}",
            f"Quarantine Vault: {threats_count} threats safely neutralized",
            f"OS Hardening Score: {vuln_score}/100"
        ]

        actions = []
        if vuln["vulnerabilities_detected"] > 0:
            actions.append(f"Remediate {vuln['vulnerabilities_detected']} OS configuration findings in Vulnerability Scanner.")
        else:
            actions.append("Keep real-time protection and automatic threat definitions enabled.")

        summary = (
            "Your PC is currently protected by XSHEILD. Real-time file ingress surveillance is active, "
            "and canary integrity traps are armed." if canaries_secure else
            "WARNING: A canary integrity breach or ransomware attempt was recently flagged! Please review the Ransomware log."
        )

        return CopilotResponse(
            query=query,
            intent="SYSTEM_SAFETY_AUDIT",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=vuln_score,
            is_actionable=True,
            requires_authorization=False
        )

    def _handle_performance_query(self, query: str) -> CopilotResponse:
        from src.core.system_cleaner import system_cleaner

        cleaner_analysis = system_cleaner.analyze()
        total_formatted = cleaner_analysis.get("total_formatted", "0 MB")
        total_files = cleaner_analysis.get("total_files", 0)

        findings = [
            f"Reclaimable System & Application Junk: {total_formatted}",
            f"Junk Files Identified: {total_files} items across temp and prefetch caches",
            "Hardware Metrics: Kernel memory and process load within expected operating thresholds"
        ]

        actions = [
            "Run 1-Click System Cleaner to safely purge cached temp files and unneeded crash dumps.",
            "Verify startup items in Startup & Persistence tab to disable unneeded autostart software."
        ]

        summary = (
            f"Your computer has {total_formatted} of safe-to-clean junk files and cache bloat. "
            f"Cleaning these caches will free disk space and reduce filesystem latency."
        )

        return CopilotResponse(
            query=query,
            intent="SYSTEM_PERFORMANCE",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=85,
            is_actionable=True,
            requires_authorization=True  # Destructive action requires approval
        )

    def _handle_attack_query(self, query: str) -> CopilotResponse:
        from src.core.ransomware_shield import ransomware_shield

        incidents = ransomware_shield.get_incident_history()
        findings = []
        if incidents:
            latest = incidents[0]
            summary = f"Recent incident detected: {latest.get('threat_category', 'Threat')} targeting {latest.get('target_path', 'unknown')}."
            findings.append(f"Incident Time: {latest.get('detected_at')}")
            findings.append(f"Category: {latest.get('threat_category')}")
            findings.append(f"Action Taken: {latest.get('action_taken')}")
            findings.append(f"Description: {latest.get('description')}")
        else:
            summary = "No ransomware attacks or canary integrity breaches have occurred on this PC."
            findings.append("Canary decoys in Documents, Desktop, and AppData are intact.")
            findings.append("Zero suspicious mass file rename or encryption bursts recorded.")

        actions = [
            "Ensure Volume Shadow Copy shield remains active.",
            "Maintain external offsite backups of critical business data."
        ]

        return CopilotResponse(
            query=query,
            intent="ATTACK_INVESTIGATION",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=95 if not incidents else 60,
            is_actionable=False,
            requires_authorization=False
        )

    def _handle_quarantine_query(self, query: str) -> CopilotResponse:
        from src.core.quarantine import QuarantineManager

        q_mgr = QuarantineManager()
        items = q_mgr.list_items()

        findings = []
        if items:
            summary = f"There are currently {len(items)} items isolated in the AES-256-GCM encrypted Quarantine Vault."
            for it in items[:3]:
                findings.append(f"Item: {it.original_filename} - Detection: {it.detection_name} ({it.detection_category.value})")
        else:
            summary = "Your Quarantine Vault is currently empty. No isolated malware files."
            findings.append("All scanned filesystem targets were either verified clean or not requiring isolation.")

        actions = [
            "Review quarantined items before restoration to prevent accidental re-infection.",
            "Items can be permanently purged from the Quarantine tab with zero residual traces."
        ]

        return CopilotResponse(
            query=query,
            intent="QUARANTINE_EXPLANATION",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=90,
            is_actionable=True,
            requires_authorization=True
        )

    def _handle_improvement_query(self, query: str) -> CopilotResponse:
        from src.core.vulnerability_scanner import vulnerability_scanner

        audit = vulnerability_scanner.run_full_vulnerability_audit()
        vulns = audit.get("vulnerable_items", [])

        findings = [
            f"Current Hardening Score: {audit['overall_security_score']}/100",
            f"Vulnerabilities Requiring Attention: {len(vulns)}"
        ]
        actions = []
        for v in vulns:
            actions.append(f"[{v['title']}]: {v['remediation_advice']}")

        if not actions:
            actions.append("All baseline security settings (UAC, SMBv1, Firewall) conform to CIS recommendations.")

        summary = f"Your PC has a security posture score of {audit['overall_security_score']}/100. Follow the recommendations below to achieve maximum hardening."

        return CopilotResponse(
            query=query,
            intent="SECURITY_IMPROVEMENT",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=audit["overall_security_score"],
            is_actionable=True,
            requires_authorization=False
        )

    def _handle_general_query(self, query: str) -> CopilotResponse:
        summary = (
            "I am XSHEILD AI Security Copilot. I can inspect your real-time protection, explain quarantined threats, "
            "diagnose system performance bottlenecks, and recommend security hardening steps."
        )
        findings = [
            "Ask: 'Is my computer safe?'",
            "Ask: 'Why is my computer slow?'",
            "Ask: 'What happened during the last attack?'",
            "Ask: 'How can I improve my PC security?'"
        ]
        actions = ["Select a suggested query above or type your technical question."]

        return CopilotResponse(
            query=query,
            intent="GENERAL_ASSISTANCE",
            summary=summary,
            detailed_findings=findings,
            recommended_actions=actions,
            system_safety_score=95,
            is_actionable=False,
            requires_authorization=False
        )


# Global copilot instance
ai_copilot = AISecurityCopilot()
