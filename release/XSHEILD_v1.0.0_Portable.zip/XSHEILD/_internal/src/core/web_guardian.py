"""
XSHEILD Web Guardian & Phishing Defense Engine
Owner: Future Finger Technologies
Provides real-time URL reputation analysis, phishing/typosquatting heuristics,
browser extension auditing, and deceptive attachment analysis.
"""

import os
import re
import math
import json
import urllib.parse
from typing import Dict, List, Optional, Set, Any, Tuple
from dataclasses import dataclass, asdict

from src.core.logger import get_logger

logger = get_logger("core.web_guardian")

# High-risk TLDs disproportionately used in phishing and malware campaigns
SUSPICIOUS_TLDS: Set[str] = {
    ".tk", ".ml", ".ga", ".cf", ".gq", ".top", ".xyz", ".work",
    ".click", ".buzz", ".monster", ".racing", ".fit", ".rest",
    ".zip", ".mov", ".kim", ".cam", ".live", ".country", ".gdn", ".stream"
}

# Protected commercial & banking brands targeted by phishing
TARGETED_BRANDS: List[str] = [
    "paypal", "microsoft", "google", "apple", "amazon", "netflix",
    "razorpay", "sbi", "hdfc", "icici", "chase", "wellsfargo",
    "bankofamerica", "binance", "coinbase", "futurefinger", "xsheild",
    "paytm", "phonepe", "metamask"
]

# Cyrillic & Greek homoglyphs visually indistinguishable from Latin characters
HOMOGLYPH_MAP: Dict[str, str] = {
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c",
    "\u0443": "y", "\u0445": "x", "\u0456": "i", "\u03bf": "o", "\u03bd": "v",
    "\u03c1": "p", "\u0455": "s", "\u0458": "j"
}

# Deceptive dual extensions commonly used in malicious attachments
DECEPTIVE_EXTENSIONS: List[str] = [
    ".pdf.exe", ".docx.exe", ".xlsx.exe", ".jpg.exe", ".pdf.scr",
    ".doc.vbs", ".pdf.hta", ".xlsx.js", ".zip.exe", ".rar.exe"
]


@dataclass
class URLVerdict:
    url: str
    domain: str
    is_malicious: bool
    risk_score: int  # 0 to 100
    risk_category: str
    reasons: List[str]


@dataclass
class BrowserExtensionFinding:
    browser: str
    extension_id: str
    name: str
    version: str
    is_suspicious: bool
    suspicious_permissions: List[str]
    manifest_path: str


class WebGuardianEngine:
    """
    Analyzes URLs, phishing traits, browser extensions, and deceptive email attachments.
    """

    def __init__(self):
        self.is_active = True

    def detect_homoglyph_spoofing(self, hostname: str) -> Tuple[bool, Optional[str]]:
        """
        Detects IDN / Punycode and Unicode homoglyph attacks where non-Latin characters
        visually mimic authentic brand domains (e.g., Cyrillic 'а' replacing Latin 'a').
        """
        # 1. Punycode encoded domain
        if "xn--" in hostname:
            try:
                decoded = hostname.encode("ascii").decode("idna")
                return True, f"Punycode encoded domain ({hostname} -> {decoded}) disguising non-ASCII glyphs"
            except Exception:
                return True, f"Malformed Punycode domain detected: {hostname}"

        # 2. Check for visual homoglyphs
        has_homoglyph = False
        normalized_chars = []
        for char in hostname:
            if char in HOMOGLYPH_MAP:
                has_homoglyph = True
                normalized_chars.append(HOMOGLYPH_MAP[char])
            else:
                normalized_chars.append(char)

        if has_homoglyph:
            normalized_domain = "".join(normalized_chars)
            for brand in TARGETED_BRANDS:
                if brand in normalized_domain:
                    return True, f"Homoglyph spoofing detected: '{hostname}' visually counterfeits protected brand '{brand}'"
            return True, f"Suspicious mixed-script homoglyphs detected in hostname: '{hostname}'"

        return False, None

    def calculate_domain_entropy(self, domain_label: str) -> float:
        """Calculates Shannon entropy of domain label to detect DGA algorithms."""
        if not domain_label:
            return 0.0
        prob = [float(domain_label.count(c)) / len(domain_label) for c in set(domain_label)]
        return -sum(p * math.log2(p) for p in prob)

    def analyze_url(self, url: str) -> URLVerdict:
        """
        Evaluates a URL against deterministic phishing heuristics:
        Punycode/homoglyphs, Shannon entropy (DGA), IP hostnames, brand typosquatting,
        deceptive subdomains, credential harvesting paths, and suspicious TLDs.
        """
        reasons = []
        risk_score = 0
        category = "BENIGN"

        try:
            parsed = urllib.parse.urlparse(url if "://" in url else "http://" + url)
            hostname = (parsed.hostname or "").lower()
            path = parsed.path.lower()
            raw_query = parsed.query.lower()
        except Exception:
            return URLVerdict(
                url=url, domain="INVALID", is_malicious=True,
                risk_score=90, risk_category="MALFORMED_URL",
                reasons=["URL could not be parsed securely"]
            )

        if not hostname:
            return URLVerdict(
                url=url, domain="", is_malicious=False,
                risk_score=0, risk_category="BENIGN", reasons=[]
            )

        # 1. Homoglyph / Punycode spoofing check (Critical Zero-Day Phishing Vector)
        is_homoglyph, homo_reason = self.detect_homoglyph_spoofing(hostname)
        if is_homoglyph and homo_reason:
            risk_score += 70
            reasons.append(homo_reason)

        # 2. Shannon Entropy & DGA Detection
        labels = hostname.split(".")
        main_label = labels[-2] if len(labels) >= 2 else labels[0]
        if len(main_label) >= 10:
            entropy = self.calculate_domain_entropy(main_label)
            if entropy >= 3.65:
                risk_score += 40
                reasons.append(f"High domain entropy ({entropy:.2f}) indicates automated DGA (Domain Generation Algorithm)")

        # 3. Check if raw IP is used as hostname
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", hostname):
            risk_score += 45
            reasons.append(f"Host uses raw numeric IP address ({hostname}) rather than registered domain name")

        # 4. Check for suspicious TLDs
        for tld in SUSPICIOUS_TLDS:
            if hostname.endswith(tld):
                risk_score += 30
                reasons.append(f"Domain uses high-abuse top-level domain ({tld})")
                break

        # 5. Check for brand impersonation / typosquatting in domain or subdomain
        for brand in TARGETED_BRANDS:
            if brand in hostname:
                legit_suffixes = (f"{brand}.com", f"{brand}.net", f"{brand}.org", f"{brand}.co.in", f"{brand}.in")
                is_legit = any(hostname == s or hostname.endswith("." + s) for s in legit_suffixes)
                if not is_legit:
                    risk_score += 55
                    reasons.append(f"Potential phishing/typosquatting impersonating '{brand}' in host '{hostname}'")

        # 6. Check excessive subdomain depth
        subdomain_parts = hostname.split(".")
        if len(subdomain_parts) > 4:
            risk_score += 25
            reasons.append(f"Excessive subdomain depth ({len(subdomain_parts)} levels) indicative of phishing evasion")

        # 7. Check credential embedding in URL authority
        if parsed.username or parsed.password:
            risk_score += 60
            reasons.append("URL contains embedded credentials (@ symbol phishing trap)")

        # 8. Check credential, KYC, and banking harvesting paths
        phish_keywords = [
            "login", "signin", "verify-account", "update-password", "security-check",
            "billing-update", "aadhaar", "pancard", "kyc-update", "seed-phrase",
            "private-key", "netbanking", "card-cvv", "otp-verification"
        ]
        for kw in phish_keywords:
            if kw in path or kw in raw_query:
                if risk_score >= 25 or any(b in hostname for b in TARGETED_BRANDS):
                    risk_score += 35
                    reasons.append(f"Sensitive credential/financial harvesting keyword detected: '{kw}'")
                    break

        risk_score = min(100, risk_score)
        is_malicious = risk_score >= 60

        if is_malicious:
            category = "PHISHING_OR_MALICIOUS"
        elif risk_score >= 30:
            category = "SUSPICIOUS"

        return URLVerdict(
            url=url,
            domain=hostname,
            is_malicious=is_malicious,
            risk_score=risk_score,
            risk_category=category,
            reasons=reasons
        )

    def audit_browser_extensions(self) -> List[BrowserExtensionFinding]:
        """
        Audits Chrome and Edge extension directories for high-risk permissions
        (e.g., <all_urls> + cookies + webRequestBlocking).
        """
        findings: List[BrowserExtensionFinding] = []
        user_local = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))

        extension_roots = [
            ("Google Chrome", os.path.join(user_local, "Google", "Chrome", "User Data", "Default", "Extensions")),
            ("Microsoft Edge", os.path.join(user_local, "Microsoft", "Edge", "User Data", "Default", "Extensions"))
        ]

        DANGEROUS_PERMISSIONS = {
            "<all_urls>", "webRequest", "webRequestBlocking", "cookies",
            "debugger", "proxy", "nativeMessaging"
        }

        for browser_name, root_dir in extension_roots:
            if not os.path.exists(root_dir):
                continue

            try:
                for ext_id in os.listdir(root_dir):
                    ext_path = os.path.join(root_dir, ext_id)
                    if not os.path.isdir(ext_path):
                        continue

                    # Each extension folder contains version subfolders
                    for ver in os.listdir(ext_path):
                        ver_path = os.path.join(ext_path, ver)
                        manifest_p = os.path.join(ver_path, "manifest.json")
                        if os.path.exists(manifest_p):
                            try:
                                with open(manifest_p, "r", encoding="utf-8", errors="ignore") as mf:
                                    mdata = json.load(mf)
                                ext_name = mdata.get("name", ext_id)
                                ext_ver = mdata.get("version", ver)
                                permissions = set(mdata.get("permissions", []))

                                suspicious_perms = [p for p in permissions if p in DANGEROUS_PERMISSIONS]
                                is_susp = len(suspicious_perms) >= 2

                                findings.append(BrowserExtensionFinding(
                                    browser=browser_name,
                                    extension_id=ext_id,
                                    name=ext_name,
                                    version=ext_ver,
                                    is_suspicious=is_susp,
                                    suspicious_permissions=suspicious_perms,
                                    manifest_path=manifest_p
                                ))
                            except Exception:
                                pass
            except Exception as e:
                logger.debug(f"Error auditing {browser_name} extensions: {e}")

        return findings

    def check_attachment_filename(self, filename: str) -> Dict[str, Any]:
        """Checks if an email attachment uses deceptive multi-extension techniques."""
        lower_name = filename.lower()
        for de in DECEPTIVE_EXTENSIONS:
            if lower_name.endswith(de):
                return {
                    "is_deceptive": True,
                    "pattern": de,
                    "reason": f"Deceptive multi-extension '{de}' disguises executable malware as standard media or document."
                }
        return {"is_deceptive": False, "pattern": None, "reason": None}


# Global singleton
web_guardian = WebGuardianEngine()
