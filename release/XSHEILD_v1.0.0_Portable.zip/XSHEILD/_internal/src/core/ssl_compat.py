"""
XSHEILD SSL Compatibility & Resilience Layer
Owner: Future Finger Technologies

Ensures ssl.SSLContext initialization never fails due to missing environment-specific PEM files
(e.g., codex-rejected-cas.pem) in PyInstaller frozen environments or custom Windows deployments.
"""

import os
import sys

_patched = False

def patch_ssl_codex_compat():
    """Patches ssl.SSLContext.__new__ to safely handle missing codex-rejected-cas.pem."""
    global _patched
    if _patched:
        return
    _patched = True

    try:
        import ssl
        import _ssl

        orig_new = ssl.SSLContext.__new__

        def safe_ssl_context_new(cls, protocol=None, *args, **kwargs):
            if protocol is None:
                protocol = ssl.PROTOCOL_TLS
            try:
                return orig_new(cls, protocol, *args, **kwargs)
            except (FileNotFoundError, OSError):
                # Fallback: create pure C _SSLContext if codex-rejected-cas.pem is not found on disk
                self = _ssl._SSLContext.__new__(cls, protocol)
                candidates = [
                    os.path.join(getattr(sys, "_MEIPASS", ""), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(getattr(ssl, "__file__", "")), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(sys.executable), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(sys.executable), "_internal", "codex-rejected-cas.pem"),
                ]
                for p in candidates:
                    if p and os.path.isfile(p):
                        try:
                            _ssl._SSLContext.load_verify_locations(self, cafile=p)
                            break
                        except Exception:
                            pass
                return self

        ssl.SSLContext.__new__ = safe_ssl_context_new
    except Exception:
        pass

# Automatically patch on import
patch_ssl_codex_compat()
