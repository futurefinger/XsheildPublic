"""
XSHEILD SSL Compatibility, Self-Healing & Resilience Layer
Owner: Future Finger Technologies

Ensures:
1. ssl.SSLContext initialization never fails due to missing environment-specific PEM files
   (e.g., codex-rejected-cas.pem) in PyInstaller frozen environments or custom Windows deployments.
2. Self-heals corrupted or 0-byte _ssl.pyd / libssl DLLs from existing backup snapshots.
3. Provides a zero-crash resilient fallback SSL shim if native SSL binaries are corrupted or locked,
   guaranteeing pywebview desktop UI and core services launch without unhandled Win32 DLL exceptions.
"""

import os
import sys
import glob
import shutil
import types
import logging

logger = logging.getLogger("ssl_compat")
_patched = False


def _attempt_binary_self_healing():
    """Detects and recovers 0-byte or corrupted SSL binaries in the frozen runtime directory."""
    if not getattr(sys, "frozen", False):
        return

    exe_dir = os.path.dirname(sys.executable)
    internal_dir = os.path.join(exe_dir, "_internal")
    candidates_dir = internal_dir if os.path.isdir(internal_dir) else exe_dir

    targets = ["_ssl.pyd", "libssl-3-x64.dll", "libcrypto-3-x64.dll"]
    for target in targets:
        target_path = os.path.join(candidates_dir, target)
        if os.path.isfile(target_path) and os.path.getsize(target_path) == 0:
            # File is corrupted (0 bytes). Search for valid .old_* backup or backup directories
            logger.warning(f"[SSL RECOVERY] Corrupted 0-byte file detected: {target_path}. Searching for backup...")
            pattern = os.path.join(candidates_dir, target + ".old_*")
            old_backups = sorted(glob.glob(pattern), reverse=True)
            recovered = False
            for b in old_backups:
                try:
                    if os.path.getsize(b) > 0:
                        shutil.copy2(b, target_path)
                        logger.info(f"[SSL RECOVERY] Successfully restored {target} from {b}")
                        recovered = True
                        break
                except Exception:
                    pass

            if not recovered:
                # Search in backup vault
                local_appdata = os.environ.get("LOCALAPPDATA", "")
                if local_appdata:
                    backup_glob = os.path.join(local_appdata, "XSHEILD", "Backups", "*", "_internal", target)
                    vault_backups = sorted(glob.glob(backup_glob), reverse=True)
                    for vb in vault_backups:
                        try:
                            if os.path.getsize(vb) > 0:
                                shutil.copy2(vb, target_path)
                                logger.info(f"[SSL RECOVERY] Successfully restored {target} from vault {vb}")
                                break
                        except Exception:
                            pass


def patch_ssl_codex_compat():
    """Patches ssl to safely handle missing certs and provides resilient fallback if _ssl is broken."""
    global _patched
    if _patched:
        return
    _patched = True

    # 1. Attempt binary self-healing if needed
    try:
        _attempt_binary_self_healing()
    except Exception:
        pass

    # 2. Attempt standard import
    try:
        import ssl
        import _ssl

        orig_new = ssl.SSLContext.__new__

        def safe_ssl_context_new(cls, protocol=None, *args, **kwargs):
            if protocol is None:
                protocol = getattr(ssl, "PROTOCOL_TLS", 2)
            try:
                return orig_new(cls, protocol, *args, **kwargs)
            except (FileNotFoundError, OSError):
                # Fallback: create pure C _SSLContext if codex-rejected-cas.pem is not found on disk
                self = _ssl._SSLContext.__new__(cls, protocol)
                candidates = [
                    os.path.join(getattr(sys, "_MEIPASS", ""), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(getattr(ssl, "__file__", "")), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(sys.executable), "codex-rejected-cas.pem"),
                    os.path.join(os.path.dirname(sys.executable), "_internal", "codex-rejected-cas.pem"),
                ]
                for p in candidates:
                    if p and os.path.isfile(p):
                        try:
                            _ssl._SSLContext.load_verify_locations(self, cafile=p)
                            break
                        except Exception:
                            pass
                return self

        ssl.SSLContext.__new__ = safe_ssl_context_new
    except (ImportError, OSError) as e:
        # 3. Resilient Fallback Shim: Prevent application crash when _ssl DLL is corrupted
        logger.warning(f"[SSL RESILIENCE] Native _ssl module unavailable ({e}). Initializing zero-crash SSL shim.")
        
        class DummySSLContext:
            def __init__(self, protocol=None, *args, **kwargs):
                self.protocol = protocol
                self.check_hostname = False
                self.verify_mode = 0
            def load_cert_chain(self, *args, **kwargs): pass
            def load_verify_locations(self, *args, **kwargs): pass
            def wrap_socket(self, sock, *args, **kwargs): return sock
            def set_ciphers(self, *args, **kwargs): pass
            def set_default_verify_paths(self): pass

        dummy_ssl = types.ModuleType("ssl")
        dummy_ssl.PROTOCOL_TLS = 2
        dummy_ssl.PROTOCOL_TLS_CLIENT = 16
        dummy_ssl.PROTOCOL_TLS_SERVER = 17
        dummy_ssl.PROTOCOL_SSLv23 = 2
        dummy_ssl.CERT_NONE = 0
        dummy_ssl.CERT_OPTIONAL = 1
        dummy_ssl.CERT_REQUIRED = 2
        dummy_ssl.SSLContext = DummySSLContext
        class SSLError(Exception): pass
        class CertificateError(ValueError): pass
        class SSLEOFError(SSLError): pass
        class SSLZeroReturnError(SSLError): pass
        class SSLWantReadError(SSLError): pass
        class SSLWantWriteError(SSLError): pass
        class SSLSyscallError(SSLError): pass
        dummy_ssl.SSLError = SSLError
        dummy_ssl.CertificateError = CertificateError
        dummy_ssl.SSLEOFError = SSLEOFError
        dummy_ssl.SSLZeroReturnError = SSLZeroReturnError
        dummy_ssl.SSLWantReadError = SSLWantReadError
        dummy_ssl.SSLWantWriteError = SSLWantWriteError
        dummy_ssl.SSLSyscallError = SSLSyscallError
        dummy_ssl.create_default_context = lambda *args, **kwargs: DummySSLContext()
        dummy_ssl._create_unverified_context = lambda *args, **kwargs: DummySSLContext()

        dummy_c_ssl = types.ModuleType("_ssl")
        dummy_c_ssl._SSLContext = DummySSLContext
        dummy_c_ssl.PROTOCOL_TLS = 2
        dummy_c_ssl.HAS_TLSv1_3 = False

        sys.modules["ssl"] = dummy_ssl
        sys.modules["_ssl"] = dummy_c_ssl


# Automatically patch on import
patch_ssl_codex_compat()
