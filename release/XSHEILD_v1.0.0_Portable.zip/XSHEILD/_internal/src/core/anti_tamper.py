"""
XSHEILD Anti-Tamper & Binary Integrity Guard
Owner: Future Finger Technologies
Defends XSHEILD against reverse engineering, memory tampering, unauthorized debugging,
process hooking (Frida/CheatEngine), and binary modification.
"""

import os
import sys
import hashlib
import logging
from typing import Dict, Any, List, Tuple, Optional

logger = logging.getLogger("XSHEILD.AntiTamper")

# Known reverse-engineering, disassembling, memory editing, and cracking tool executables
KNOWN_CRACKING_TOOLS = {
    "x64dbg.exe",
    "x32dbg.exe",
    "cheatengine-x86_64.exe",
    "cheatengine-i386.exe",
    "cheatengine.exe",
    "ida.exe",
    "ida64.exe",
    "ghidra.exe",
    "scylla.exe",
    "scylla_x64.exe",
    "scylla_x86.exe",
    "dnspy.exe",
    "de4dot.exe",
    "ilspy.exe",
    "httpdebuggerui.exe",
    "charles.exe",
    "fiddler.exe",
    "processhacker.exe",
}

# Suspicious DLL names injected by dynamic hooking frameworks
SUSPICIOUS_HOOK_DLLS = {
    "frida-agent.dll",
    "frida-gadget.dll",
    "scylla_hide.dll",
    "HookLibraryx64.dll",
    "HookLibraryx86.dll",
    "speedhack-x86_64.dll",
    "speedhack-i386.dll",
}


class AntiTamperGuard:
    """
    Multi-layered anti-tamper subsystem providing runtime integrity verification,
    debugger detection, and anti-hooking defense.
    """

    def __init__(self, enable_strict_mode: bool = False):
        self.enable_strict_mode = enable_strict_mode
        self._cached_binary_hash: Optional[str] = None

    def is_debugger_present(self) -> Tuple[bool, str]:
        """
        Detects if an active user-mode debugger is attached to the current process
        using Windows native kernel32 APIs.
        """
        if os.name != "nt":
            return False, "Non-Windows OS: native debugger checks skipped"

        try:
            import ctypes
            # 1. PEB BeingDebugged check via kernel32.IsDebuggerPresent()
            is_present = bool(ctypes.windll.kernel32.IsDebuggerPresent())
            if is_present:
                return True, "Active user-mode debugger detected via IsDebuggerPresent"

            # 2. CheckRemoteDebuggerPresent check (checks ProcessDebugPort)
            is_remote_present = ctypes.c_bool(False)
            h_proc = ctypes.windll.kernel32.GetCurrentProcess()
            if ctypes.windll.kernel32.CheckRemoteDebuggerPresent(h_proc, ctypes.byref(is_remote_present)):
                if is_remote_present.value:
                    return True, "Remote debugger attached detected via CheckRemoteDebuggerPresent"

            return False, "No debugger attached"
        except Exception as exc:
            logger.debug("Anti-tamper debugger probe exception: %s", exc)
            return False, f"Debugger probe error: {str(exc)}"

    def detect_cracking_tools(self) -> Tuple[bool, List[str]]:
        """
        Scans running system processes for active memory patchers, disassemblers,
        and reverse-engineering tools.
        """
        detected_tools: List[str] = []
        try:
            import psutil
            for proc in psutil.process_iter(attrs=["name"]):
                try:
                    pname = (proc.info.get("name") or "").lower()
                    if pname in KNOWN_CRACKING_TOOLS:
                        detected_tools.append(proc.info.get("name"))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as exc:
            logger.debug("Failed to scan processes for cracking tools: %s", exc)

        return (len(detected_tools) > 0, detected_tools)

    def detect_injected_hooks(self) -> Tuple[bool, List[str]]:
        """
        Checks loaded modules in the current process memory for known DLL hooks
        (Frida, CheatEngine speedhack, ScyllaHide).
        """
        detected_hooks: List[str] = []
        if os.name != "nt":
            return False, []

        try:
            import psutil
            current_proc = psutil.Process()
            # Inspect loaded memory maps / DLLs
            for m in current_proc.memory_maps():
                path = m.path or ""
                basename = os.path.basename(path).lower()
                for sus_dll in SUSPICIOUS_HOOK_DLLS:
                    if sus_dll.lower() in basename:
                        detected_hooks.append(basename)
        except Exception as exc:
            logger.debug("Memory maps hook check bypassed: %s", exc)

        return (len(detected_hooks) > 0, detected_hooks)

    def verify_binary_hash(self, file_path: Optional[str] = None, expected_hash: Optional[str] = None) -> Tuple[bool, str]:
        """
        Verifies SHA-256 integrity of the executable or target binary on disk.
        """
        target = file_path or sys.executable
        if not target or not os.path.isfile(target):
            return True, "Target binary path is not a file (likely running from interactive interpreter)"

        try:
            hasher = hashlib.sha256()
            with open(target, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            computed = hasher.hexdigest()
            self._cached_binary_hash = computed

            if expected_hash:
                if computed.lower() != expected_hash.lower():
                    return False, f"Binary integrity violation: SHA-256 {computed} does not match expected {expected_hash}"
                return True, "Binary integrity verified valid"

            return True, f"Binary SHA-256 calculated: {computed}"
        except Exception as exc:
            return False, f"Failed to compute binary integrity hash: {str(exc)}"

    def perform_full_tamper_audit(self) -> Dict[str, Any]:
        """
        Executes a comprehensive anti-tamper inspection and returns the security audit record.
        """
        is_debugged, debug_reason = self.is_debugger_present()
        tools_active, tools_list = self.detect_cracking_tools()
        hooks_active, hooks_list = self.detect_injected_hooks()

        tampered = is_debugged or hooks_active

        report = {
            "tampered": tampered,
            "debugger_present": is_debugged,
            "debugger_reason": debug_reason,
            "cracking_tools_detected": tools_list,
            "injected_hooks_detected": hooks_list,
            "strict_mode": self.enable_strict_mode,
            "status": "COMPROMISED" if tampered else ("WARNING" if tools_active else "SECURE")
        }

        if tampered:
            logger.warning("SECURITY ALERT: Application tampering detected! %s", report)

        return report
