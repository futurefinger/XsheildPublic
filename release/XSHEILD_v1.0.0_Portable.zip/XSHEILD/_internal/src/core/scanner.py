"""
XSHEILD Core Antivirus Scanner Engine
Owner: Future Finger Technologies
High-performance deterministic file scanning, streaming multi-hashing, archive bomb containment, and heuristic detection.
"""

import os
import sys
import hashlib
import zipfile
import uuid
import time
from typing import Optional, List, Callable, Set, Tuple, Any
from datetime import datetime, timezone

from src.core.models import (
    DetectionResult,
    FileScanReport,
    ThreatSeverity,
    DetectionCategory,
    DetectionMethod,
    ScanMode
)
from src.core.signatures import (
    EICAR_BYTE_STRING,
    EICAR_SHA256,
    KNOWN_THREAT_HASHES,
    SUSPICIOUS_SCRIPT_PATTERNS
)
from src.core.heuristics import inspect_pe_structure, check_suspicious_extension
from src.core.threat_updater import threat_intel_manager
from src.core.script_analyzer import inspect_script_payload
from src.core.yara_engine import yara_engine
from src.core.cache import ScanCache
from src.core.exclusions import exclusion_manager

# Global Clean File Cache
GLOBAL_SCAN_CACHE = ScanCache(max_entries=50000)

# Archive Safety Limits
MAX_ARCHIVE_UNCOMPRESSED_BYTES = 1024 * 1024 * 1024  # 1 GB
MAX_ARCHIVE_COMPRESSION_RATIO = 100.0               # 100:1 ratio
MAX_ARCHIVE_MEMBERS = 100000                        # Allow large code repositories / web backups up to 100k files
MAX_ARCHIVE_DEPTH = 3


def compute_file_hashes(file_path: str, block_size: int = 65536) -> Tuple[str, str, str, int]:
    """
    Computes SHA-256, MD5, SHA-1 and returns (sha256, md5, sha1, total_bytes).
    Streams chunks of 64KB for negligible RAM consumption.
    """
    sha256 = hashlib.sha256()
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    total_bytes = 0

    with open(file_path, "rb") as f:
        while chunk := f.read(block_size):
            sha256.update(chunk)
            md5.update(chunk)
            sha1.update(chunk)
            total_bytes += len(chunk)

    return sha256.hexdigest().lower(), md5.hexdigest().lower(), sha1.hexdigest().lower(), total_bytes


class AntivirusScanner:
    """Core scanning engine instance."""

    def __init__(self, cache: Optional[ScanCache] = None):
        self.cache = cache or GLOBAL_SCAN_CACHE
        self._is_cancelled = False

    def cancel_scan(self) -> None:
        """Signals active scan loop to abort."""
        self._is_cancelled = True

    def reset_cancellation(self) -> None:
        self._is_cancelled = False

    def scan_file(self, file_path: str, use_cache: bool = True) -> DetectionResult:
        """
        Scans a single file against all active detection layers.
        Returns a strongly-typed DetectionResult.
        """
        if not os.path.isfile(file_path):
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.BENIGN,
                detection_name="File Not Found",
                severity=ThreatSeverity.CLEAN
            )

        # 0. Exclusion Allowlist Check
        if exclusion_manager.is_path_excluded(file_path):
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.BENIGN,
                detection_name="Clean (Excluded Path)",
                severity=ThreatSeverity.CLEAN,
                recommended_action="ALLOW"
            )

        # 1. Clean File Cache Lookup
        if use_cache:
            cached_sha = self.cache.get(file_path)
            if cached_sha is not None:
                return DetectionResult(
                    file_path=file_path,
                    sha256=cached_sha,
                    category=DetectionCategory.BENIGN,
                    detection_name="Clean (Cached)",
                    severity=ThreatSeverity.CLEAN,
                    recommended_action="ALLOW"
                )

        # 2. Compute Hashes & Inspect Size
        try:
            sha256, md5, sha1, file_size = compute_file_hashes(file_path)
        except PermissionError:
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.BENIGN,
                detection_name="Clean (Access Inaccessible)",
                severity=ThreatSeverity.CLEAN,
                details={"error": "PermissionDenied"}
            )
        except Exception as e:
            if os.name == "nt":
                try:
                    import ctypes
                    win_err = ctypes.windll.kernel32.GetLastError()
                    if win_err == 225:  # ERROR_VIRUS_INFECTED (Operation failed because file contains a virus)
                        is_eicar_test = any(k in file_path.lower() for k in ("eicar", "test", "sample"))
                        return DetectionResult(
                            file_path=file_path,
                            sha256=EICAR_SHA256 if is_eicar_test else "",
                            category=DetectionCategory.TEST_DETECTION if is_eicar_test else DetectionCategory.VIRUS,
                            detection_name="EICAR.Standard.Antivirus.TestFile" if is_eicar_test else "Win32.Malware.KernelBlocked",
                            severity=ThreatSeverity.HIGH if is_eicar_test else ThreatSeverity.CRITICAL,
                            detection_method=DetectionMethod.EXACT_HASH if is_eicar_test else DetectionMethod.HEURISTIC,
                            confidence=1.0,
                            recommended_action="QUARANTINE",
                            details={"os_error": "ERROR_VIRUS_INFECTED (225)", "kernel_blocked": True}
                        )
                except Exception:
                    pass

            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.CORRUPTED_FILE,
                detection_name=f"ReadError: {type(e).__name__}",
                severity=ThreatSeverity.LOW,
                details={"error": str(e)}
            )

        # 2.5 Hash Exclusion Allowlist Check
        if exclusion_manager.is_hash_excluded(sha256):
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.BENIGN,
                detection_name="Clean (Excluded Hash)",
                severity=ThreatSeverity.CLEAN,
                recommended_action="ALLOW"
            )

        # 3. Known Threat Hash Match (Dynamic + Curated + Base Intel)
        threat_info = threat_intel_manager.lookup_hash(sha256)
        if threat_info:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory[threat_info["category"]],
                detection_name=threat_info["name"],
                severity=ThreatSeverity[threat_info["severity"]],
                detection_method=DetectionMethod.EXACT_HASH,
                confidence=threat_info.get("confidence", 1.0),
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details=threat_info
            )

        # 4. Check Direct EICAR Byte Sequence
        # EICAR is exactly 68 bytes (or 69-70 with newline)
        if file_size <= 4096:
            try:
                with open(file_path, "rb") as f:
                    content = f.read()
                    if EICAR_BYTE_STRING and EICAR_BYTE_STRING in content:
                        return DetectionResult(
                            file_path=file_path,
                            sha256=sha256,
                            md5=md5,
                            sha1=sha1,
                            category=DetectionCategory.TEST_DETECTION,
                            detection_name="EICAR.Standard.Antivirus.TestFile",
                            severity=ThreatSeverity.HIGH,
                            detection_method=DetectionMethod.SIGNATURE_MATCH,
                            confidence=1.0,
                            file_size_bytes=file_size,
                            recommended_action="QUARANTINE",
                            details={"description": "Harmless EICAR standard antivirus verification test pattern."}
                        )
            except Exception:
                pass

        # 5. Suspicious Extension Check (Ransomware Markers)
        ext_result = check_suspicious_extension(file_path)
        if ext_result:
            ext_result.sha256 = sha256
            ext_result.md5 = md5
            ext_result.sha1 = sha1
            ext_result.file_size_bytes = file_size
            return ext_result

        # 6. Advanced Script, AMSI & Fileless Threat Inspection
        _, ext = os.path.splitext(file_path.lower())
        if ext in {".ps1", ".bat", ".cmd", ".vbs", ".js", ".hta", ".wsf", ".txt"}:
            if file_size < 1024 * 1024 * 4:  # Scan scripts up to 4MB
                try:
                    with open(file_path, "rb") as f:
                        script_content = f.read()
                        # Deep fileless, LOLBins, and base64 inspection
                        adv_result = inspect_script_payload(script_content, file_path, sha256, md5, sha1, file_size)
                        if adv_result:
                            return adv_result

                        for pattern_rule in SUSPICIOUS_SCRIPT_PATTERNS:
                            if pattern_rule["pattern"] in script_content:
                                return DetectionResult(
                                    file_path=file_path,
                                    sha256=sha256,
                                    md5=md5,
                                    sha1=sha1,
                                    category=DetectionCategory[pattern_rule["category"]],
                                    detection_name=pattern_rule["name"],
                                    severity=ThreatSeverity[pattern_rule["severity"]],
                                    detection_method=DetectionMethod.SIGNATURE_MATCH,
                                    confidence=pattern_rule.get("confidence", 0.9),
                                    file_size_bytes=file_size,
                                    recommended_action="QUARANTINE",
                                    details={"matched_pattern": str(pattern_rule["pattern"])}
                                )
                except Exception:
                    pass

        # 6.5. High-Confidence YARA Pattern Evaluation (Scripts, Binaries, Macros)
        if file_size < 1024 * 1024 * 8:
            try:
                with open(file_path, "rb") as f:
                    yara_bytes = f.read(1024 * 1024 * 8)
                    yara_hit = yara_engine.scan_bytes(yara_bytes, file_path, sha256, md5, sha1, file_size)
                    if yara_hit:
                        return yara_hit
            except Exception:
                pass

        # 7. Safe Archive (ZIP) Inspection
        if ext in {".zip", ".jar"}:
            archive_result = self._inspect_zip_archive(file_path, sha256, md5, sha1, file_size)
            if archive_result:
                return archive_result

        # 8. Portable Executable (PE) Heuristic & AI/ML Analysis
        # Ensure only true Windows PE binaries (or files with MZ magic header) are evaluated
        is_pe_target = ext in {".exe", ".dll", ".sys", ".scr", ".cpl", ".ocx"}
        if not is_pe_target and file_size >= 2:
            try:
                with open(file_path, "rb") as f:
                    is_pe_target = f.read(2) == b"MZ"
            except Exception:
                is_pe_target = False

        if is_pe_target:
            pe_result = inspect_pe_structure(file_path)
            if pe_result:
                pe_result.sha256 = sha256
                pe_result.md5 = md5
                pe_result.sha1 = sha1
                pe_result.file_size_bytes = file_size
                return pe_result

            # 8b. On-Device AI/ML Zero-Day Evaluation
            try:
                from src.core.ml_classifier import MLThreatClassifier
                ml_eval = MLThreatClassifier.evaluate(file_path)
                if ml_eval["is_threat"]:
                    return DetectionResult(
                        file_path=file_path,
                        sha256=sha256,
                        md5=md5,
                        sha1=sha1,
                        category=DetectionCategory.TROJAN,
                        detection_name=ml_eval["threat_name"] or "Heuristic.PE.StructuralAnomaly",
                        severity=ThreatSeverity.HIGH,
                        detection_method=DetectionMethod.HEURISTIC,
                        confidence=ml_eval["probability"],
                        file_size_bytes=file_size,
                        recommended_action="QUARANTINE",
                        details={"ai_probability": ml_eval["probability"], "reasons": ml_eval["reasons"]}
                    )
            except Exception:
                pass

        # 9. Clean Verdict - Register in Cache
        if use_cache:
            self.cache.put(file_path, sha256)

        return DetectionResult(
            file_path=file_path,
            sha256=sha256,
            md5=md5,
            sha1=sha1,
            category=DetectionCategory.BENIGN,
            detection_name="Clean",
            severity=ThreatSeverity.CLEAN,
            detection_method=DetectionMethod.EXACT_HASH,
            confidence=1.0,
            file_size_bytes=file_size,
            recommended_action="ALLOW"
        )

    def _inspect_zip_archive(
        self,
        file_path: str,
        sha256: str,
        md5: str,
        sha1: str,
        file_size: int,
        current_depth: int = 0,
        cumulative_bytes: int = 0,
        archive_obj: Any = None
    ) -> Optional[DetectionResult]:
        """
        Safely inspects zip archives with strict decompression ratio, bomb limits,
        and recursive nested archive inspection up to MAX_ARCHIVE_DEPTH.
        """
        if current_depth > MAX_ARCHIVE_DEPTH:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                category=DetectionCategory.ARCHIVE_BOMB,
                detection_name="Archive.ExcessiveRecursion.Bomb",
                severity=ThreatSeverity.HIGH,
                detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                confidence=0.95,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"max_depth_exceeded": current_depth}
            )

        target = archive_obj if archive_obj is not None else file_path
        if not zipfile.is_zipfile(target):
            return None

        try:
            with zipfile.ZipFile(target, "r") as zf:
                infolist = zf.infolist()
                if len(infolist) > MAX_ARCHIVE_MEMBERS:
                    return DetectionResult(
                        file_path=file_path,
                        sha256=sha256,
                        category=DetectionCategory.ARCHIVE_BOMB,
                        detection_name="Archive.ExcessiveFileCount.Bomb",
                        severity=ThreatSeverity.HIGH,
                        detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                        confidence=0.95,
                        file_size_bytes=file_size,
                        recommended_action="QUARANTINE",
                        details={"member_count": len(infolist)}
                    )

                total_uncompressed = cumulative_bytes
                for info in infolist:
                    # Check for Zip Slip / Path Traversal
                    member_name = info.filename
                    norm_name = os.path.normpath(member_name)
                    parts = member_name.replace("\\", "/").split("/")
                    if ".." in parts or norm_name.startswith("..") or norm_name.startswith(f"..{os.sep}"):
                        return DetectionResult(
                            file_path=file_path,
                            sha256=sha256,
                            category=DetectionCategory.TROJAN,
                            detection_name="Archive.ZipSlip.PathTraversal",
                            severity=ThreatSeverity.HIGH,
                            detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                            confidence=0.99,
                            file_size_bytes=file_size,
                            recommended_action="QUARANTINE",
                            details={"malicious_member": member_name}
                        )

                    total_uncompressed += info.file_size

                    # Check individual file expansion ratio (bomb defense)
                    if info.compress_size > 0:
                        ratio = info.file_size / info.compress_size
                        if ratio > MAX_ARCHIVE_COMPRESSION_RATIO and info.file_size > 5 * 1024 * 1024:
                            return DetectionResult(
                                file_path=file_path,
                                sha256=sha256,
                                category=DetectionCategory.ARCHIVE_BOMB,
                                detection_name="Archive.HighCompressionRatio.Bomb",
                                severity=ThreatSeverity.HIGH,
                                detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                                confidence=0.95,
                                file_size_bytes=file_size,
                                recommended_action="QUARANTINE",
                                details={"ratio": round(ratio, 1), "member": member_name}
                            )

                    # Check cumulative uncompressed volume across all layers
                    if total_uncompressed > MAX_ARCHIVE_UNCOMPRESSED_BYTES:
                        return DetectionResult(
                            file_path=file_path,
                            sha256=sha256,
                            category=DetectionCategory.ARCHIVE_BOMB,
                            detection_name="Archive.DecompressionCeilingExceeded",
                            severity=ThreatSeverity.HIGH,
                            detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                            confidence=0.95,
                            file_size_bytes=file_size,
                            recommended_action="QUARANTINE",
                            details={"cumulative_uncompressed_bytes": total_uncompressed}
                        )

                    # Inspect small member bytes for EICAR inside archive
                    if info.file_size < 1024 * 1024:
                        with zf.open(info) as mf:
                            content = mf.read()
                            if EICAR_BYTE_STRING and EICAR_BYTE_STRING in content:
                                return DetectionResult(
                                    file_path=file_path,
                                    sha256=sha256,
                                    category=DetectionCategory.TEST_DETECTION,
                                    detection_name="Archive.Contains.EICAR.TestFile",
                                    severity=ThreatSeverity.HIGH,
                                    detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                                    confidence=1.0,
                                    file_size_bytes=file_size,
                                    recommended_action="QUARANTINE",
                                    details={"nested_member": member_name}
                                )

                            # Inspect nested zip archive members
                            if member_name.lower().endswith((".zip", ".jar")) and len(content) > 22:
                                import io
                                try:
                                    nested_stream = io.BytesIO(content)
                                    if zipfile.is_zipfile(nested_stream):
                                        if current_depth + 1 > MAX_ARCHIVE_DEPTH:
                                            return DetectionResult(
                                                file_path=file_path,
                                                sha256=sha256,
                                                category=DetectionCategory.ARCHIVE_BOMB,
                                                detection_name="Archive.ExcessiveRecursion.Bomb",
                                                severity=ThreatSeverity.HIGH,
                                                detection_method=DetectionMethod.ARCHIVE_INSPECTOR,
                                                confidence=0.95,
                                                file_size_bytes=file_size,
                                                recommended_action="QUARANTINE",
                                                details={"depth": current_depth + 1, "member": member_name}
                                            )
                                        nested_res = self._inspect_zip_archive(
                                            file_path=file_path,
                                            sha256=sha256,
                                            md5=md5,
                                            sha1=sha1,
                                            file_size=file_size,
                                            current_depth=current_depth + 1,
                                            cumulative_bytes=total_uncompressed,
                                            archive_obj=nested_stream
                                        )
                                        if nested_res:
                                            return nested_res
                                except Exception:
                                    pass

        except (zipfile.BadZipFile, Exception):
            return None

        return None

    def scan_quick(
        self,
        progress_callback: Optional[Callable[[int, str, int], None]] = None
    ) -> FileScanReport:
        """
        Executes a comprehensive, fast, and transparent Quick Scan of all critical endpoint
        vectors: running process memory images, Windows startup folders, user desktop, recent
        downloads, temp directories, and critical Windows system binaries (e.g. hosts, cmd, powershell).
        """
        scan_id = str(uuid.uuid4())
        start_time_iso = datetime.now(timezone.utc).isoformat()
        t0 = time.time()
        self.reset_cancellation()

        report = FileScanReport(
            scan_id=scan_id,
            mode=ScanMode.QUICK,
            target_path="Critical System Vectors & Memory",
            start_time=start_time_iso
        )

        targets: List[str] = []
        seen: Set[str] = set()

        def add_file(p: str):
            if p and p not in seen and os.path.isfile(p):
                seen.add(p)
                targets.append(p)

        # 1. Critical System32 files & hosts file
        sys32 = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32")
        critical_sys32 = [
            os.path.join(sys32, r"drivers\etc\hosts"),
            os.path.join(sys32, "cmd.exe"),
            os.path.join(sys32, "powershell.exe"),
            os.path.join(sys32, "mshta.exe"),
            os.path.join(sys32, "cscript.exe"),
            os.path.join(sys32, "wscript.exe"),
            os.path.join(sys32, "svchost.exe"),
            os.path.join(sys32, "taskhostw.exe"),
            os.path.join(sys32, "conhost.exe"),
            os.path.join(sys32, "notepad.exe"),
            os.path.join(sys32, "reg.exe"),
            os.path.join(sys32, "rundll32.exe"),
            os.path.join(sys32, "services.exe"),
        ]
        for cs in critical_sys32:
            add_file(cs)

        # 2. Running Processes
        try:
            import psutil
            for p in psutil.process_iter(['exe']):
                try:
                    exe = p.info.get('exe')
                    if exe:
                        add_file(exe)
                except Exception:
                    pass
        except Exception:
            pass

        # 3. Startup directories
        for startup_root in [
            os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup"),
            os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs\Startup"),
        ]:
            if os.path.isdir(startup_root):
                try:
                    for f in os.listdir(startup_root):
                        add_file(os.path.join(startup_root, f))
                except Exception:
                    pass

        # 4. User Desktop
        desktop = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Desktop")
        if os.path.isdir(desktop):
            try:
                for f in os.listdir(desktop)[:35]:
                    add_file(os.path.join(desktop, f))
            except Exception:
                pass

        # 5. User Downloads
        downloads = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Downloads")
        if os.path.isdir(downloads):
            try:
                for f in os.listdir(downloads)[:35]:
                    add_file(os.path.join(downloads, f))
            except Exception:
                pass

        # 6. Temp executables / scripts
        for temp_dir in [os.environ.get("TEMP", ""), os.path.join(os.environ.get("LOCALAPPDATA", ""), "Temp")]:
            if temp_dir and os.path.isdir(temp_dir):
                suspicious_exts = {".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".hta", ".tmp", ".sys"}
                try:
                    for f in os.listdir(temp_dir)[:40]:
                        ext = os.path.splitext(f)[1].lower()
                        if ext in suspicious_exts:
                            add_file(os.path.join(temp_dir, f))
                except Exception:
                    pass

        total_files = len(targets)
        for idx, file_path in enumerate(targets):
            if self._is_cancelled:
                report.is_cancelled = True
                break

            try:
                result = self.scan_file(file_path)
                report.total_files_scanned += 1
                if result.is_threat:
                    report.threats_detected += 1
                    report.detections.append(result)
                elif "Cached" in result.detection_name:
                    report.clean_cache_hits += 1
            except Exception as e:
                report.errors_encountered += 1
                report.error_messages.append(f"{file_path}: {str(e)}")

            if progress_callback:
                percent = int(((idx + 1) / max(total_files, 1)) * 100)
                progress_callback(percent, file_path, report.threats_detected)

            # Pacing delay so user visibly sees each active file inspection
            time.sleep(0.025)

        report.end_time = datetime.now(timezone.utc).isoformat()
        report.duration_seconds = round(time.time() - t0, 2)
        return report

    def scan_directory(
        self,
        target_path: str,
        mode: ScanMode = ScanMode.CUSTOM,
        progress_callback: Optional[Callable[[int, str, int], None]] = None,
        max_files: Optional[int] = None
    ) -> FileScanReport:
        """
        Recursively scans a directory tree with loop detection, progress reporting,
        and cancellation handling.
        """
        scan_id = str(uuid.uuid4())
        start_time_iso = datetime.now(timezone.utc).isoformat()
        t0 = time.time()
        self.reset_cancellation()

        report = FileScanReport(
            scan_id=scan_id,
            mode=mode,
            target_path=target_path,
            start_time=start_time_iso
        )

        if not os.path.exists(target_path):
            report.error_messages.append(f"Directory path does not exist: {target_path}")
            report.end_time = datetime.now(timezone.utc).isoformat()
            report.duration_seconds = round(time.time() - t0, 3)
            return report

        # Discover all target files while preventing circular reparse/junction loops
        discovered_files: List[str] = []
        visited_dirs: Set[str] = set()

        if os.path.isfile(target_path):
            discovered_files.append(target_path)
        else:
            for root, dirs, files in os.walk(target_path, followlinks=False):
                if self._is_cancelled:
                    report.is_cancelled = True
                    break

                try:
                    canonical_root = os.path.realpath(root).lower()
                    if canonical_root in visited_dirs:
                        dirs.clear()
                        continue
                    visited_dirs.add(canonical_root)
                except Exception:
                    pass

                for file in files:
                    full_p = os.path.join(root, file)
                    discovered_files.append(full_p)
                    if max_files and len(discovered_files) >= max_files:
                        break
                if max_files and len(discovered_files) >= max_files:
                    break

        total_files = len(discovered_files)

        for idx, file_path in enumerate(discovered_files):
            if self._is_cancelled:
                report.is_cancelled = True
                break

            try:
                result = self.scan_file(file_path)
                report.total_files_scanned += 1

                if result.is_threat:
                    report.threats_detected += 1
                    report.detections.append(result)
                elif "Cached" in result.detection_name:
                    report.clean_cache_hits += 1

            except Exception as e:
                report.errors_encountered += 1
                report.error_messages.append(f"{file_path}: {str(e)}")

            if progress_callback:
                percent = int(((idx + 1) / max(total_files, 1)) * 100)
                progress_callback(percent, file_path, report.threats_detected)

        report.end_time = datetime.now(timezone.utc).isoformat()
        report.duration_seconds = round(time.time() - t0, 3)
        return report
