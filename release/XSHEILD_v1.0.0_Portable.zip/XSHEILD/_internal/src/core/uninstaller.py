"""
XSHEILD Native Windows Uninstaller Service
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
Official Destination: futurefingerindia@gmail.com

Executes clean, complete removal of XSHEILD Endpoint Security:
- Removes Windows Startup registry entries (HKCU & HKLM)
- Removes Desktop and Start Menu shortcuts across Public and User profiles
- Removes Windows Control Panel (appwiz.cpl) and Apps & Features entries
- Self-deletes installed program files and binaries
"""

import os
import sys
import time
import winreg
import shutil
import subprocess
import ctypes


def _native_confirm_dialog(title: str, message: str) -> bool:
    """Shows a topmost, foreground modal confirmation dialog using native Win32 API."""
    MB_YESNO = 0x00000004
    MB_ICONWARNING = 0x00000030
    MB_TOPMOST = 0x00040000
    MB_SETFOREGROUND = 0x00010000
    IDYES = 6
    try:
        res = ctypes.windll.user32.MessageBoxW(0, message, title, MB_YESNO | MB_ICONWARNING | MB_TOPMOST | MB_SETFOREGROUND)
        return res == IDYES
    except Exception:
        return True


def _native_info_dialog(title: str, message: str) -> None:
    """Shows a topmost, foreground informational dialog using native Win32 API."""
    MB_OK = 0x00000000
    MB_ICONINFORMATION = 0x00000040
    MB_TOPMOST = 0x00040000
    MB_SETFOREGROUND = 0x00010000
    try:
        ctypes.windll.user32.MessageBoxW(0, message, title, MB_OK | MB_ICONINFORMATION | MB_TOPMOST | MB_SETFOREGROUND)
    except Exception:
        pass


def perform_uninstall(silent: bool = False) -> bool:
    """Executes full uninstallation workflow."""
    if not silent:
        confirm = _native_confirm_dialog(
            "Uninstall XSHEILD Endpoint Security",
            "Are you sure you want to completely remove XSHEILD Endpoint Security from this computer?\n\n"
            "Publisher: Future Finger Technologies\n"
            "This will remove real-time filesystem protection, startup surveillance, and all security shields."
        )
        if not confirm:
            return False

    # 1. Terminate other running XSHEILD processes
    current_pid = os.getpid()
    try:
        subprocess.run(
            ["taskkill", "/F", "/FI", f"PID ne {current_pid}", "/IM", "XSHEILD.exe"],
            capture_output=True,
            check=False
        )
    except Exception:
        pass

    # 2. Remove Windows Startup Registry Entries (HKCU and HKLM)
    for root_key, key_path in [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
    ]:
        try:
            with winreg.OpenKey(root_key, key_path, 0, winreg.KEY_SET_VALUE) as k:
                try:
                    winreg.DeleteValue(k, "XSHEILD")
                except (FileNotFoundError, OSError):
                    pass
        except Exception:
            pass

    # 3. Remove Windows Uninstall Registry Entries (HKCU and HKLM)
    for root_key, key_path in [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\XSHEILD"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\XSHEILD"),
    ]:
        for access in (0, getattr(winreg, "KEY_WOW64_64KEY", 0), getattr(winreg, "KEY_WOW64_32KEY", 0)):
            try:
                winreg.DeleteKeyEx(root_key, key_path, access)
            except Exception:
                try:
                    winreg.DeleteKey(root_key, key_path)
                except Exception:
                    pass

    # Guaranteed command-line reg deletion fallback
    for reg_target in [
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\XSHEILD",
        r"HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\XSHEILD",
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
        r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run",
    ]:
        try:
            if "Run" in reg_target:
                subprocess.run(["reg.exe", "delete", reg_target, "/v", "XSHEILD", "/f"], capture_output=True, check=False)
            else:
                subprocess.run(["reg.exe", "delete", reg_target, "/f"], capture_output=True, check=False)
        except Exception:
            pass

    # 4. Remove Desktop Shortcuts (Public Desktop and Current User Desktop)
    desktop_dirs = []
    public_desktop = os.environ.get("PUBLIC", r"C:\Users\Public")
    if public_desktop:
        desktop_dirs.append(os.path.join(public_desktop, "Desktop"))

    user_profile = os.environ.get("USERPROFILE", "")
    if user_profile:
        desktop_dirs.append(os.path.join(user_profile, "Desktop"))

    for d in desktop_dirs:
        for fname in ("XSHEILD.lnk", "XSHEILD Endpoint Security.lnk"):
            target = os.path.join(d, fname)
            if os.path.exists(target):
                try:
                    os.remove(target)
                except Exception:
                    pass

    # 5. Remove Start Menu Folders and Shortcuts
    start_dirs = []
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        start_dirs.append(os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Future Finger Technologies"))
        start_dirs.append(os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\XSHEILD"))
        # Startup folder
        startup_dir = os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup")
        for sname in ("XSHEILD.lnk", "XSHEILD_Startup.cmd", "XSHEILD.cmd", "XSHEILD.bat"):
            sp = os.path.join(startup_dir, sname)
            if os.path.exists(sp):
                try:
                    os.remove(sp)
                except Exception:
                    pass

    program_data = os.environ.get("ProgramData", r"C:\ProgramData")
    if program_data:
        start_dirs.append(os.path.join(program_data, r"Microsoft\Windows\Start Menu\Programs\Future Finger Technologies"))
        start_dirs.append(os.path.join(program_data, r"Microsoft\Windows\Start Menu\Programs\XSHEILD"))

    for s_dir in start_dirs:
        if os.path.isdir(s_dir):
            try:
                shutil.rmtree(s_dir, ignore_errors=True)
            except Exception:
                pass

    # 6. Self-delete installation directory after process termination
    install_dir = os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) else os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # Only delete if inside Programs/XSHEILD or LocalAppData to avoid deleting dev workspace
    if "Programs" in install_dir and "XSHEILD" in install_dir:
        del_bat = os.path.join(os.environ.get("TEMP", os.path.expanduser("~")), "xsheild_uninstall_cleaner.cmd")
        try:
            with open(del_bat, "w", encoding="utf-8") as f:
                f.write("@echo off\r\n")
                f.write("timeout /t 2 /nobreak >nul\r\n")
                f.write(f'rmdir /s /q "{install_dir}"\r\n')
                f.write(f'del "%~f0"\r\n')
            subprocess.Popen(["cmd.exe", "/c", del_bat], creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        except Exception:
            pass

    if not silent:
        _native_info_dialog(
            "XSHEILD Uninstalled",
            "XSHEILD Endpoint Security has been successfully uninstalled from your computer."
        )

    return True
