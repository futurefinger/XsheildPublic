"""
XSHEILD Legal Framework, Terms of Service & Exclusive Delhi Jurisdiction Agreement
Owner: Future Finger Technologies (futurefingerindia@gmail.com)

Drafted pursuant to:
1. Information Technology Act, 2000 (and IT Amendment Act, 2008).
2. Digital Personal Data Protection Act, 2023 (DPDP Act, India).
3. Indian Contract Act, 1872 (Section 10 - Click-wrap enforceable contracts).
4. Arbitration and Conciliation Act, 1996.

GOVERNING LAW & JURISDICTION: NEW DELHI, DELHI, INDIA (EXCLUSIVE WORLDWIDE)
"""

AGREEMENT_VERSION = "2026.1-DELHI-EXCLUSIVE"
PUBLISHER_NAME = "Future Finger Technologies"
CONTACT_EMAIL = "futurefingerindia@gmail.com"
OFFICIAL_JURISDICTION = "New Delhi, Delhi, India"

EULA_AND_TERMS_TEXT = f"""END USER LICENSE AGREEMENT, TERMS OF SERVICE & CYBERSECURITY LIABILITY DISCLAIMER
SOFTWARE: XSHEILD Next-Generation Endpoint Security & Antivirus
PUBLISHER: {PUBLISHER_NAME} (Email: {CONTACT_EMAIL})
AGREEMENT VERSION: {AGREEMENT_VERSION}
GOVERNING LAW & EXCLUSIVE JURISDICTION: {OFFICIAL_JURISDICTION}

IMPORTANT — READ WITH EXTREME ATTENTION BEFORE DOWNLOADING, INSTALLING, COPYING, OR USING THIS SOFTWARE.

THIS IS A LEGALLY BINDING CONTRACT BETWEEN YOU ("USER", "YOU", OR "LICENSEE") AND FUTURE FINGER TECHNOLOGIES ("COMPANY", "WE", "US", OR "LICENSOR"). BY CLICKING "I AGREE", CHECKING ANY CONSENT BOX, INSTALLING, OR OPERATING XSHEILD, YOU UNCONDITIONALLY AND IRREVOCABLY AGREE TO BE BOUND BY ALL TERMS, COVENANTS, AND JURISDICTIONAL MANDATES CONTAINED HEREIN. IF YOU DO NOT AGREE, IMMEDIATELY CEASE INSTALLATION, DELETE ALL COPIES, AND EXIT.

--------------------------------------------------------------------------------
1. GRANT OF LICENSE
--------------------------------------------------------------------------------
Future Finger Technologies grants you a revocable, personal, non-exclusive, non-transferable, limited license to install and run the XSHEILD software strictly in accordance with your registered tier (Evaluation, Free, Pro, Family, or Business). This license grants no title, ownership, copyright, or intellectual property rights, all of which remain exclusively with Future Finger Technologies.

--------------------------------------------------------------------------------
2. MANDATORY EXCLUSIVE JURISDICTION & GOVERNING LAW (NEW DELHI, INDIA)
--------------------------------------------------------------------------------
2.1. GOVERNING LAW: This Agreement, its validity, interpretation, performance, and any non-contractual obligations or torts arising out of or in connection with XSHEILD, shall be governed strictly and exclusively by the substantive laws of the Republic of India, without regard to conflict of laws principles.

2.2. EXCLUSIVE JURISDICTION: You expressly, knowingly, and irrevocably agree that any dispute, claim, legal action, suit, or proceeding of whatever nature arising out of, relating to, or involving Future Finger Technologies or XSHEILD SHALL BE INSTITUTED SOLELY AND EXCLUSIVELY IN THE COMPETENT COURTS, TRIBUNALS, AND FORUMS LOCATED IN NEW DELHI, DELHI, INDIA.

2.3. GLOBAL IRREVOCABLE WAIVER: REGARDLESS OF WHERE YOU ARE LOCATED OR RESIDE — WHETHER IN DELHI, ANY OTHER STATE OR UNION TERRITORY OF INDIA, THE UNITED STATES OF AMERICA, THE EUROPEAN UNION, THE UNITED KINGDOM, CANADA, AUSTRALIA, ASIA, OR ANY OTHER GLOBAL JURISDICTION — YOU EXPRESSLY WAIVE ANY OBJECTION BASED ON FORUM NON CONVENIENS, PERSONAL JURISDICTION, VENUE, OR DISTANCE. YOU AGREE THAT NO COURT OUTSIDE NEW DELHI, DELHI, INDIA SHALL POSSESS JURISDICTION OVER FUTURE FINGER TECHNOLOGIES.

--------------------------------------------------------------------------------
3. MANDATORY PRE-LITIGATION BINDING ARBITRATION
--------------------------------------------------------------------------------
Any controversy or claim arising out of or relating to this Agreement, software performance, or data handling shall first be submitted to binding arbitration under the Indian Arbitration and Conciliation Act, 1996. The arbitration shall be conducted by a Sole Arbitrator appointed exclusively by Future Finger Technologies. The seat and legal venue of arbitration shall be New Delhi, Delhi, India. The proceedings shall be conducted in English.

--------------------------------------------------------------------------------
4. DISCLAIMER OF INVENTED GUARANTEES & "AS-IS" WARRANTY
--------------------------------------------------------------------------------
4.1. "AS IS" AND "AS AVAILABLE": XSHEILD IS PROVIDED "AS IS", "WITH ALL FAULTS", AND WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS, IMPLIED, STATUTORY, OR HEURISTIC. 

4.2. NO ABSOLUTE IMMUNITY: IN CONFORMITY WITH CYBERSECURITY SCIENCE AND LAW, NO ANTIVIRUS OR EDR CAN GUARANTEE 100% PREVENTION OF ADVANCED ZERO-DAY THREATS, POLYMORPHIC MALWARE, STATE-SPONSORED ATTACKS, HARDWARE COMPROMISES, OR HUMAN ERROR. FUTURE FINGER TECHNOLOGIES SPECIFICALLY DISCLAIMS ANY REPRESENTATION OF UNCONDITIONAL OR FOOLPROOF IMMUNITY.

4.3. RANSOMWARE & DATA LOSS: WHILE XSHEILD DEPLOYS ADVANCED CANARY HONEYPOTS AND ENCRYPTION TRIPWIRES, THE COMPANY DISCLAIMS ANY GUARANTEE OF AUTOMATIC DATA ROLLBACK OR RECOVERY. USERS ARE SOLELY RESPONSIBLE FOR MAINTAINING INDEPENDENT, OFFLINE BACKUPS.

--------------------------------------------------------------------------------
5. ABSOLUTE LIMITATION OF LIABILITY & DAMAGE CAP
--------------------------------------------------------------------------------
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW:
5.1. UNDER NO CIRCUMSTANCES SHALL FUTURE FINGER TECHNOLOGIES, ITS FOUNDERS, DIRECTORS, SHAREHOLDERS, EMPLOYEES, CONTRACTORS, OR AFFILIATES BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, PUNITIVE, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, LOSS OF DATA, RANSOMWARE EXTORTION PAYMENTS, LOST PROFITS, BUSINESS INTERRUPTION, PRIVACY BREACHES BY THIRD-PARTY MALWARE, HARDWARE DAMAGE, OR CORRUPTED FILES).

5.2. MONETARY LIABILITY CAP: IN NO EVENT SHALL THE AGGREGATE MONETARY LIABILITY OF FUTURE FINGER TECHNOLOGIES TO YOU FOR ALL CLAIMS EXCEED THE TOTAL AMOUNT ACTUALLY PAID BY YOU TO FUTURE FINGER TECHNOLOGIES FOR XSHEILD IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM, OR INDIAN RUPEES ONE THOUSAND (INR ₹1,000/-), WHICHEVER IS LOWER.

--------------------------------------------------------------------------------
6. COMPLETE TELEMETRIC DISCLOSURE & DATA PRIVACY CONSENT
--------------------------------------------------------------------------------
Pursuant to the Digital Personal Data Protection Act, 2023 (India) and international compliance:
6.1. INSTALLATION AUDIT COPY: You explicitly authorize XSHEILD, upon installation, initial launch, and license activation, to capture registration telemetry (Name, Email, Organization, Device ID, Windows OS Build, Hardware Fingerprint, IP Address, and Consent Timestamp) and securely transmit a digital verification dossier to Future Finger Technologies at:
      futurefingerindia@gmail.com

6.2. SECURITY PURPOSE ONLY: This data is utilized solely for license enforcement, anti-piracy protection, threat telemetry, warranty verification, and customer support. Future Finger Technologies pledges never to sell or monetize user personal details.

--------------------------------------------------------------------------------
7. USER INDEMNIFICATION OBLIGATION
--------------------------------------------------------------------------------
You agree to defend, indemnify, and hold completely harmless Future Finger Technologies, its executives, developers, and representatives from and against any claims, losses, liabilities, legal costs, or damages arising out of your misuse of XSHEILD, violation of this Agreement, or violation of any third-party right or applicable law.

--------------------------------------------------------------------------------
8. SEVERABILITY & ENTIRE AGREEMENT
--------------------------------------------------------------------------------
If any provision of this Agreement is held to be invalid or unenforceable, such provision shall be enforced to the maximum extent permissible, and the remaining provisions shall remain in full force and effect. This Agreement constitutes the complete and exclusive understanding between the parties regarding XSHEILD.
"""

# Short Summary for UI Displays
SUMMARY_DISCLAIMER_BULLETS = [
    "Exclusive Jurisdiction: All legal proceedings and disputes are subject solely and exclusively to the Courts of New Delhi, Delhi, India, regardless of user location worldwide.",
    "Limitation of Liability: Software provided 'AS-IS' without invented guarantees. Liability is strictly capped at INR ₹1,000 or annual subscription paid.",
    "No 100% Zero-Day Immunity: User acknowledges that layered heuristic defenses cannot promise unconditional immunity from advanced state-level threats.",
    "Registration Dossier: User consent and system telemetry are digitally dispatched to futurefingerindia@gmail.com for license validation.",
    "Governing Law: Indian Information Technology Act, 2000 & substantive laws of India exclusively apply."
]
