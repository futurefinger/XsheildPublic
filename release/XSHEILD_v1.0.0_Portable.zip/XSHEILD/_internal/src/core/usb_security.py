"""
XSHEILD USB & Removable Media Security Guard
Owner: Future Finger Technologies
Provides USB device discovery, autorun immunization (vaccine), shortcut worm detection,
and on-demand external media scanning.
"""

import os
import sys
import ctypes
import json
import time
import shutil
import logging
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from src.core.logger import get_logger

logger = get_logger("core.usb_security")

DEFAULT_USB_LOG_PATH = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "usb_activity.json"
)

# Win32 Drive Types (GetDriveTypeW)
DRIVE_UNKNOWN = 0
DRIVE_NO_ROOT_DIR = 1
DRIVE_REMOVABLE = 2
DRIVE_FIXED = 3
DRIVE_REMOTE = 4
DRIVE_CDROM = 5
DRIVE_RAMDISK = 6


@dataclass
class USBDevice:
    drive_letter: str
    drive_type: str
    volume_label: str
    filesystem: str
    total_gb: float
    free_gb: float
    is_removable: bool
    is_immunized: bool


@dataclass
class USBActivityEvent:
    event_id: str
    timestamp: str
    drive_letter: str
    volume_label: str
    event_type: str
    details: str


class USBSecurityGuard:
    """
    Monitors, immunizes, and scans removable USB drives and external media.
    """

    def __init__(self, log_path: Optional[str] = None):
        self.log_path = log_path or DEFAULT_USB_LOG_PATH
        self.is_active = True
        self._ensure_log_exists()

    def _ensure_log_exists(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            if not os.path.exists(self.log_path):
                self._save_log([])
        except Exception:
            pass

    def _load_log(self) -> List[Dict[str, Any]]:
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_log(self, events: List[Dict[str, Any]]) -> None:
        temp_p = self.log_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(events, f, indent=2)
        import shutil
        for attempt in range(5):
            try:
                os.replace(temp_p, self.log_path)
                return
            except (PermissionError, OSError):
                if attempt == 4:
                    try:
                        shutil.copyfile(temp_p, self.log_path)
                        try:
                            os.remove(temp_p)
                        except OSError:
                            pass
                        return
                    except Exception:
                        pass
                time.sleep(0.05 * (attempt + 1))

    def log_event(self, event: USBActivityEvent) -> None:
        events = self._load_log()
        events.insert(0, asdict(event))
        if len(events) > 500:
            events = events[:500]
        self._save_log(events)
        logger.info(f"USB EVENT: [{event.event_type}] Drive {event.drive_letter} ({event.volume_label}) - {event.details}")

    def get_activity_log(self) -> List[Dict[str, Any]]:
        return self._load_log()

    def get_connected_drives(self) -> List[USBDevice]:
        """
        Enumerates all mounted logical drives and determines removable vs fixed status using Win32 API.
        """
        devices: List[USBDevice] = []
        if sys.platform != "win32":
            return devices

        try:
            kernel32 = ctypes.windll.kernel32
            bitmask = kernel32.GetLogicalDrives()

            for i in range(26):
                if bitmask & (1 << i):
                    drive_letter = f"{chr(65 + i)}:\\"
                    dtype = kernel32.GetDriveTypeW(ctypes.c_wchar_p(drive_letter))

                    type_str = "UNKNOWN"
                    is_removable = False
                    if dtype == DRIVE_REMOVABLE:
                        type_str = "REMOVABLE"
                        is_removable = True
                    elif dtype == DRIVE_FIXED:
                        type_str = "FIXED"
                    elif dtype == DRIVE_CDROM:
                        type_str = "CDROM"
                    elif dtype == DRIVE_REMOTE:
                        type_str = "NETWORK"

                    # Get Volume Information
                    vol_name = ctypes.create_unicode_buffer(1024)
                    fs_name = ctypes.create_unicode_buffer(1024)
                    kernel32.GetVolumeInformationW(
                        ctypes.c_wchar_p(drive_letter),
                        vol_name, ctypes.sizeof(vol_name),
                        None, None, None,
                        fs_name, ctypes.sizeof(fs_name)
                    )

                    # Get Disk Free Space
                    total_gb = 0.0
                    free_gb = 0.0
                    try:
                        usage = shutil.disk_usage(drive_letter)
                        total_gb = round(usage.total / (1024 ** 3), 2)
                        free_gb = round(usage.free / (1024 ** 3), 2)
                    except Exception:
                        pass

                    # Check autorun vaccine
                    autorun_p = os.path.join(drive_letter, "autorun.inf")
                    is_immunized = os.path.isdir(autorun_p)

                    devices.append(USBDevice(
                        drive_letter=drive_letter,
                        drive_type=type_str,
                        volume_label=vol_name.value or "Local Disk",
                        filesystem=fs_name.value or "NTFS",
                        total_gb=total_gb,
                        free_gb=free_gb,
                        is_removable=is_removable,
                        is_immunized=is_immunized
                    ))
        except Exception as e:
            logger.debug(f"Error enumerating drives: {e}")

        return devices

    def immunize_drive(self, drive_path: str) -> Dict[str, Any]:
        """
        Creates an immutable, un-writable directory named 'autorun.inf' on the drive root.
        This neutralizes USB autorun worm propagation techniques.
        """
        clean_drive = drive_path.rstrip("/\\") + "\\"
        autorun_path = os.path.join(clean_drive, "autorun.inf")

        try:
            # If a malicious file named autorun.inf already exists, remove it
            if os.path.isfile(autorun_path):
                # Remove read-only attribute if present
                if sys.platform == "win32":
                    ctypes.windll.kernel32.SetFileAttributesW(autorun_path, 0x80)  # FILE_ATTRIBUTE_NORMAL
                os.remove(autorun_path)

            # Create un-deletable directory structure: autorun.inf\nul.protect
            if not os.path.exists(autorun_path):
                os.makedirs(autorun_path, exist_ok=True)
                # Create protected file inside
                beacon_p = os.path.join(autorun_path, "xsheild_vaccine.beacon")
                with open(beacon_p, "w", encoding="utf-8") as f:
                    f.write("XSHEILD_VACCINE_ACTIVE")

            # Mark directory as Read-Only + Hidden + System where supported
            if sys.platform == "win32":
                ctypes.windll.kernel32.SetFileAttributesW(autorun_path, 0x01 | 0x02 | 0x04)

            import uuid
            self.log_event(USBActivityEvent(
                event_id=str(uuid.uuid4()),
                timestamp=datetime.now(timezone.utc).isoformat(),
                drive_letter=clean_drive,
                volume_label="USB_VACCINE",
                event_type="IMMUNIZATION_SUCCESS",
                details=f"Autorun vaccine applied successfully to {clean_drive}"
            ))

            return {"success": True, "path": autorun_path, "message": "Drive successfully immunized against autorun exploits"}
        except Exception as err:
            return {"success": False, "path": autorun_path, "message": f"Immunization failed: {err}"}

    def check_shortcut_worms(self, drive_path: str) -> List[Dict[str, Any]]:
        """
        Audits drive root for standard USB worm traits:
        Hidden folders combined with .lnk shortcuts pointing to PowerShell/WScript/CMD.
        """
        suspicious = []
        clean_drive = drive_path.rstrip("/\\") + "\\"
        if not os.path.exists(clean_drive):
            return suspicious

        try:
            for item in os.listdir(clean_drive):
                item_path = os.path.join(clean_drive, item)
                lower_name = item.lower()

                # Flag shortcut worm vectors
                if lower_name.endswith(".lnk"):
                    suspicious.append({
                        "file_path": item_path,
                        "filename": item,
                        "threat": "Worm.USB.ShortcutDrop",
                        "severity": "HIGH",
                        "description": "Suspicious .lnk shortcut dropped in removable drive root"
                    })
                elif lower_name.endswith((".vbs", ".scr", ".bat", ".cmd")) and not lower_name.startswith("autorun"):
                    suspicious.append({
                        "file_path": item_path,
                        "filename": item,
                        "threat": "Worm.USB.ExecutableScript",
                        "severity": "HIGH",
                        "description": "Script or executable staged in removable drive root"
                    })
        except Exception as e:
            logger.debug(f"Error checking shortcut worms in {drive_path}: {e}")

        return suspicious


# Global USB guard instance
usb_guard = USBSecurityGuard()
