"""
XSHEILD Cyber Acoustic & Threat Audio Alert Engine
Owner: Future Finger Technologies

Provides futuristic, non-jarring, hardware-synthesized acoustic cues for:
1. Threat Interception & Neutralization (sleek cyber shield pulse)
2. Safe System State / Scan Completed (crystalline harmonic confirmation)
3. Scan Initiated (tactile frequency sweep)
4. Protection Armed / Online (gentle futuristic boot chime)

Synthesizes high-fidelity 44.1kHz 16-bit PCM WAV audio dynamically in memory,
requiring zero external sound files or third-party audio packages.
Plays asynchronously on Windows without blocking worker or security threads.
Automatically suppresses audio during Gaming Mode / Focus Assist.
"""

import os
import io
import math
import wave
import struct
import json
import logging
import threading
from typing import List, Optional

logger = logging.getLogger("xsheild.audio")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
AUDIO_CONFIG_FILE = os.path.join(CONFIG_DIR, "audio_settings.json")

try:
    import winsound
    WINSOUND_AVAILABLE = True
except ImportError:
    WINSOUND_AVAILABLE = False


def _synthesize_pcm_wav(
    frequencies: List[float],
    duration: float = 0.45,
    sample_rate: int = 44100,
    volume: float = 0.65,
    decay: float = 3.2,
    harmonic_weights: Optional[List[float]] = None
) -> bytes:
    """
    Synthesizes a multi-harmonic waveform in-memory with smooth exponential envelope.
    Guarantees zero audio clipping and zero DC offset clicks.
    """
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        n_frames = int(sample_rate * duration)

        weights = harmonic_weights or [1.0 / len(frequencies)] * len(frequencies)
        total_w = sum(weights) or 1.0
        norm_weights = [w / total_w for w in weights]

        raw_frames = bytearray()
        for i in range(n_frames):
            t = float(i) / sample_rate
            # Fast 25ms attack to eliminate clicks, exponential decay envelope
            attack = min(1.0, t / 0.025)
            envelope = attack * math.exp(-decay * (t / duration))

            val = 0.0
            for freq, weight in zip(frequencies, norm_weights):
                val += weight * math.sin(2.0 * math.pi * freq * t)

            sample = max(-1.0, min(1.0, val * envelope * volume))
            sample_int = int(sample * 32767)
            raw_frames.extend(struct.pack("<h", sample_int))

        wav.writeframes(raw_frames)
    return buf.getvalue()


class CyberSoundEngine:
    """Manages playback of synthesized futuristic audio cues."""

    def __init__(self, config_path: str = AUDIO_CONFIG_FILE):
        self.config_path = config_path
        self._lock = threading.Lock()
        self._sound_enabled = True
        self._load_config()

        # Pre-synthesize audio assets in memory for zero-latency 0ms playback
        self._tone_threat = _synthesize_pcm_wav(
            frequencies=[880.0, 440.0, 220.0],
            duration=0.45,
            volume=0.60,
            decay=2.8,
            harmonic_weights=[0.5, 0.35, 0.15]
        )
        self._tone_safe = _synthesize_pcm_wav(
            frequencies=[523.25, 659.25, 783.99, 1046.50],  # C5 - E5 - G5 - C6 celestial chord
            duration=0.75,
            volume=0.55,
            decay=3.0,
            harmonic_weights=[0.3, 0.3, 0.25, 0.15]
        )
        self._tone_scan_complete = _synthesize_pcm_wav(
            frequencies=[587.33, 880.0],  # D5 -> A5 crisp resolution
            duration=0.40,
            volume=0.55,
            decay=3.5
        )
        self._tone_shield_online = _synthesize_pcm_wav(
            frequencies=[440.0, 659.25, 880.0],
            duration=0.50,
            volume=0.50,
            decay=3.0
        )

    def _load_config(self) -> None:
        if os.path.isfile(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._sound_enabled = bool(data.get("sound_effects_enabled", True))
            except Exception as e:
                logger.warning(f"Failed to read audio config: {e}")

    def _save_config(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump({"sound_effects_enabled": self._sound_enabled}, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to write audio config: {e}")

    @property
    def is_enabled(self) -> bool:
        with self._lock:
            return self._sound_enabled

    def set_enabled(self, enabled: bool) -> bool:
        with self._lock:
            self._sound_enabled = bool(enabled)
            self._save_config()
            return self._sound_enabled

    def toggle(self) -> bool:
        with self._lock:
            self._sound_enabled = not self._sound_enabled
            self._save_config()
            return self._sound_enabled

    def _play_raw_wav(self, wav_bytes: bytes) -> bool:
        """Plays PCM WAV asynchronously without blocking."""
        if not WINSOUND_AVAILABLE or not self._sound_enabled:
            return False

        # Suppress audio during active Gaming / Silent Mode
        try:
            from src.core.notifications import gaming_mode_manager
            if gaming_mode_manager.is_active:
                return False
        except Exception:
            pass

        try:
            winsound.PlaySound(wav_bytes, winsound.SND_MEMORY | winsound.SND_ASYNC)
            return True
        except Exception as e:
            logger.debug(f"Audio playback notice: {e}")
            return False

    def play_threat_intercepted(self) -> bool:
        """Plays futuristic dual-tone shield pulse when malware is intercepted."""
        return self._play_raw_wav(self._tone_threat)

    def play_system_safe(self) -> bool:
        """Plays calming, pleasant harmonic chord confirming system is secure."""
        return self._play_raw_wav(self._tone_safe)

    def play_scan_complete(self) -> bool:
        """Plays ascending two-tone confirmation when scan finishes."""
        return self._play_raw_wav(self._tone_scan_complete)

    def play_shield_online(self) -> bool:
        """Plays cyber boot chime when real-time protection activates."""
        return self._play_raw_wav(self._tone_shield_online)


# Global singleton sound engine
sound_engine = CyberSoundEngine()
