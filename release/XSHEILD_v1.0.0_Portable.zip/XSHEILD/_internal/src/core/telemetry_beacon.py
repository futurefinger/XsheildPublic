"""
Future Finger Technologies — XShield Remote Telemetry Beacon & License Verifier
Tracks installed client computers, activation keys, registration state, and auto-updates.
"""

import os
import sys
import json
import time
import socket
import platform
import threading
import urllib.request
import urllib.error
import hashlib
from datetime import datetime

HQ_TELEMETRY_URL = "http://127.0.0.1:8100/api/xshield/telemetry/heartbeat"
XSHIELD_VERSION = "2.5.0"


def get_hardware_id() -> str:
    """Computes a unique, tamper-resistant HWID for the machine."""
    try:
        raw_seed = f"{platform.node()}-{platform.machine()}-{platform.processor()}-{os.environ.get('COMPUTERNAME', '')}"
        return hashlib.sha256(raw_seed.encode("utf-8")).hexdigest()[:24].upper()
    except Exception:
        return "HWID-UNKNOWN-DEFAULT"


def get_client_ip() -> str:
    """Discovers the client IP address safely."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


class XShieldTelemetryBeacon:
    def __init__(self, endpoint_url: str = None):
        self.endpoint_url = endpoint_url or os.environ.get("XSHIELD_HQ_URL", HQ_TELEMETRY_URL)
        self.hwid = get_hardware_id()
        self.hostname = socket.gethostname()
        self.username = os.environ.get("USERNAME", "SystemUser")
        self.os_info = f"{platform.system()} {platform.release()} ({platform.architecture()[0]})"
        self.running = False
        self._thread = None
        self.last_response = None

    def collect_payload(self) -> dict:
        """Gathers local telemetry, license details, and registration status."""
        # Load license info if present
        license_key = "TRIAL-FREE-30D"
        license_tier = "Pro Trial"
        customer_email = "unregistered@local.pc"
        customer_name = "Trial User"
        customer_phone = ""

        # Check local licensing files
        lic_paths = [
            os.path.join(os.path.dirname(__file__), "..", "..", "logs", "xshield_license.json"),
            os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "logs", "xshield_licenses.json"),
            os.path.join(os.environ.get("APPDATA", ""), "FutureFinger", "XShield", "license.json")
        ]
        for lp in lic_paths:
            if os.path.exists(lp):
                try:
                    with open(lp, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        license_key = data.get("license_key", license_key)
                        license_tier = data.get("tier", license_tier)
                        customer_email = data.get("customer_email", customer_email)
                        customer_name = data.get("customer_name", customer_name)
                        customer_phone = data.get("customer_phone", customer_phone)
                        break
                except Exception:
                    pass

        return {
            "hwid": self.hwid,
            "hostname": self.hostname,
            "username": self.username,
            "os_platform": self.os_info,
            "client_ip": get_client_ip(),
            "version": XSHIELD_VERSION,
            "license_key": license_key,
            "license_tier": license_tier,
            "is_registered": (customer_email != "unregistered@local.pc"),
            "customer_name": customer_name,
            "customer_email": customer_email,
            "customer_phone": customer_phone,
            "sentry_status": "ACTIVE_PROTECTED",
            "threats_blocked": 0,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }

    def send_heartbeat(self) -> dict:
        """Sends one heartbeat to Future Finger Central Headquarters."""
        payload = self.collect_payload()
        try:
            req_data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.endpoint_url,
                data=req_data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": f"FutureFinger-XShield/{XSHIELD_VERSION}"
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=4) as res:
                body = res.read().decode("utf-8")
                resp_json = json.loads(body)
                self.last_response = resp_json
                return resp_json
        except Exception as e:
            # Non-blocking graceful error logging
            return {"status": "OFFLINE_QUEUED", "error": str(e)}

    def _worker_loop(self):
        """Periodic background pulse daemon."""
        while self.running:
            self.send_heartbeat()
            # Pulse every 10 minutes (600 seconds)
            for _ in range(600):
                if not self.running:
                    break
                time.sleep(1)

    def start_background_daemon(self):
        """Starts the beacon thread."""
        if self._thread and self._thread.is_alive():
            return
        self.running = True
        self._thread = threading.Thread(target=self._worker_loop, daemon=True, name="XShieldTelemetryDaemon")
        self._thread.start()

    def stop(self):
        self.running = False


telemetry_beacon = XShieldTelemetryBeacon()

if __name__ == "__main__":
    print(f"Testing XShield Beacon from {socket.gethostname()}...")
    res = telemetry_beacon.send_heartbeat()
    print("Heartbeat result:", res)
