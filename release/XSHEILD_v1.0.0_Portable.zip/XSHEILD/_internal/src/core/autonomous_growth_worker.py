"""
XSHEILD Autonomous Viral Growth & Self-Marketing Worker
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, India
Official Destination: futurefingerindia@gmail.com

Continuously operates in the background of every installed client:
1. Emotion-Driven Milestone Marketing: Triggers pre-crafted viral share links when threats are neutralized.
2. Clean Streak Celebrations: Prompts milestone badges after 3, 7, and 30 days of clean protection.
3. Corporate LAN / Office Auto-Detection: Generates Team Protection invites on business workstations.
4. Autonomous Weekly Marketing & Telemetry Dispatch to futurefingerindia@gmail.com.
5. Zero human effort required: runs entirely autonomously.
"""

import os
import sys
import time
import json
import socket
import logging
import threading
import webbrowser
import urllib.parse
from typing import Dict, Any, Optional
from datetime import datetime, timezone, timedelta

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [AUTONOMOUS-GROWTH] %(message)s")
logger = logging.getLogger("xsheild.autonomous_growth")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

GROWTH_STATE_FILE = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "autonomous_marketing_state.json"
)

OWNER_EMAIL = "futurefingerindia@gmail.com"


class AutonomousGrowthWorker:
    """Autonomous marketing engine embedded into every XSHEILD endpoint."""

    def __init__(self, state_file: str = GROWTH_STATE_FILE):
        self.state_file = state_file
        os.makedirs(os.path.dirname(os.path.abspath(self.state_file)), exist_ok=True)
        self._lock = threading.Lock()
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None

        self._state = self._load_state()

    def _load_state(self) -> Dict[str, Any]:
        with self._lock:
            if os.path.isfile(self.state_file):
                try:
                    with open(self.state_file, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    pass

            # Default initial state
            default_state = {
                "first_installed_at": datetime.now(timezone.utc).isoformat(),
                "threats_intercepted_count": 0,
                "clean_days_milestones_awarded": [],
                "last_weekly_digest_dispatched": None,
                "office_network_prompted": False,
                "viral_prompts_shown": 0,
                "referral_code": None
            }
            self._save_state_unlocked(default_state)
            return default_state

    def _save_state_unlocked(self, state: Dict[str, Any]):
        try:
            with open(self.state_file, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to persist autonomous marketing state: {e}")

    def _save_state(self):
        with self._lock:
            self._save_state_unlocked(self._state)

    def get_user_referral_link(self) -> str:
        """Retrieves or creates the unique referral link for this installation."""
        try:
            from src.core.growth_engine import GrowthEngine
            ge = GrowthEngine()
            # Check user profile
            p_file = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD", "user_profile.json")
            email = "user@xshield.local"
            name = "XSHEILD Shield Ambassador"
            if os.path.isfile(p_file):
                with open(p_file, "r", encoding="utf-8") as f:
                    u = json.load(f)
                    email = u.get("email", email)
                    name = u.get("name", name)

            profile = ge.get_or_create_user_referral_profile(name, email)
            ref_code = profile.get("referral_code", "XSHIELD-PILOT")
            ref_url = profile.get("referral_url", f"https://futurefingertechnologies.com/xshield/invite?ref={ref_code}")

            with self._lock:
                self._state["referral_code"] = ref_code
            self._save_state()
            return ref_url
        except Exception:
            return "https://futurefingertechnologies.com/xshield"

    # --- Trigger 1: Threat Neutralized Viral Prompt ---

    def on_threat_neutralized(self, threat_name: str, file_path: str):
        """
        Called automatically when XSHEILD neutralizes a threat.
        Generates a high-converting emotional celebration and desktop notification.
        """
        with self._lock:
            self._state["threats_intercepted_count"] += 1
            count = self._state["threats_intercepted_count"]
            self._state["viral_prompts_shown"] += 1
        self._save_state()

        ref_link = self.get_user_referral_link()

        whatsapp_text = (
            f"🛡️ My PC was just protected from a high-risk {threat_name} threat by XSHEILD Antivirus! "
            f"Get 30 Days of Free Pro Protection for your PC right here: {ref_link}"
        )

        logger.info(f"[AUTONOMOUS MARKETING] Threat neutralized: {threat_name}. Prepared viral protection link.")

        # Show desktop notification
        try:
            from src.core.notifications import NotificationManager
            nm = NotificationManager()
            nm.show_toast(
                title="🛡️ Attack Neutralized by XSHEILD!",
                message=f"Defended from {threat_name}. Gift free Pro protection to colleagues & friends to earn +30 bonus days!"
            )
        except Exception:
            pass

    # --- Trigger 2: Clean Streak Milestones ---

    def check_clean_streak_milestones(self):
        """Checks if the PC has maintained 3, 7, 14, or 30 days of virus-free uptime."""
        try:
            first_seen = datetime.fromisoformat(self._state.get("first_installed_at", datetime.now(timezone.utc).isoformat()))
            days_active = (datetime.now(timezone.utc) - first_seen).days
        except Exception:
            days_active = 0

        milestones = [3, 7, 14, 30, 60, 90]
        awarded = set(self._state.get("clean_days_milestones_awarded", []))

        for m in milestones:
            if days_active >= m and m not in awarded:
                with self._lock:
                    self._state["clean_days_milestones_awarded"].append(m)
                self._save_state()

                ref_link = self.get_user_referral_link()
                logger.info(f"[AUTONOMOUS MARKETING] Awarded {m}-Day Clean Streak Milestone! Promoting ambassador sharing.")

                try:
                    from src.core.notifications import NotificationManager
                    nm = NotificationManager()
                    nm.show_toast(
                        title=f"🏆 {m}-Day Zero-Threat Shield Award!",
                        message=f"Your PC has been 100% clean for {m} days! Invite 3 friends with your link to unlock free VIP Pro days."
                    )
                except Exception:
                    pass
                break

    # --- Trigger 3: Corporate / Office Network Auto-Detection ---

    def check_and_promote_office_team_shield(self):
        """Detects if system is on a business/corporate LAN and prompts team protection."""
        if self._state.get("office_network_prompted", False):
            return

        is_office = False
        try:
            # Check for Windows Domain or multiple network interfaces
            hostname = socket.gethostname()
            fqdn = socket.getfqdn()
            if "." in fqdn and not fqdn.endswith(".local") and not fqdn.endswith(".home"):
                is_office = True

            # Check if domain role in registry
            import winreg
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters")
                domain, _ = winreg.QueryValueEx(k, "Domain")
                winreg.CloseKey(k)
                if domain:
                    is_office = True
            except Exception:
                pass
        except Exception:
            pass

        if is_office:
            with self._lock:
                self._state["office_network_prompted"] = True
            self._save_state()

            ref_link = self.get_user_referral_link()
            logger.info("[AUTONOMOUS MARKETING] Corporate LAN detected! Prompting multi-device team protection.")

            try:
                from src.core.notifications import NotificationManager
                nm = NotificationManager()
                nm.show_toast(
                    title="🏢 Corporate Workstation Protection",
                    message="Office network detected. Protect your team & coworkers with XSHEILD centralized enterprise defense."
                )
            except Exception:
                pass

    # --- Trigger 4: Autonomous Weekly Telemetry & Marketing Dispatch ---

    def check_and_dispatch_weekly_digest(self):
        """Silently and autonomously emails a weekly security & marketing digest to futurefingerindia@gmail.com."""
        last_str = self._state.get("last_weekly_digest_dispatched")
        now = datetime.now(timezone.utc)
        should_dispatch = False

        if not last_str:
            should_dispatch = True
        else:
            try:
                last_dt = datetime.fromisoformat(last_str)
                if now - last_dt >= timedelta(days=7):
                    should_dispatch = True
            except Exception:
                should_dispatch = True

        if should_dispatch:
            try:
                from src.core.growth_engine import GrowthEngine
                ge = GrowthEngine()
                ge.dispatch_comprehensive_growth_report("AUTONOMOUS_WEEKLY_ENDPOINT_TELEMETRY")
                with self._lock:
                    self._state["last_weekly_digest_dispatched"] = now.isoformat()
                self._save_state()
                logger.info(f"[AUTONOMOUS MARKETING] Weekly security dossier successfully dispatched to {OWNER_EMAIL}.")
            except Exception as e:
                logger.debug(f"Weekly digest dispatch deferred: {e}")

    # --- 1-Click Viral Sharing Actions ---

    def generate_share_payload(self) -> Dict[str, str]:
        """Produces ready-to-use 1-click sharing URLs."""
        ref_link = self.get_user_referral_link()
        msg_text = (
            f"🛡️ Protect your PC with XSHEILD — Beyond Antivirus. "
            f"I have been using it to secure my laptop from ransomware and zero-day threats. "
            f"Claim 30 Days Free Pro Edition using my link:\n{ref_link}"
        )
        encoded_msg = urllib.parse.quote(msg_text)

        return {
            "referral_url": ref_link,
            "share_text": msg_text,
            "whatsapp_url": f"https://api.whatsapp.com/send?text={encoded_msg}",
            "telegram_url": f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote('Protect your PC with XSHEILD Antivirus')}",
            "email_url": f"mailto:?subject={urllib.parse.quote('Gift: 30 Days Free XSHEILD Pro Antivirus')}&body={encoded_msg}",
            "linkedin_url": f"https://www.linkedin.com/sharing/share-offsite/?url={urllib.parse.quote(ref_link)}"
        }

    def share_via_whatsapp(self) -> bool:
        """Opens WhatsApp Web with pre-populated referral message."""
        payload = self.generate_share_payload()
        return webbrowser.open(payload["whatsapp_url"])

    def share_via_email(self) -> bool:
        """Opens default email client with pre-populated message."""
        payload = self.generate_share_payload()
        return webbrowser.open(payload["email_url"])

    def share_via_telegram(self) -> bool:
        """Opens Telegram share dialog."""
        payload = self.generate_share_payload()
        return webbrowser.open(payload["telegram_url"])

    # --- Background Loop ---

    def start_autonomous_engine(self, check_interval_seconds: int = 3600):
        """Starts background worker thread."""
        if self._running:
            return
        self._running = True

        def _loop():
            # Initial run
            time.sleep(10)
            while self._running:
                try:
                    self.check_clean_streak_milestones()
                    self.check_and_promote_office_team_shield()
                    self.check_and_dispatch_weekly_digest()
                except Exception as e:
                    logger.debug(f"Error in autonomous marketing loop: {e}")
                time.sleep(check_interval_seconds)

        self._worker_thread = threading.Thread(target=_loop, daemon=True)
        self._worker_thread.start()
        logger.info("XSHEILD Autonomous Viral Marketing & Growth Engine initialized and running.")

    def stop_autonomous_engine(self):
        self._running = False
