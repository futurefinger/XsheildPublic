"""
XSHEILD GitHub Software Distribution & Release Discovery Engine
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, India
Official Destination: futurefingerindia@gmail.com

Interfaces with the public GitHub Releases API to discover software updates,
download assets, verify checksums, and fetch release changelogs.
Implements ETag caching, rate-limit fallback, and zero-token client security.
"""

import os
import sys
import json
import time
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [GITHUB-DIST] %(message)s")
logger = logging.getLogger("xsheild.github_dist")

DEFAULT_REPO_OWNER = "futurefinger"
DEFAULT_REPO_NAME = "XsheildPublic"
CACHE_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
CACHE_FILE = os.path.join(CACHE_DIR, "github_releases_cache.json")

# Fallback release catalog if GitHub API is unreachable or rate-limited on cold start
FALLBACK_CATALOG = [
    {
        "tag_name": "v2.6.28",
        "name": "XSHEILD v2.6.28 — 3D Meditation Sentinel & Bottom-Right Sovereign HUD Matrix",
        "published_at": "2026-11-23T12:00:00Z",
        "prerelease": False,
        "draft": False,
        "html_url": "https://github.com/futurefinger/XsheildPublic",
        "body": "## XSHEILD Production Release v2.6.28\n- 3D Animated Buy Now Button integrated into bottom-right Meditation Sentinel Tray HUD\n- Dynamic sovereign license gating and floating checkout badge on public portal\n- High-performance native installer with Section 65B IT Act verification",
        "assets": [
            {
                "name": "XSHEILD_Setup.exe",
                "size": 45369560,
                "browser_download_url": "https://github.com/futurefinger/XsheildPublic/releases/download/v2.6.28/XSHEILD_Setup.exe"
            }
        ]
    }
]


class GitHubDistributionEngine:
    """Manages release discovery and assets retrieval via GitHub public API."""

    def __init__(self, owner: str = DEFAULT_REPO_OWNER, repo: str = DEFAULT_REPO_NAME, cache_path: str = CACHE_FILE):
        self.owner = owner
        self.repo = repo
        self.cache_path = cache_path
        os.makedirs(os.path.dirname(os.path.abspath(self.cache_path)), exist_ok=True)
        self.api_base = f"https://api.github.com/repos/{self.owner}/{self.repo}"
        self._cached_data: Dict[str, Any] = self._load_cache()

    def _load_cache(self) -> Dict[str, Any]:
        if os.path.isfile(self.cache_path):
            try:
                with open(self.cache_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            "etag": None,
            "last_checked": 0,
            "releases": FALLBACK_CATALOG
        }

    def _save_cache(self):
        try:
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(self._cached_data, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed saving GitHub releases cache: {e}")

    def fetch_all_releases(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Fetches all published releases from GitHub API or raw public repository with ETag and rate-limit handling.
        """
        now = time.time()
        # Cache for at least 3 minutes unless forced
        if not force_refresh and (now - self._cached_data.get("last_checked", 0) < 180):
            return self._cached_data.get("releases", FALLBACK_CATALOG)

        # Primary source 1: GitHub Releases API
        url = f"{self.api_base}/releases?_t={int(now)}"
        headers = {
            "User-Agent": "XSHEILD-Antivirus-Client/1.0 (Future Finger Technologies)",
            "Accept": "application/vnd.github.v3+json",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache"
        }
        if self._cached_data.get("etag") and not force_refresh:
            headers["If-None-Match"] = self._cached_data["etag"]

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=6) as res:
                if res.status == 200:
                    etag = res.headers.get("ETag")
                    raw = res.read().decode("utf-8")
                    data = json.loads(raw)
                    if isinstance(data, list) and len(data) > 0:
                        # Check if raw version.json has an even newer direct release
                        try:
                            public_url = f"https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/version.json?_t={int(now)}"
                            req2 = urllib.request.Request(public_url, headers={
                                "User-Agent": "XSHEILD-Antivirus-Client/1.0",
                                "Cache-Control": "no-cache, no-store, must-revalidate",
                                "Pragma": "no-cache"
                            })
                            with urllib.request.urlopen(req2, timeout=4) as res2:
                                if res2.status == 200:
                                    v_info = json.loads(res2.read().decode("utf-8"))
                                    raw_ver = v_info.get("version", "")
                                    latest_api_tag = data[0].get("tag_name", "").lstrip("vV")
                                    from src.core.software_updater import is_version_newer
                                    if raw_ver and is_version_newer(raw_ver, latest_api_tag):
                                        tag = v_info.get("tag_name") or v_info.get("tag") or f"v{raw_ver}"
                                        rel_direct = {
                                            "tag_name": tag,
                                            "name": v_info.get("release_name") or f"XSHEILD {tag} — Production Release",
                                            "published_at": v_info.get("published_at", datetime.now(timezone.utc).isoformat()),
                                            "prerelease": False,
                                            "draft": False,
                                            "html_url": "https://github.com/futurefinger/XsheildPublic",
                                            "body": v_info.get("release_notes") or f"XSHEILD Production Release {tag}",
                                            "assets": [
                                                {
                                                    "name": v_info.get("installer_file", "XSHEILD_Setup.exe"),
                                                    "size": v_info.get("size") or v_info.get("installer_size", 43558616),
                                                    "browser_download_url": v_info.get("download_url") or "https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/XSHEILD_Setup.exe"
                                                }
                                            ],
                                            "sha256": v_info.get("sha256") or v_info.get("installer_sha256", "")
                                        }
                                        data.insert(0, rel_direct)
                        except Exception as e_raw:
                            logger.debug(f"Direct raw version comparison skipped: {e_raw}")

                        self._cached_data["releases"] = data
                        self._cached_data["etag"] = etag
                        self._cached_data["last_checked"] = now
                        self._save_cache()
                        logger.info(f"Successfully fetched {len(data)} releases from GitHub API.")
                        return data
                    else:
                        logger.debug("GitHub Releases API returned empty catalog. Checking raw public distribution manifest...")
        except urllib.error.HTTPError as he:
            if he.code == 304:
                logger.debug("GitHub Releases API returned 304 Not Modified. Reusing cached releases.")
                if self._cached_data.get("releases"):
                    return self._cached_data["releases"]
            logger.debug(f"GitHub API HTTP error: {he}. Checking public raw distribution...")
        except Exception as e:
            logger.debug(f"GitHub API check deferred: {e}. Checking public raw distribution...")

        # Primary source 2: Raw Public Distribution manifest (unauthenticated, 0 rate limit)
        public_url = f"https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/version.json?_t={int(now)}"
        try:
            req2 = urllib.request.Request(public_url, headers={
                "User-Agent": "XSHEILD-Antivirus-Client/1.0",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache"
            })
            with urllib.request.urlopen(req2, timeout=5) as res2:
                if res2.status == 200:
                    v_info = json.loads(res2.read().decode("utf-8"))
                    if v_info.get("version"):
                        ver = v_info["version"]
                        tag = v_info.get("tag_name") or v_info.get("tag") or f"v{ver}"
                        rel = {
                            "tag_name": tag,
                            "name": v_info.get("release_name") or v_info.get("name") or f"XSHEILD {tag} — Production Release",
                            "published_at": v_info.get("published_at", datetime.now(timezone.utc).isoformat()),
                            "prerelease": False,
                            "draft": False,
                            "html_url": "https://github.com/futurefinger/XsheildPublic",
                            "body": v_info.get("release_notes") or v_info.get("body") or f"XSHEILD Release {tag}",
                            "assets": [
                                {
                                    "name": v_info.get("installer_file", "XSHEILD_Setup.exe"),
                                    "size": v_info.get("installer_size") or v_info.get("size", 43459288),
                                    "browser_download_url": v_info.get("download_url", "https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/XSHEILD_Setup.exe")
                                }
                            ],
                            "sha256": v_info.get("installer_sha256") or v_info.get("sha256", "")
                        }
                        self._cached_data["releases"] = [rel]
                        self._cached_data["last_checked"] = now
                        self._save_cache()
                        logger.info(f"Discovered release {tag} from public distribution manifest.")
                        return [rel]
        except Exception as e:
            logger.debug(f"Public manifest check deferred: {e}")

        return self._cached_data.get("releases", FALLBACK_CATALOG)

    def get_latest_release(self, channel: str = "stable", force_refresh: bool = False) -> Optional[Dict[str, Any]]:
        """
        Returns the latest release matching the desired channel (stable, beta, dev).
        """
        releases = self.fetch_all_releases(force_refresh=force_refresh)
        if not releases:
            return None

        for rel in releases:
            if rel.get("draft", False):
                continue

            is_prerelease = rel.get("prerelease", False)
            tag = rel.get("tag_name", "").lower()

            if channel == "stable":
                if not is_prerelease and "beta" not in tag and "dev" not in tag:
                    return rel
            elif channel == "beta":
                if "dev" not in tag:
                    return rel
            else:
                # dev channel accepts any release
                return rel

        # Default fallback to first non-draft
        return releases[0] if releases else None

    def get_asset_info(self, release: Dict[str, Any], filename_contains: str) -> Optional[Dict[str, Any]]:
        """Finds asset in release matching filename pattern."""
        assets = release.get("assets", [])
        for a in assets:
            if filename_contains.lower() in a.get("name", "").lower():
                return a
        return None

    def get_download_url_for_installer(self, release: Dict[str, Any]) -> Optional[str]:
        """Returns direct download URL for the Windows Setup installer (.exe)."""
        asset = self.get_asset_info(release, "Setup") or self.get_asset_info(release, ".exe")
        return asset.get("browser_download_url") if asset else None

    def get_download_url_for_portable(self, release: Dict[str, Any]) -> str:
        """Returns download URL for the portable zip package."""
        asset = self.get_asset_info(release, "Portable") or self.get_asset_info(release, ".zip")
        if asset and asset.get("browser_download_url"):
            return asset["browser_download_url"]
        tag = release.get("tag_name", "v2.6.3")
        return f"https://github.com/futurefinger/XsheildPublic/releases/download/{tag}/XSHEILD_v1.0.0_Portable.zip"

    def fetch_release_checksums(self, release: Dict[str, Any]) -> Dict[str, str]:
        """
        Downloads and parses SHA256SUMS.txt, release_checksum.txt, or manifest sha256.
        Returns a mapping: filename -> sha256_hash.
        """
        if release.get("sha256"):
            hash_val = release["sha256"].strip().lower()
            return {
                "XSHEILD_Setup.exe": hash_val,
                "update.exe": hash_val
            }

        asset = self.get_asset_info(release, "SHA256") or self.get_asset_info(release, "checksum")
        if not asset or not asset.get("browser_download_url"):
            return {}

        url = asset["browser_download_url"]
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "XSHEILD-Antivirus-Client/1.0"})
            with urllib.request.urlopen(req, timeout=5) as res:
                if res.status == 200:
                    text = res.read().decode("utf-8")
                    checksums = {}
                    for line in text.splitlines():
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        parts = line.split()
                        if len(parts) >= 2:
                            chk = parts[0].strip().lower()
                            fn = parts[1].strip().lstrip("*")
                            checksums[fn] = chk
                    return checksums
        except Exception as e:
            logger.debug(f"Could not fetch release checksums: {e}")
        return {}


# Global singleton instance
github_distribution = GitHubDistributionEngine()
