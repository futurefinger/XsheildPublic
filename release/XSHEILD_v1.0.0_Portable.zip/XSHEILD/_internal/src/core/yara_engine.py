"""
XSHEILD YARA Threat Rule Matching Engine
Owner: Future Finger Technologies

Provides fast, high-confidence signature pattern matching using YARA-style rule semantics:
1. Evaluates text, hex byte patterns, and regex indicators across binaries and documents.
2. Supports flexible matching conditions (all, any, threshold-based).
3. Pre-loaded with curated production rules for CobaltStrike, LockBit 3.0, Mimikatz, and WebShells.
4. Extensible to ingest community YARA feeds (.yar / .yara files).
"""

import os
import re
import logging
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field

from src.core.models import (
    DetectionResult,
    DetectionCategory,
    ThreatSeverity,
    DetectionMethod
)

logger = logging.getLogger("xsheild.yara_engine")


@dataclass
class YaraRule:
    """Represents a YARA-compatible threat detection rule."""
    rule_name: str
    category: DetectionCategory
    severity: ThreatSeverity
    description: str
    strings: List[bytes]
    condition: str = "any"  # "any", "all", or integer count threshold as string "2", "3"
    confidence: float = 0.98


def _decode_sig(masked: bytes, key: int = 0x5B) -> bytes:
    return bytes([b ^ key for b in masked])


# Built-in Production Signature Rules (XOR masked to eliminate AV heuristic false positives)
BUILTIN_YARA_RULES: List[YaraRule] = [
    YaraRule(
        rule_name="Ransom.LockBit3.PayloadArtifacts",
        category=DetectionCategory.RANSOMWARE,
        severity=ThreatSeverity.CRITICAL,
        description="Ransomware ransom notes, encryption markers, and mutexes.",
        strings=[
            _decode_sig(bytes([55, 52, 56, 48, 57, 50, 47, 123, 104, 117, 107, 123, 47, 51, 62, 123, 44, 52, 41, 55, 63, 124, 40, 123, 54, 52, 40, 47, 123, 56, 52, 54, 43, 55, 62, 47, 62, 123, 41, 58, 53, 40, 52, 54, 44, 58, 41, 62])),
            _decode_sig(bytes([55, 57, 104, 4, 63, 62, 56, 41, 34, 43, 47, 117, 47, 35, 47])),
            _decode_sig(bytes([34, 52, 46, 41, 123, 63, 58, 47, 58, 123, 50, 40, 123, 40, 47, 52, 55, 62, 53, 123, 58, 53, 63, 123, 62, 53, 56, 41, 34, 43, 47, 62, 63])),
            _decode_sig(bytes([55, 52, 56, 48, 57, 50, 47, 118, 40, 46, 43, 43, 52, 41, 47, 117, 56, 52, 54])),
        ],
        condition="any",
        confidence=1.0
    ),
    YaraRule(
        rule_name="Hacktool.CobaltStrike.BeaconStager",
        category=DetectionCategory.TROJAN,
        severity=ThreatSeverity.CRITICAL,
        description="C2 beacon reflective loader and payload cradle.",
        strings=[
            _decode_sig(bytes([41, 62, 61, 55, 62, 56, 47, 50, 45, 62, 55, 52, 58, 63, 62, 41])),
            _decode_sig(bytes([126, 40, 123, 58, 40, 123, 126, 40, 7, 126, 40, 97, 123, 126, 63])),
            _decode_sig(bytes([43, 52, 44, 62, 41, 40, 51, 62, 55, 55, 123, 118, 53, 52, 43, 123, 118, 44, 123, 51, 50, 63, 63, 62, 53, 123, 118, 56, 123, 121, 50, 62, 35, 123, 115, 115, 53, 62, 44, 118, 52, 57, 49, 62, 56, 47, 123, 53, 62, 47, 117, 44, 62, 57, 56, 55, 50, 62, 53, 47, 114, 117, 63, 52, 44, 53, 55, 52, 58, 63, 40, 47, 41, 50, 53, 60])),
            _decode_sig(bytes([57, 62, 58, 56, 52, 53, 117, 63, 55, 55])),
        ],
        condition="any",
        confidence=0.99
    ),
    YaraRule(
        rule_name="Webshell.ChinaChopper.Generic",
        category=DetectionCategory.TROJAN,
        severity=ThreatSeverity.HIGH,
        description="Generic eval webshell backdoor payload.",
        strings=[
            _decode_sig(bytes([103, 100, 43, 51, 43, 123, 27, 62, 45, 58, 55, 115, 127, 4, 43, 52, 40, 47, 0])),
            _decode_sig(bytes([103, 100, 43, 51, 43, 123, 62, 45, 58, 55, 115, 127, 4, 41, 62, 42, 46, 62, 40, 47, 0])),
            _decode_sig(bytes([103, 126, 62, 45, 58, 55, 123, 41, 62, 42, 46, 62, 40, 47, 115])),
            _decode_sig(bytes([103, 126, 62, 35, 62, 56, 46, 47, 62, 123, 41, 62, 42, 46, 62, 40, 47, 115])),
        ],
        condition="any",
        confidence=0.98
    ),
    YaraRule(
        rule_name="Hacktool.Mimikatz.MemorySignatures",
        category=DetectionCategory.TROJAN,
        severity=ThreatSeverity.CRITICAL,
        description="In-memory credential dumper functions and token extractors.",
        strings=[
            _decode_sig(bytes([48, 46, 51, 55, 4, 54, 4, 40, 62, 48, 46, 41, 55, 40, 58])),
            _decode_sig(bytes([55, 40, 58, 40, 41, 45, 117, 63, 55, 55, 122, 55, 40, 58, 43, 55, 52, 60, 50, 53, 56, 41, 62, 63, 40])),
            _decode_sig(bytes([54, 50, 54, 50, 55, 50, 57, 117, 63, 55, 55])),
            _decode_sig(bytes([40, 62, 48, 46, 41, 55, 40, 58, 97, 97, 55, 52, 60, 52, 53, 43, 58, 40, 40, 44, 52, 41, 63, 40])),
        ],
        condition="any",
        confidence=1.0
    ),
    YaraRule(
        rule_name="Malware.OfficeMacro.DropperHeuristic",
        category=DetectionCategory.SUSPICIOUS_SCRIPT,
        severity=ThreatSeverity.HIGH,
        description="Malicious VBA macro download cradle in Microsoft Office document.",
        strings=[
            _decode_sig(bytes([58, 46, 47, 52, 52, 43, 62, 53])),
            _decode_sig(bytes([44, 52, 41, 48, 57, 52, 52, 48, 4, 52, 43, 62, 53])),
            _decode_sig(bytes([56, 41, 62, 58, 47, 62, 52, 57, 49, 62, 56, 47, 115, 121, 44, 40, 56, 41, 50, 43, 47, 117, 40, 51, 62, 55, 55, 121, 114])),
            _decode_sig(bytes([43, 52, 44, 62, 41, 40, 51, 62, 55, 55, 117, 62, 35, 62, 123, 118, 44, 50, 53, 63, 52, 44, 40, 47, 34, 55, 62, 123, 51, 50, 63, 63, 62, 53])),
        ],
        condition="2",
        confidence=0.95
    )
]


class YaraMatchingEngine:
    """
    High-performance pattern scanner evaluating YARA rules against file content.
    """

    def __init__(self, custom_rules: Optional[List[YaraRule]] = None):
        self.rules: List[YaraRule] = list(BUILTIN_YARA_RULES)
        if custom_rules:
            self.rules.extend(custom_rules)

    def scan_bytes(
        self,
        content: bytes,
        file_path: str,
        sha256: str = "",
        md5: str = "",
        sha1: str = "",
        file_size: int = 0
    ) -> Optional[DetectionResult]:
        """
        Scans binary or document bytes against all registered YARA rules.
        """
        content_lower = content.lower()

        for rule in self.rules:
            matched_strings = []
            for pattern in rule.strings:
                if pattern in content_lower:
                    matched_strings.append(pattern.decode("latin-1", errors="replace"))

            is_match = False
            if rule.condition == "any":
                is_match = len(matched_strings) >= 1
            elif rule.condition == "all":
                is_match = len(matched_strings) == len(rule.strings)
            elif rule.condition.isdigit():
                threshold = int(rule.condition)
                is_match = len(matched_strings) >= threshold

            if is_match:
                logger.info(f"YARA Match: {rule.rule_name} in {file_path} (Matches: {matched_strings})")
                return DetectionResult(
                    file_path=file_path,
                    sha256=sha256,
                    md5=md5,
                    sha1=sha1,
                    category=rule.category,
                    detection_name=rule.rule_name,
                    severity=rule.severity,
                    detection_method=DetectionMethod.SIGNATURE_MATCH,
                    confidence=rule.confidence,
                    file_size_bytes=file_size,
                    recommended_action="QUARANTINE",
                    details={
                        "engine": "XSHEILD YARA Pattern Engine",
                        "description": rule.description,
                        "matched_patterns": matched_strings,
                        "condition": rule.condition
                    }
                )

        return None


# Global YARA engine singleton
yara_engine = YaraMatchingEngine()
