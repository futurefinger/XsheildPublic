"""
XSHEILD Enterprise License Administration & Entitlement Engine
Owner: Future Finger Technologies (futurefingerindia@gmail.com)

Features:
- Cryptographically signed Ed25519 (RFC 8032) asymmetric license token creation
- Assignment to specific users, clients, organizations, and hardware IDs
- Granular plan duration (30 days, 1 year, 2 years, Lifetime VIP, custom)
- Multi-seat device limit enforcement and seat transfer workflow
- License state management: ACTIVE, SUSPENDED, REVOKED, EXPIRED
- Bulk license generation for enterprise batch deployments
- Cryptographic audit trail logging for all administrative actions
- Export licenses as JSON or CSV
"""

import os
import sys
import json
import time
import uuid
import base64
import csv
import io
import threading
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from src.core.logger import get_logger
from src.licensing.client import PLAN_FEATURES, get_hardware_device_id
from src.licensing.token_verifier import verify_asymmetric_token

try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = get_logger("license_admin")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
ENTERPRISE_STORE = os.path.join(CONFIG_DIR, "enterprise_licenses.json")
AUDIT_LOG_FILE = os.path.join(CONFIG_DIR, "license_admin_audit.json")

# Master Fallback Key if not in .env (Future Finger Technologies Ed25519 pair)
FALLBACK_PRIVATE_KEY_B64 = "kwvUsdyM/cQKWxB7d7u1CXkOlegWQKLBTERKE27Y+DY="
FALLBACK_PUBLIC_KEY_B64 = "hzZSl4tGUdxfz0A5ddQCl79WP40epQQZ6n+elWDYm7k="

PLAN_DEFAULT_DEVICES = {
    "FREE_EVALUATION": 1,
    "PRO": 1,
    "FAMILY": 5,
    "BUSINESS": 25,
    "ENTERPRISE": 100,
}


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _get_signing_key() -> Optional[Any]:
    if not CRYPTO_AVAILABLE:
        return None
    raw_b64 = os.environ.get("FFT_ED25519_PRIVATE_KEY", "").strip()
    if not raw_b64:
        # Check root .env
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        env_file = os.path.join(root_dir, ".env")
        if os.path.isfile(env_file):
            try:
                with open(env_file, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.startswith("FFT_ED25519_PRIVATE_KEY="):
                            raw_b64 = line.split("=", 1)[1].strip()
                            break
            except Exception:
                pass
    if not raw_b64:
        raw_b64 = FALLBACK_PRIVATE_KEY_B64

    try:
        priv_bytes = base64.b64decode(raw_b64)
        return ed25519.Ed25519PrivateKey.from_private_bytes(priv_bytes)
    except Exception as exc:
        logger.error(f"Failed to load Ed25519 private key: {exc}")
        return None


class LicenseAdminManager:
    """Enterprise License Admin Controller for Future Finger Technologies."""

    def __init__(self, store_path: Optional[str] = None):
        self.store_path = os.path.abspath(store_path or ENTERPRISE_STORE)
        self.audit_path = os.path.abspath(AUDIT_LOG_FILE)
        self._lock = threading.Lock()
        os.makedirs(os.path.dirname(self.store_path), exist_ok=True)
        self._init_defaults()

    def _init_defaults(self):
        with self._lock:
            if not os.path.exists(self.store_path):
                initial_data = {
                    "version": "1.0",
                    "publisher": "Future Finger Technologies",
                    "admin_contact": "futurefingerindia@gmail.com",
                    "licenses": {},
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
                self._save_raw(initial_data)

            if not os.path.exists(self.audit_path):
                with open(self.audit_path, "w", encoding="utf-8") as f:
                    json.dump([], f, indent=2)

    def _load_raw(self) -> Dict[str, Any]:
        try:
            if os.path.exists(self.store_path):
                with open(self.store_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Error reading license store: {e}")
        return {"licenses": {}}

    def _save_raw(self, data: Dict[str, Any]):
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        temp_p = self.store_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(temp_p, self.store_path)

    def _log_audit(self, action: str, details: Dict[str, Any]):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "details": details,
            "operator": "admin@futurefinger.com"
        }
        try:
            entries = []
            if os.path.exists(self.audit_path):
                with open(self.audit_path, "r", encoding="utf-8") as f:
                    entries = json.load(f)
            entries.append(entry)
            if len(entries) > 1000:
                entries = entries[-1000:]
            with open(self.audit_path, "w", encoding="utf-8") as f:
                json.dump(entries, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to append license audit log: {e}")

    def issue_license(
        self,
        customer_name: str,
        customer_email: str,
        plan: str = "PRO",
        duration_days: int = 365,
        organization: str = "",
        max_devices: Optional[int] = None,
        bound_device_id: str = "",
        notes: str = ""
    ) -> Dict[str, Any]:
        """
        Creates and signs a new commercial Ed25519 license token and records it in the admin catalog.
        """
        plan_upper = plan.upper()
        if plan_upper not in PLAN_FEATURES:
            plan_upper = "PRO"

        features = PLAN_FEATURES.get(plan_upper, PLAN_FEATURES["PRO"])
        limit_devices = max_devices if (max_devices and max_devices > 0) else PLAN_DEFAULT_DEVICES.get(plan_upper, 1)

        now = int(time.time())
        expires_at = now + (duration_days * 86400)
        license_id = f"XSH-LIC-{uuid.uuid4().hex[:8].upper()}"

        payload = {
            "token_id": license_id,
            "user_id": customer_email.strip().lower(),
            "customer_name": customer_name.strip(),
            "organization": organization.strip() or "Standard User",
            "plan": plan_upper,
            "issued_at": now,
            "expires_at": expires_at,
            "features": features,
            "max_devices": limit_devices,
            "issuer": "Future Finger Technologies",
            "jurisdiction": "New Delhi, Delhi, India",
            "product": "XSHEILD Next-Gen Antivirus"
        }

        if bound_device_id.strip():
            payload["device_id"] = bound_device_id.strip()

        # Sign with Ed25519
        signing_key = _get_signing_key()
        if not signing_key:
            raise RuntimeError("Ed25519 signing key unavailable. Cannot issue secure license.")

        canonical_json = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        sig_bytes = signing_key.sign(canonical_json)
        token_str = f"ed25519.{_b64url_encode(canonical_json)}.{_b64url_encode(sig_bytes)}"

        # Initial active devices
        active_devices = []
        if bound_device_id.strip():
            active_devices.append({
                "device_id": bound_device_id.strip(),
                "device_name": "Primary Registered Device",
                "activated_at": datetime.now(timezone.utc).isoformat()
            })

        record = {
            "license_id": license_id,
            "token": token_str,
            "customer_name": customer_name.strip(),
            "customer_email": customer_email.strip().lower(),
            "organization": organization.strip() or "Standard User",
            "plan": plan_upper,
            "duration_days": duration_days,
            "issued_at": now,
            "issued_at_iso": datetime.fromtimestamp(now, tz=timezone.utc).isoformat(),
            "expires_at": expires_at,
            "expires_at_iso": datetime.fromtimestamp(expires_at, tz=timezone.utc).isoformat(),
            "max_devices": limit_devices,
            "active_devices": active_devices,
            "status": "ACTIVE",
            "bound_device_id": bound_device_id.strip(),
            "notes": notes.strip(),
            "features": features
        }

        with self._lock:
            data = self._load_raw()
            data["licenses"][license_id] = record
            self._save_raw(data)

        self._log_audit("ISSUE_LICENSE", {
            "license_id": license_id,
            "customer": customer_name,
            "email": customer_email,
            "plan": plan_upper,
            "duration_days": duration_days,
            "max_devices": limit_devices
        })

        logger.info(f"Successfully issued commercial license {license_id} for {customer_email} ({plan_upper})")
        return record

    def bulk_generate(
        self,
        count: int = 5,
        plan: str = "PRO",
        duration_days: int = 365,
        org_prefix: str = "Enterprise Bulk",
        max_devices: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Generates multiple activation keys for batch corporate deployments."""
        count = max(1, min(100, count))
        results = []
        for i in range(1, count + 1):
            cust_name = f"{org_prefix} Seat #{i}"
            cust_email = f"seat_{i}_{uuid.uuid4().hex[:6]}@deployment.futurefinger.com"
            lic = self.issue_license(
                customer_name=cust_name,
                customer_email=cust_email,
                plan=plan,
                duration_days=duration_days,
                organization=org_prefix,
                max_devices=max_devices,
                notes=f"Batch generated item {i} of {count}"
            )
            results.append(lic)
        return results

    def revoke_license(self, license_id: str, reason: str = "") -> Tuple[bool, str]:
        """Revokes an issued license permanently."""
        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, f"License ID '{license_id}' not found."

            lic["status"] = "REVOKED"
            lic["revoked_at"] = datetime.now(timezone.utc).isoformat()
            lic["revocation_reason"] = reason or "Revoked by Administrator"
            self._save_raw(data)

        self._log_audit("REVOKE_LICENSE", {"license_id": license_id, "reason": reason})
        return True, f"License {license_id} has been revoked."

    def suspend_license(self, license_id: str, reason: str = "") -> Tuple[bool, str]:
        """Temporarily suspends an active license."""
        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, f"License ID '{license_id}' not found."

            lic["status"] = "SUSPENDED"
            lic["suspended_at"] = datetime.now(timezone.utc).isoformat()
            lic["suspension_reason"] = reason or "Administrative suspension"
            self._save_raw(data)

        self._log_audit("SUSPEND_LICENSE", {"license_id": license_id, "reason": reason})
        return True, f"License {license_id} has been suspended."

    def reactivate_license(self, license_id: str) -> Tuple[bool, str]:
        """Reactivates a suspended license."""
        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, f"License ID '{license_id}' not found."

            now = int(time.time())
            if lic.get("expires_at", 0) <= now:
                return False, f"Cannot reactivate expired license. Please extend duration first."

            lic["status"] = "ACTIVE"
            lic.pop("suspended_at", None)
            lic.pop("suspension_reason", None)
            self._save_raw(data)

        self._log_audit("REACTIVATE_LICENSE", {"license_id": license_id})
        return True, f"License {license_id} reactivated to ACTIVE status."

    def extend_license(self, license_id: str, additional_days: int) -> Tuple[bool, str]:
        """Adds extra days to a license."""
        if additional_days <= 0:
            return False, "Additional days must be greater than zero."

        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, f"License ID '{license_id}' not found."

            now = int(time.time())
            curr_exp = max(lic.get("expires_at", now), now)
            new_exp = curr_exp + (additional_days * 86400)
            lic["expires_at"] = new_exp
            lic["expires_at_iso"] = datetime.fromtimestamp(new_exp, tz=timezone.utc).isoformat()
            if lic["status"] == "EXPIRED":
                lic["status"] = "ACTIVE"

            # Re-sign token with updated expiration
            signing_key = _get_signing_key()
            if signing_key:
                payload = {
                    "token_id": lic["license_id"],
                    "user_id": lic["customer_email"],
                    "customer_name": lic["customer_name"],
                    "organization": lic.get("organization", ""),
                    "plan": lic["plan"],
                    "issued_at": lic["issued_at"],
                    "expires_at": new_exp,
                    "features": lic["features"],
                    "max_devices": lic.get("max_devices", 1),
                    "issuer": "Future Finger Technologies",
                    "product": "XSHEILD Next-Gen Antivirus"
                }
                canonical_json = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
                sig_bytes = signing_key.sign(canonical_json)
                lic["token"] = f"ed25519.{_b64url_encode(canonical_json)}.{_b64url_encode(sig_bytes)}"

            self._save_raw(data)

        self._log_audit("EXTEND_LICENSE", {"license_id": license_id, "days_added": additional_days})
        return True, f"License {license_id} extended by {additional_days} days."

    def transfer_device_seat(
        self,
        license_id: str,
        old_device_id: str,
        new_device_id: str,
        new_device_name: str = "New Device"
    ) -> Tuple[bool, str]:
        """Unlinks a device and binds a new hardware device to the seat."""
        if not new_device_id.strip():
            return False, "Target new device ID cannot be empty."

        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, f"License ID '{license_id}' not found."

            devices = lic.get("active_devices", [])
            # Remove old device if present
            devices = [d for d in devices if d.get("device_id") != old_device_id]

            # Check capacity
            if len(devices) >= lic.get("max_devices", 1):
                return False, f"Device capacity reached ({len(devices)}/{lic.get('max_devices')}). Remove an existing device first."

            devices.append({
                "device_id": new_device_id.strip(),
                "device_name": new_device_name.strip() or f"PC-{new_device_id[:6]}",
                "activated_at": datetime.now(timezone.utc).isoformat()
            })
            lic["active_devices"] = devices
            self._save_raw(data)

        self._log_audit("TRANSFER_SEAT", {
            "license_id": license_id,
            "old_device": old_device_id,
            "new_device": new_device_id
        })
        return True, f"Successfully transferred seat to device {new_device_id}."

    def register_device_activation(
        self,
        license_id: str,
        device_id: str,
        device_name: str = ""
    ) -> Tuple[bool, str]:
        """Registers a device activating under this license if within seat limit."""
        with self._lock:
            data = self._load_raw()
            lic = data["licenses"].get(license_id)
            if not lic:
                return False, "License not found."

            if lic.get("status") != "ACTIVE":
                return False, f"License is currently {lic.get('status')}."

            now = int(time.time())
            if lic.get("expires_at", 0) <= now:
                lic["status"] = "EXPIRED"
                self._save_raw(data)
                return False, "License has expired."

            devices = lic.get("active_devices", [])
            # If already registered
            for d in devices:
                if d.get("device_id") == device_id:
                    return True, "Device already registered to this license."

            # Check limit
            if len(devices) >= lic.get("max_devices", 1):
                return False, f"Maximum device activations exceeded ({len(devices)}/{lic.get('max_devices')}). Please upgrade plan or transfer an existing seat."

            devices.append({
                "device_id": device_id,
                "device_name": device_name or f"Workstation-{device_id[:6]}",
                "activated_at": datetime.now(timezone.utc).isoformat()
            })
            lic["active_devices"] = devices
            self._save_raw(data)

        self._log_audit("DEVICE_ACTIVATED", {"license_id": license_id, "device_id": device_id})
        return True, f"Device registered successfully ({len(devices)}/{lic.get('max_devices')} seats active)."

    def list_licenses(self, status_filter: Optional[str] = None, query: str = "") -> List[Dict[str, Any]]:
        """Returns all managed licenses with optional status filter and search query."""
        data = self._load_raw()
        licenses = list(data.get("licenses", {}).values())
        now = int(time.time())

        # Update dynamic expired status
        for lic in licenses:
            if lic.get("status") == "ACTIVE" and lic.get("expires_at", 0) <= now:
                lic["status"] = "EXPIRED"

        # Apply filters
        if status_filter and status_filter.upper() != "ALL":
            licenses = [l for l in licenses if l.get("status") == status_filter.upper()]

        if query.strip():
            q = query.strip().lower()
            licenses = [
                l for l in licenses
                if q in l.get("license_id", "").lower()
                or q in l.get("customer_name", "").lower()
                or q in l.get("customer_email", "").lower()
                or q in l.get("organization", "").lower()
                or q in l.get("plan", "").lower()
            ]

        # Sort descending by issued_at
        licenses.sort(key=lambda x: x.get("issued_at", 0), reverse=True)
        return licenses

    def get_license(self, license_id: str) -> Optional[Dict[str, Any]]:
        data = self._load_raw()
        return data.get("licenses", {}).get(license_id)

    def get_license_audit_logs(self, limit: int = 100) -> List[Dict[str, Any]]:
        try:
            if os.path.exists(self.audit_path):
                with open(self.audit_path, "r", encoding="utf-8") as f:
                    logs = json.load(f)
                    return list(reversed(logs))[:limit]
        except Exception as e:
            logger.error(f"Failed to read audit logs: {e}")
        return []

    def get_license_stats(self) -> Dict[str, Any]:
        """Calculates aggregated metrics across all enterprise and retail licenses."""
        licenses = self.list_licenses()
        now = int(time.time())

        total = len(licenses)
        active = sum(1 for l in licenses if l.get("status") == "ACTIVE" and l.get("expires_at", 0) > now)
        expired = sum(1 for l in licenses if l.get("expires_at", 0) <= now or l.get("status") == "EXPIRED")
        revoked = sum(1 for l in licenses if l.get("status") == "REVOKED")
        suspended = sum(1 for l in licenses if l.get("status") == "SUSPENDED")

        total_seats = sum(l.get("max_devices", 1) for l in licenses)
        active_seats = sum(len(l.get("active_devices", [])) for l in licenses)

        plan_counts = {}
        for l in licenses:
            p = l.get("plan", "PRO")
            plan_counts[p] = plan_counts.get(p, 0) + 1

        return {
            "total_licenses": total,
            "active_licenses": active,
            "expired_licenses": expired,
            "revoked_licenses": revoked,
            "suspended_licenses": suspended,
            "total_seats_allocated": total_seats,
            "active_seats_utilized": active_seats,
            "seat_utilization_pct": round((active_seats / max(1, total_seats)) * 100, 1),
            "plan_breakdown": plan_counts
        }

    def export_licenses_json(self) -> str:
        licenses = self.list_licenses()
        return json.dumps(licenses, indent=2)

    def export_licenses_csv(self) -> str:
        licenses = self.list_licenses()
        output = io.StringIO()
        fieldnames = [
            "license_id", "status", "plan", "customer_name", "customer_email",
            "organization", "duration_days", "issued_at_iso", "expires_at_iso",
            "max_devices", "active_device_count", "notes", "token"
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for lic in licenses:
            row = dict(lic)
            row["active_device_count"] = len(lic.get("active_devices", []))
            writer.writerow(row)
        return output.getvalue()


_instance: Optional[LicenseAdminManager] = None


def get_license_admin_manager() -> LicenseAdminManager:
    global _instance
    if _instance is None:
        _instance = LicenseAdminManager()
    return _instance
