"""
XSHEILD Core Domain Models
Owner: Future Finger Technologies
Defines strongly-typed data structures for detections, scans, quarantine, and threat severity.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone


class ThreatSeverity(str, Enum):
    CLEAN = "CLEAN"
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DetectionCategory(str, Enum):
    BENIGN = "BENIGN"
    TEST_DETECTION = "TEST_DETECTION"
    RANSOMWARE = "RANSOMWARE"
    TROJAN = "TROJAN"
    SPYWARE = "SPYWARE"
    ADWARE_PUA = "ADWARE_PUA"
    SUSPICIOUS_PE = "SUSPICIOUS_PE"
    SUSPICIOUS_SCRIPT = "SUSPICIOUS_SCRIPT"
    PERSISTENCE_ALERT = "PERSISTENCE_ALERT"
    ARCHIVE_BOMB = "ARCHIVE_BOMB"
    CORRUPTED_FILE = "CORRUPTED_FILE"


class DetectionMethod(str, Enum):
    EXACT_HASH = "EXACT_HASH"
    SIGNATURE_MATCH = "SIGNATURE_MATCH"
    HEURISTIC = "HEURISTIC"
    HEURISTIC_ENTROPY = "HEURISTIC_ENTROPY"
    PE_ANOMALY = "PE_ANOMALY"
    ARCHIVE_INSPECTOR = "ARCHIVE_INSPECTOR"
    BEHAVIORAL_TELEMETRY = "BEHAVIORAL_TELEMETRY"
    CLOUD_REPUTATION = "CLOUD_REPUTATION"


class ScanMode(str, Enum):
    QUICK = "QUICK"
    FULL = "FULL"
    CUSTOM = "CUSTOM"
    SINGLE_FILE = "SINGLE_FILE"
    REALTIME = "REALTIME"


@dataclass
class DetectionResult:
    """Represents an individual threat finding or verified clean verdict."""
    file_path: str
    sha256: str
    md5: str = ""
    sha1: str = ""
    category: DetectionCategory = DetectionCategory.BENIGN
    detection_name: str = "Clean"
    severity: ThreatSeverity = ThreatSeverity.CLEAN
    detection_method: DetectionMethod = DetectionMethod.EXACT_HASH
    confidence: float = 1.0  # 0.0 to 1.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    scanner_version: str = "1.0.0"
    signature_db_version: str = "2026.10.29"
    file_size_bytes: int = 0
    recommended_action: str = "ALLOW"  # ALLOW, QUARANTINE, DELETE, MONITOR
    action_result: str = "NONE"       # NONE, QUARANTINED, DELETED, RESTORED, IGNORED
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_threat(self) -> bool:
        return self.severity not in (ThreatSeverity.CLEAN, ThreatSeverity.INFO)


@dataclass
class FileScanReport:
    """Represents the complete outcome of a scan operation."""
    scan_id: str
    mode: ScanMode
    target_path: str
    start_time: str
    end_time: str = ""
    duration_seconds: float = 0.0
    total_files_scanned: int = 0
    threats_detected: int = 0
    clean_cache_hits: int = 0
    errors_encountered: int = 0
    detections: List[DetectionResult] = field(default_factory=list)
    error_messages: List[str] = field(default_factory=list)
    is_cancelled: bool = False


@dataclass
class QuarantineRecord:
    """Represents a neutralized, isolated file stored inside the encrypted vault."""
    item_id: str
    original_path: str
    vault_file_name: str
    original_filename: str
    sha256: str
    file_size_bytes: int
    quarantined_at: str
    detection_name: str
    severity: ThreatSeverity
    detection_category: DetectionCategory
    is_restored: bool = False
    is_deleted: bool = False
    restored_at: Optional[str] = None
    restored_path: Optional[str] = None
