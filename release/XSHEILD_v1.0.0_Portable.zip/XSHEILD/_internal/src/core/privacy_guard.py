"""
XSHEILD Privacy Guard & Sensor Surveillance Engine
Owner: Future Finger Technologies
Monitors real-time webcam and microphone sensor access via Windows CapabilityAccessManager,
detects unauthorized background recording, and generates endpoint privacy reports.
"""

import os
import sys
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from src.core.logger import get_logger

logger = get_logger("core.privacy_guard")

# Sensor registry roots under Windows 10 & 11
WEBCAM_CONSENT_KEY = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam"
MICROPHONE_CONSENT_KEY = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone"


@dataclass
class SensorAccessRecord:
    sensor_type: str  # "WEBCAM" or "MICROPHONE"
    application_id: str
    is_currently_active: bool
    last_access_start: Optional[str]
    last_access_stop: Optional[str]
    is_suspicious: bool
    reason: Optional[str]


class PrivacyGuardEngine:
    """
    Audits active and recent webcam and microphone access using native Windows winreg APIs.
    """

    def __init__(self):
        self.is_active = True

    def _filetime_to_iso(self, ft: int) -> Optional[str]:
        """Converts Windows 64-bit FILETIME (100-ns intervals since Jan 1, 1601) to ISO-8601 string."""
        if not ft or ft <= 0:
            return None
        try:
            # 11644473600 is seconds between 1601-01-01 and 1970-01-01
            unix_ts = (ft / 10000000) - 11644473600
            if unix_ts > 0:
                return datetime.fromtimestamp(unix_ts, tz=timezone.utc).isoformat()
        except Exception:
            pass
        return None

    def audit_sensor(self, sensor_type: str) -> List[SensorAccessRecord]:
        """Audits access records for specified sensor ("WEBCAM" or "MICROPHONE")."""
        records: List[SensorAccessRecord] = []
        if sys.platform != "win32":
            return records

        import winreg

        sub_path = WEBCAM_CONSENT_KEY if sensor_type == "WEBCAM" else MICROPHONE_CONSENT_KEY

        for root_hkey in [winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE]:
            try:
                with winreg.OpenKey(root_hkey, sub_path) as base_key:
                    num_subkeys = winreg.QueryInfoKey(base_key)[0]
                    for i in range(num_subkeys):
                        try:
                            subkey_name = winreg.EnumKey(base_key, i)

                            # NonPackaged subkey contains standard Win32 executables
                            if subkey_name == "NonPackaged":
                                np_path = f"{sub_path}\\NonPackaged"
                                try:
                                    with winreg.OpenKey(root_hkey, np_path) as np_key:
                                        num_np = winreg.QueryInfoKey(np_key)[0]
                                        for j in range(num_np):
                                            app_key_name = winreg.EnumKey(np_key, j)
                                            rec = self._read_sensor_app_key(root_hkey, f"{np_path}\\{app_key_name}", app_key_name, sensor_type)
                                            if rec:
                                                records.append(rec)
                                except Exception:
                                    pass
                            else:
                                rec = self._read_sensor_app_key(root_hkey, f"{sub_path}\\{subkey_name}", subkey_name, sensor_type)
                                if rec:
                                    records.append(rec)
                        except Exception:
                            continue
            except Exception as e:
                logger.debug(f"Could not open sensor key {sub_path}: {e}")

        return records

    def _read_sensor_app_key(self, hkey, full_path: str, app_id: str, sensor_type: str) -> Optional[SensorAccessRecord]:
        import winreg
        try:
            with winreg.OpenKey(hkey, full_path) as key:
                start_ft = 0
                stop_ft = 0
                try:
                    start_ft = winreg.QueryValueEx(key, "LastUsedTimeStart")[0]
                except Exception:
                    pass
                try:
                    stop_ft = winreg.QueryValueEx(key, "LastUsedTimeStop")[0]
                except Exception:
                    pass

                # If start > 0 and stop == 0, sensor is currently active!
                is_active = (start_ft > 0 and stop_ft == 0)

                # Format readable app name (strip registry path slashes)
                readable_app = app_id.replace("#", "\\")
                lower_app = readable_app.lower()

                # Evaluate suspicious background access
                is_susp = False
                reason = None

                # Flag scripts or temp binaries accessing camera/mic
                if any(ext in lower_app for ext in [".vbs", ".ps1", ".bat", ".cmd", ".hta", ".scr"]):
                    is_susp = True
                    reason = f"Script engine ({app_id}) requested {sensor_type.lower()} access"
                elif "\\temp\\" in lower_app or "\\appdata\\local\\temp" in lower_app:
                    is_susp = True
                    reason = f"Temporary executable in AppData/Temp requested {sensor_type.lower()} access"

                return SensorAccessRecord(
                    sensor_type=sensor_type,
                    application_id=readable_app,
                    is_currently_active=is_active,
                    last_access_start=self._filetime_to_iso(start_ft),
                    last_access_stop=self._filetime_to_iso(stop_ft),
                    is_suspicious=is_susp,
                    reason=reason
                )
        except Exception:
            return None

    def get_full_privacy_report(self) -> Dict[str, Any]:
        """Aggregates webcam and microphone privacy telemetry."""
        cam_records = self.audit_sensor("WEBCAM")
        mic_records = self.audit_sensor("MICROPHONE")

        active_cam = [r for r in cam_records if r.is_currently_active]
        active_mic = [r for r in mic_records if r.is_currently_active]
        suspicious = [r for r in cam_records + mic_records if r.is_suspicious]

        return {
            "status": "PROTECTED" if not suspicious else "SUSPICIOUS_ACCESS_DETECTED",
            "active_webcam_sessions": len(active_cam),
            "active_microphone_sessions": len(active_mic),
            "total_webcam_apps_tracked": len(cam_records),
            "total_microphone_apps_tracked": len(mic_records),
            "suspicious_events_count": len(suspicious),
            "recent_webcam_access": [asdict(r) for r in cam_records[:10]],
            "recent_microphone_access": [asdict(r) for r in mic_records[:10]],
            "suspicious_findings": [asdict(r) for r in suspicious]
        }


# Global singleton
privacy_guard = PrivacyGuardEngine()
