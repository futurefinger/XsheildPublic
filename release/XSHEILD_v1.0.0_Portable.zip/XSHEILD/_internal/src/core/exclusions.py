"""
XSHEILD Scan Exclusion & Trusted Allowlist Manager
Owner: Future Finger Technologies

Allows administrators, developers, and users to specify:
1. Path Exclusions (file or recursive directory tree)
2. Extension Exclusions (e.g. .tar.gz, .sh, .pyc)
3. Cryptographic Hash Allowlists (SHA-256)

Persists configuration safely with atomic writes to %LOCALAPPDATA%\\XSHEILD\\exclusions.json.
Thread-safe and guarded against path traversal vulnerabilities.
"""

import os
import json
import logging
import threading
from typing import Set, List, Dict, Any, Optional

logger = logging.getLogger("xsheild.exclusions")

DEFAULT_CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
EXCLUSIONS_FILE = os.path.join(DEFAULT_CONFIG_DIR, "exclusions.json")


class ExclusionManager:
    """Manages persistent scan and real-time surveillance exclusions."""

    def __init__(self, config_path: str = EXCLUSIONS_FILE):
        self.config_path = config_path
        self._lock = threading.Lock()
        self._excluded_paths: Set[str] = set()
        self._excluded_extensions: Set[str] = set()
        self._trusted_hashes: Set[str] = set()
        self._load()

    def _load(self) -> None:
        """Loads saved exclusions from disk."""
        if not os.path.isfile(self.config_path):
            return

        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._excluded_paths = {os.path.normcase(os.path.abspath(p)) for p in data.get("paths", [])}
                self._excluded_extensions = {ext.lower() if ext.startswith(".") else f".{ext.lower()}" for ext in data.get("extensions", [])}
                self._trusted_hashes = {h.lower() for h in data.get("trusted_hashes", [])}
        except Exception as e:
            logger.warning(f"Failed to load scan exclusions: {e}")

    def _save(self) -> None:
        """Atomically persists exclusions to disk."""
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            data = {
                "paths": sorted(list(self._excluded_paths)),
                "extensions": sorted(list(self._excluded_extensions)),
                "trusted_hashes": sorted(list(self._trusted_hashes))
            }
            tmp = self.config_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self.config_path)
        except Exception as e:
            logger.error(f"Failed to persist scan exclusions: {e}")

    def add_path_exclusion(self, path: str) -> bool:
        """Excludes a file or directory path from real-time and on-demand scanning."""
        if not path or not path.strip():
            return False
        clean_p = os.path.normcase(os.path.abspath(path.strip()))
        with self._lock:
            self._excluded_paths.add(clean_p)
            self._save()
        logger.info(f"Added path exclusion: {clean_p}")
        return True

    def remove_path_exclusion(self, path: str) -> bool:
        """Removes an excluded path."""
        clean_p = os.path.normcase(os.path.abspath(path.strip()))
        with self._lock:
            if clean_p in self._excluded_paths:
                self._excluded_paths.remove(clean_p)
                self._save()
                return True
        return False

    def add_extension_exclusion(self, ext: str) -> bool:
        """Excludes an extension (e.g. '.sh' or 'tar.gz')."""
        clean_ext = ext.strip().lower()
        if not clean_ext:
            return False
        if not clean_ext.startswith("."):
            clean_ext = f".{clean_ext}"
        with self._lock:
            self._excluded_extensions.add(clean_ext)
            self._save()
        return True

    def remove_extension_exclusion(self, ext: str) -> bool:
        clean_ext = ext.strip().lower()
        if not clean_ext.startswith("."):
            clean_ext = f".{clean_ext}"
        with self._lock:
            if clean_ext in self._excluded_extensions:
                self._excluded_extensions.remove(clean_ext)
                self._save()
                return True
        return False

    def add_trusted_hash(self, sha256_hash: str) -> bool:
        """Allows a specific SHA-256 hash unconditionally."""
        clean_h = sha256_hash.strip().lower()
        if len(clean_h) != 64:
            return False
        with self._lock:
            self._trusted_hashes.add(clean_h)
            self._save()
        return True

    def remove_trusted_hash(self, sha256_hash: str) -> bool:
        clean_h = sha256_hash.strip().lower()
        with self._lock:
            if clean_h in self._trusted_hashes:
                self._trusted_hashes.remove(clean_h)
                self._save()
                return True
        return False

    def is_path_excluded(self, file_path: str) -> bool:
        """Returns True if the path or any parent directory is excluded."""
        if not file_path:
            return False
        clean_p = os.path.normcase(os.path.abspath(file_path))

        with self._lock:
            # 1. Exact path or parent directory exclusion
            for excl in self._excluded_paths:
                if clean_p == excl:
                    return True
                # Check if file is inside an excluded directory
                if clean_p.startswith(excl + os.sep) or clean_p.startswith(excl + "/"):
                    return True

            # 2. Extension check
            lower_name = clean_p.lower()
            for ext in self._excluded_extensions:
                if lower_name.endswith(ext):
                    return True

        return False

    def is_hash_excluded(self, sha256_hash: str) -> bool:
        """Returns True if the hash is registered in the trusted allowlist."""
        if not sha256_hash:
            return False
        with self._lock:
            return sha256_hash.lower() in self._trusted_hashes

    def is_excluded(self, file_path: str, sha256_hash: Optional[str] = None) -> bool:
        """Comprehensive check across path, extension, and SHA-256."""
        if self.is_path_excluded(file_path):
            return True
        if sha256_hash and self.is_hash_excluded(sha256_hash):
            return True
        return False

    def get_all_exclusions(self) -> Dict[str, List[str]]:
        """Returns snapshot of active exclusions."""
        with self._lock:
            return {
                "paths": sorted(list(self._excluded_paths)),
                "extensions": sorted(list(self._excluded_extensions)),
                "trusted_hashes": sorted(list(self._trusted_hashes))
            }


# Global Singleton Instance
exclusion_manager = ExclusionManager()
