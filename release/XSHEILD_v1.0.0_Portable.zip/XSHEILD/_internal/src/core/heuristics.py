"""
XSHEILD Heuristic Analysis & Static Feature Inspection
Owner: Future Finger Technologies
Performs Shannon entropy analysis, PE structure parsing, section validation, and suspicious API mapping.
"""

import math
import os
from typing import Optional, Dict, Any, List, Set
from collections import Counter

from src.core.models import DetectionResult, ThreatSeverity, DetectionCategory, DetectionMethod
from src.core.signatures import SUSPICIOUS_API_SETS, RANSOMWARE_EXTENSIONS

try:
    import pefile
    PEFILE_AVAILABLE = True
except ImportError:
    PEFILE_AVAILABLE = False


def calculate_entropy(data: bytes) -> float:
    """
    Computes Shannon entropy in bits per byte (range: 0.0 to 8.0).
    Values > 7.2 typically indicate packed, encrypted, or compressed payloads.
    """
    if not data:
        return 0.0

    length = len(data)
    counts = Counter(data)
    entropy = 0.0

    for count in counts.values():
        p_x = count / length
        entropy -= p_x * math.log2(p_x)

    return round(entropy, 4)


def inspect_file_entropy(file_path: str, max_read_bytes: int = 1024 * 1024 * 4) -> float:
    """Reads up to max_read_bytes from file and returns calculated Shannon entropy."""
    try:
        with open(file_path, "rb") as f:
            chunk = f.read(max_read_bytes)
            return calculate_entropy(chunk)
    except Exception:
        return 0.0


def inspect_pe_structure(file_path: str) -> Optional[DetectionResult]:
    """
    Performs deep PE structural analysis using pefile.
    Detects packed binaries, anomalous section characteristics (e.g. RWX sections),
    and suspicious API import combinations (process injection, keylogging).
    Guarded against memory exhaustion and parser DOS bombs.
    """
    if not PEFILE_AVAILABLE:
        return None

    try:
        file_size = os.path.getsize(file_path)
    except OSError:
        return None

    # Guard against parsing massive non-PE or oversized binaries (> 100 MB)
    if file_size > 100 * 1024 * 1024:
        return None

    # Check for basic DOS MZ header before invoking pefile
    try:
        with open(file_path, "rb") as f:
            magic = f.read(2)
            if magic != b"MZ":
                return None
    except Exception:
        return None

    pe = None
    try:
        pe = pefile.PE(file_path, fast_load=False)

        # Parser DoS Guard: Section count ceiling
        if len(pe.sections) > 96:
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.SUSPICIOUS_PE,
                detection_name="Heuristic.PE.AnomalousSectionCount",
                severity=ThreatSeverity.MEDIUM,
                detection_method=DetectionMethod.PE_ANOMALY,
                confidence=0.85,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"section_count": len(pe.sections)}
            )

        suspicious_indicators: List[str] = []
        highest_section_entropy = 0.0
        has_rwx_section = False

        # 1. Section Inspection
        for section in pe.sections:
            try:
                sec_name = section.Name.decode("latin-1").strip("\x00")
            except Exception:
                sec_name = "unknown"

            try:
                sec_entropy = section.get_entropy()
            except Exception:
                sec_entropy = 0.0

            if sec_entropy > highest_section_entropy:
                highest_section_entropy = sec_entropy

            # Check section flags for RWX (Execute + Write)
            characteristics = getattr(section, "Characteristics", 0)
            is_executable = bool(characteristics & 0x20000000)  # IMAGE_SCN_MEM_EXECUTE
            is_writable = bool(characteristics & 0x80000000)    # IMAGE_SCN_MEM_WRITE

            if is_executable and is_writable:
                has_rwx_section = True
                suspicious_indicators.append(f"Section {sec_name} has RWX (Read-Write-Execute) memory permissions")

            # Check for packing: high entropy in executable section
            if is_executable and sec_entropy > 7.4:
                suspicious_indicators.append(f"Executable section {sec_name} has high entropy ({sec_entropy:.2f}), indicating packing or obfuscation")

        # 2. Import Address Table (IAT) Inspection
        imported_apis: Set[str] = set()
        if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
            for entry in pe.DIRECTORY_ENTRY_IMPORT:
                for imp in entry.imports:
                    if imp and imp.name:
                        try:
                            api_name = imp.name.decode("utf-8")
                            imported_apis.add(api_name)
                        except Exception:
                            pass

        # Evaluate against known malicious API combinations
        api_match_found = None
        for api_rule in SUSPICIOUS_API_SETS:
            matching = imported_apis.intersection(api_rule["apis"])
            if len(matching) >= min(len(api_rule["apis"]), 2):
                suspicious_indicators.append(
                    f"{api_rule['name']}: Matched APIs {list(matching)}"
                )
                api_match_found = api_rule

        # Determine Verdict
        if has_rwx_section and highest_section_entropy > 7.4:
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory.SUSPICIOUS_PE,
                detection_name="Heuristic.PE.HighEntropy.RWX",
                severity=ThreatSeverity.HIGH,
                detection_method=DetectionMethod.PE_ANOMALY,
                confidence=0.88,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={
                    "indicators": suspicious_indicators,
                    "max_entropy": round(highest_section_entropy, 2),
                    "has_rwx": has_rwx_section
                }
            )

        if api_match_found and highest_section_entropy > 7.0:
            return DetectionResult(
                file_path=file_path,
                sha256="",
                category=DetectionCategory[api_match_found["category"]],
                detection_name=api_match_found["name"],
                severity=ThreatSeverity[api_match_found["severity"]],
                detection_method=DetectionMethod.PE_ANOMALY,
                confidence=api_match_found["confidence"],
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={
                    "indicators": suspicious_indicators,
                    "rule": api_match_found["description"]
                }
            )

        return None

    except (pefile.PEFormatError, Exception):
        return None
    finally:
        if pe is not None:
            try:
                pe.close()
            except Exception:
                pass


def check_suspicious_extension(file_path: str) -> Optional[DetectionResult]:
    """Detects files matching known ransomware or dangerous executable masquerading extensions."""
    _, ext = os.path.splitext(file_path.lower())
    if ext in RANSOMWARE_EXTENSIONS:
        return DetectionResult(
            file_path=file_path,
            sha256="",
            category=DetectionCategory.RANSOMWARE,
            detection_name=f"Heuristic.Ransomware.Extension{ext}",
            severity=ThreatSeverity.HIGH,
            detection_method=DetectionMethod.HEURISTIC_ENTROPY,
            confidence=0.80,
            recommended_action="QUARANTINE",
            details={"suspicious_extension": ext}
        )
    return None
