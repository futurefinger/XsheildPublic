"""
XSHEILD Native Windows Toast Notifications & Gaming Mode Service
Owner: Future Finger Technologies

Provides:
1. Native Windows 10/11 Action Center toast notifications for real-time threat interception,
   scan completions, and system security status.
2. Gaming / Silent Mode manager to suppress popups and audio chimes during fullscreen applications.
"""

import os
import sys
import json
import logging
import subprocess
import threading
from typing import Dict, Any, Optional

logger = logging.getLogger("xsheild.notifications")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BRANDING_DIR = os.path.join(ROOT_DIR, "assets", "branding")
APP_ICON_PATH = os.path.join(BRANDING_DIR, "xsheild.ico")
APP_ID = "FutureFinger.XSHEILD.EndpointSecurity"

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
GAMING_MODE_FILE = os.path.join(CONFIG_DIR, "gaming_mode.json")


class GamingModeManager:
    """Manages Silent / Gaming Mode state to prevent disruptive alerts."""

    def __init__(self, config_path: str = GAMING_MODE_FILE):
        self.config_path = config_path
        self._lock = threading.Lock()
        self._is_active = False
        self._load_state()

    def _load_state(self) -> None:
        try:
            if os.path.isfile(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._is_active = bool(data.get("gaming_mode_enabled", False))
        except Exception as e:
            logger.warning(f"Failed to load gaming mode config: {e}")
            self._is_active = False

    def _save_state(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump({"gaming_mode_enabled": self._is_active}, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save gaming mode config: {e}")

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._is_active

    def set_gaming_mode(self, enabled: bool) -> bool:
        with self._lock:
            self._is_active = bool(enabled)
            self._save_state()
            return self._is_active

    def toggle(self) -> bool:
        with self._lock:
            self._is_active = not self._is_active
            self._save_state()
            return self._is_active


# Global singleton gaming mode manager
gaming_mode_manager = GamingModeManager()


class WindowsNotificationService:
    """Delivers native Windows 10/11 Action Center toast notifications."""

    def __init__(self, gaming_mode: Optional[GamingModeManager] = None):
        self.gaming_mode = gaming_mode or gaming_mode_manager
        self.suppressed_notifications_count = 0

    def show_toast(
        self,
        title: str,
        message: str,
        icon_path: Optional[str] = None,
        sound: bool = True
    ) -> bool:
        """
        Displays a native Windows toast notification via PowerShell WinRT or system balloon.
        Suppresses automatically if Gaming Mode is enabled.
        """
        if self.gaming_mode.is_active:
            self.suppressed_notifications_count += 1
            logger.info(f"[GAMING MODE ACTIVE] Suppressed notification: {title} - {message}")
            return False

        icon = icon_path or APP_ICON_PATH
        if not os.path.isfile(icon):
            icon = ""

        # Windows PowerShell WinRT XML Toast script
        escaped_title = title.replace('"', '`"').replace("'", "''")
        escaped_msg = message.replace('"', '`"').replace("'", "''")

        ps_script = f"""
$appId = '{APP_ID}'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlCommands, ContentType = WindowsRuntime] | Out-Null

$template = @"
<toast duration="short">
    <visual>
        <binding template="ToastGeneric">
            <text>{escaped_title}</text>
            <text>{escaped_msg}</text>
            <text placement="attribution">XSHEILD by Future Finger Technologies</text>
        </binding>
    </visual>
</toast>
"@

$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml($template)
$toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId).Show($toast)
"""

        def _run():
            try:
                # Run PowerShell silently without popup window
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

                subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                    startupinfo=startupinfo,
                    capture_output=True,
                    timeout=5,
                    check=False
                )
            except Exception as e:
                logger.debug(f"Native toast delivery notice: {e}")

        # Dispatch async to avoid blocking calling security threads
        threading.Thread(target=_run, daemon=True).start()
        return True

    def show_threat_alert(self, filename: str, threat_name: str, action: str = "Quarantined") -> bool:
        """Notifies user when an active threat is intercepted and quarantined."""
        title = "🛡️ XSHEILD: Threat Blocked"
        msg = f"Item: {os.path.basename(filename)}\nThreat: {threat_name}\nAction: Secured in AES Vault ({action})"
        return self.show_toast(title, msg)

    def show_scan_complete(self, files_scanned: int, threats_found: int, elapsed_seconds: float) -> bool:
        """Notifies user when an on-demand or scheduled scan finishes."""
        title = "🛡️ XSHEILD: Scan Completed"
        if threats_found == 0:
            msg = f"Scanned {files_scanned} files in {elapsed_seconds:.1f}s.\nZero threats detected — Your system is clean!"
        else:
            msg = f"Scanned {files_scanned} files in {elapsed_seconds:.1f}s.\n⚠️ {threats_found} threat(s) neutralized and isolated."
        return self.show_toast(title, msg)

    def show_startup_verified(self) -> bool:
        """Notifies user that background real-time shield is operational."""
        title = "🛡️ XSHEILD: Protected"
        msg = "Real-Time Guard is active. Your PC is safe."
        return self.show_toast(title, msg)


# Global notification service instance
notification_service = WindowsNotificationService()


def send_windows_notification(title: str, message: str) -> bool:
    """Convenience helper to dispatch a toast notification."""
    return notification_service.show_toast(title, message)
