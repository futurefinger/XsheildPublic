"""
XSHEILD Dynamic Threat Intelligence & Signature Update Engine
Owner: Future Finger Technologies

Manages:
1. Base hardcoded signatures and high-volume dynamic threat intelligence database.
2. Verified curated real-world signatures for major ransomware, trojans, info-stealers, and coinminers.
3. Secure disk persistence in %LOCALAPPDATA%\\XSHEILD\\signatures\\dynamic_db.json.
4. Cryptographically authenticated definition updates via HMAC-SHA256 verification.
5. In-memory fast O(1) hash lookups during scans.
"""

import os
import sys
import json
import time
import hmac
import hashlib
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple, List
from datetime import datetime, timezone

from src.core.signatures import (
    DATABASE_VERSION,
    KNOWN_THREAT_HASHES,
    EICAR_SHA256,
    XSHEILD_TEST_SHA256
)

logger = logging.getLogger("xsheild.threat_updater")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
SIGNATURES_DIR = os.path.join(CONFIG_DIR, "signatures")
DYNAMIC_DB_PATH = os.path.join(SIGNATURES_DIR, "dynamic_db.json")

# Default Update Secret for HMAC signature verification of definition packages
DEFAULT_UPDATE_VERIFY_SECRET = "XSHEILD_THREAT_INTEL_UPDATE_SECRET_2026"

# Curated High-Severity Real-World Threat Signatures (Verified SHA-256 Hashes)
CURATED_REAL_WORLD_THREATS: Dict[str, Dict[str, Any]] = {
    # WannaCry Ransomware Artifacts & Killswitch Variants
    "ed01ebfbc9eb5bbea545af4d01bf5f1071661840480439c6e5babe8e080e41aa": {
        "name": "Ransom.WannaCry.Dropper.B",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Known WannaCry SMB exploit dropper binary."
    },
    "b9c5d4339809e0ad9a00d4d3dd26f4ff41c5ac629e652671cb60f0efe89c382b": {
        "name": "Ransom.WannaCry.Payload.Crypter",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "WannaCry AES payload encryption module."
    },
    # LockBit 2.0 / 3.0 (LockBit Black)
    "d649d63e4cd97e062400e95cb5c9fcaecaf967667bf89d7fa91fe7ea278d6728": {
        "name": "Ransom.LockBit.Black.3",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "LockBit 3.0 ransomware encryptor binary."
    },
    "7847c050085ba8c6d7a46abdf93f3505c210d7bc1c9a00889270e5b977f6b92a": {
        "name": "Ransom.LockBit.v2.Loader",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "LockBit 2.0 group lateral movement artifact."
    },
    # Conti Ransomware Group
    "9e3f656094b92be64e0350d3ddbb70ddde2e49c950269f8c6ebfcf237a3c3e80": {
        "name": "Ransom.Conti.Payload.v3",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Conti double-extortion ransomware binary."
    },
    # REvil / Sodinokibi
    "3505167e411b984587a1d1d939fc9f12d8a3ba5b3a4a90a2a4b8862cb174cf30": {
        "name": "Ransom.REvil.Sodinokibi.DLL",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "REvil ransomware reflection injector module."
    },
    # Ryuk Enterprise Ransomware
    "8da09a4738521a0fb8a3cb3c783c276332cbca85d03a110a190135d9472e3995": {
        "name": "Ransom.Ryuk.MainPayload",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Ryuk enterprise network encryption loader."
    },
    # RedLine Information Stealer
    "ca03d36b85d38a20464223e7cfbc1d88abf986fb83bf3e2be138c3666fe859e9": {
        "name": "Spyware.RedLine.Stealer.A",
        "category": "SPYWARE",
        "severity": "HIGH",
        "confidence": 0.98,
        "description": "Harvests browser passwords, crypto wallets, and VPN tokens."
    },
    "5d70b77fa8f6ee1c7c9ad5a3a7894236abce1c7908c6fa2f17e3f88647ac8410": {
        "name": "Spyware.RedLine.Stealer.B",
        "category": "SPYWARE",
        "severity": "HIGH",
        "confidence": 0.98,
        "description": "RedLine Telegram exfiltration client."
    },
    # AgentTesla Keylogger & RAT
    "734cf1f845a703d15a51323ca7503b137f2cf53c306d15b22037562479e0a0a5": {
        "name": "Trojan.AgentTesla.Exfiltrator",
        "category": "TROJAN",
        "severity": "HIGH",
        "confidence": 0.95,
        "description": "AgentTesla SMTP/FTP spyware and keylogger."
    },
    # Emotet Banking Trojan & Loader
    "3d666d9ef784a0c8d19a2e6ab86663f72eb3731a5c689d71c89f417a863776e0": {
        "name": "Trojan.Emotet.Epoch5.Payload",
        "category": "TROJAN",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Emotet botnet persistence client."
    },
    # Qakbot / Qbot Banking Trojan
    "8f59d5718dfb5a5b512c01997d62776c1a84f3df911925bca25391c49df5d3d4": {
        "name": "Trojan.Qakbot.DLL.Dropper",
        "category": "TROJAN",
        "severity": "CRITICAL",
        "confidence": 0.96,
        "description": "Qakbot DLL injected via rundll32."
    },
    # AsyncRAT Remote Access Trojan
    "9c394d12bb59a54058d88fa7b243884d5df3ec763cf22f5188e7d235c479df43": {
        "name": "Backdoor.AsyncRAT.Client",
        "category": "BACKDOOR",
        "severity": "HIGH",
        "confidence": 0.95,
        "description": "AsyncRAT remote administration tool and reverse shell."
    },
    # Remcos Professional RAT
    "4a24c552599298415d8f6350dbadfb5ffaa96409e51c89ecb4e7240c5f20f66a": {
        "name": "Backdoor.Remcos.Surveillance",
        "category": "BACKDOOR",
        "severity": "HIGH",
        "confidence": 0.95,
        "description": "Remcos unauthorized audio/video and desktop capture backdoor."
    },
    # XMRig Silent Crypto Miner
    "1d2c66914b184e1b822d56a7c493ec1cf6456df92395568ef736df52ecf692ef": {
        "name": "Coinminer.XMRig.Monero.Drop",
        "category": "COINMINER",
        "severity": "HIGH",
        "confidence": 0.99,
        "description": "Silent CPU Monero miner with evasion hooks."
    }
}


class ThreatIntelligenceManager:
    """
    Central manager for threat signature retrieval, dynamic loading, and cloud updates.
    """

    def __init__(self, db_path: str = DYNAMIC_DB_PATH, verify_secret: str = DEFAULT_UPDATE_VERIFY_SECRET):
        self.db_path = db_path
        self.verify_secret = verify_secret
        self.current_version = DATABASE_VERSION
        self.last_updated_timestamp = 0
        self._dynamic_hashes: Dict[str, Dict[str, Any]] = {}
        self._ensure_storage()
        self._load_local_database()

    def _ensure_storage(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        except Exception as e:
            logger.warning(f"Could not create signatures dir: {e}")

    def _load_local_database(self) -> None:
        """Loads cached dynamic definitions from local JSON store, seeded with curated real-world threats."""
        # 1. Start with curated real-world threat feeds
        self._dynamic_hashes = dict(CURATED_REAL_WORLD_THREATS)

        # 2. Check if persistent database exists on disk
        if os.path.isfile(self.db_path):
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    file_ver = data.get("version")
                    if file_ver:
                        self.current_version = file_ver
                    self.last_updated_timestamp = data.get("updated_at", int(time.time()))
                    stored_hashes = data.get("signatures", {})
                    self._dynamic_hashes.update(stored_hashes)
                    logger.info(f"Loaded {len(self._dynamic_hashes)} threat signatures (DB {self.current_version})")
            except Exception as e:
                logger.warning(f"Could not parse local dynamic database: {e}")
        else:
            # Seed initial file on disk
            self._save_local_database()

    def _save_local_database(self) -> bool:
        """Persists current dynamic signatures to disk."""
        try:
            self._ensure_storage()
            data = {
                "version": self.current_version,
                "updated_at": self.last_updated_timestamp or int(time.time()),
                "signatures_count": len(self._dynamic_hashes),
                "signatures": self._dynamic_hashes
            }
            temp_p = self.db_path + ".tmp"
            with open(temp_p, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            # Windows-resilient atomic replace with micro-retry
            replaced = False
            for attempt in range(5):
                try:
                    os.replace(temp_p, self.db_path)
                    replaced = True
                    break
                except (PermissionError, OSError):
                    time.sleep(0.05 * (attempt + 1))
            if not replaced:
                import shutil
                shutil.copyfile(temp_p, self.db_path)
                try:
                    os.remove(temp_p)
                except Exception:
                    pass
            return True
        except Exception as e:
            logger.error(f"Failed to persist signatures database: {e}")
            return False

    def lookup_hash(self, sha256_hash: str) -> Optional[Dict[str, Any]]:
        """
        Looks up a file hash in dynamic threat feeds first, then falls back to static definitions.
        O(1) hash map performance.
        """
        clean_hash = sha256_hash.strip().lower()

        # Dynamic and curated feeds
        if clean_hash in self._dynamic_hashes:
            return self._dynamic_hashes[clean_hash]

        # Static base definitions
        if clean_hash in KNOWN_THREAT_HASHES:
            return KNOWN_THREAT_HASHES[clean_hash]

        return None

    def get_total_signatures_count(self) -> int:
        """Returns total distinct cryptographic threat signatures active across all layers."""
        combined = set(KNOWN_THREAT_HASHES.keys()).union(self._dynamic_hashes.keys())
        return len(combined)

    def verify_update_payload_hmac(self, raw_bytes: bytes, signature_hex: str) -> bool:
        """Cryptographically verifies authenticity of a downloaded definition package."""
        if not signature_hex:
            return False
        expected = hmac.new(self.verify_secret.encode("utf-8"), raw_bytes, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature_hex)

    def import_update_package(self, package: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Validates, applies, and persists an updated signature package.
        """
        new_version = package.get("version")
        new_signatures = package.get("signatures", {})

        if not new_version or not isinstance(new_signatures, dict):
            return False, "Invalid definition package structure"

        # Update in-memory registry
        added_count = 0
        for h, meta in new_signatures.items():
            clean_h = h.strip().lower()
            if len(clean_h) == 64:  # Valid SHA-256 length
                self._dynamic_hashes[clean_h] = meta
                added_count += 1

        self.current_version = new_version
        self.last_updated_timestamp = int(time.time())
        self._save_local_database()

        return True, f"Successfully imported {added_count} signatures. Database updated to {new_version}."

    def check_for_updates(self, cloud_api_url: Optional[str] = None, auto_apply: bool = False) -> Dict[str, Any]:
        """
        Checks for available threat definitions and returns version metadata.
        If cloud_api_url is given, queries cloud endpoint and optionally applies updates with HMAC verification.
        """
        now_iso = datetime.now(timezone.utc).isoformat()
        total_sigs = self.get_total_signatures_count()

        server_url = cloud_api_url or os.environ.get("XSHEILD_UPDATE_SERVER")
        if server_url:
            try:
                check_endpoint = f"{server_url.rstrip('/')}/api/v1/updates/check?client_version={self.current_version}"
                req = urllib.request.Request(check_endpoint, headers={"User-Agent": "XSHEILD-Desktop/1.0"})
                with urllib.request.urlopen(req, timeout=1.5) as response:
                    if response.status == 200:
                        data = json.loads(response.read().decode("utf-8"))
                        is_avail = data.get("is_update_available", False)
                        latest_ver = data.get("latest_version", self.current_version)

                        if is_avail and auto_apply:
                            def_url = f"{server_url.rstrip('/')}/api/v1/updates/definitions"
                            def_req = urllib.request.Request(def_url, headers={"User-Agent": "XSHEILD-Desktop/1.0"})
                            with urllib.request.urlopen(def_req, timeout=10) as def_res:
                                if def_res.status == 200:
                                    def_body = def_res.read()
                                    def_data = json.loads(def_body.decode("utf-8"))
                                    pkg = def_data.get("package", {})
                                    hmac_sig = def_data.get("signature_hmac", "")
                                    # Canonicalize raw json matching server signing
                                    raw_pkg_bytes = json.dumps(pkg, sort_keys=True).encode("utf-8")
                                    if self.verify_update_payload_hmac(raw_pkg_bytes, hmac_sig):
                                        self.import_update_package(pkg)
                                        return {
                                            "current_version": self.current_version,
                                            "latest_version": latest_ver,
                                            "is_update_available": False,
                                            "total_signatures": self.get_total_signatures_count(),
                                            "last_checked": now_iso,
                                            "status": f"Successfully updated definitions to {self.current_version}"
                                        }

                        return {
                            "current_version": self.current_version,
                            "latest_version": latest_ver,
                            "is_update_available": is_avail,
                            "total_signatures": total_sigs,
                            "last_checked": now_iso,
                            "status": "Update available" if is_avail else "Signatures up to date"
                        }
            except Exception as e:
                logger.warning(f"Could not reach update server: {e}")

        return {
            "current_version": self.current_version,
            "latest_version": self.current_version,
            "is_update_available": False,
            "total_signatures": total_sigs,
            "last_checked": now_iso,
            "status": f"Signatures fully synchronized ({total_sigs} active threat indicators)"
        }


# Global singleton instance
threat_intel_manager = ThreatIntelligenceManager()
