"""
XSHEILD Single Instance & IPC Process Coordinator
Owner: Future Finger Technologies

Ensures only a single instance of XSHEILD executes at any given time.
When a second instance is launched (e.g. from desktop shortcut, Start Menu, or command line):
1. Detects the existing active instance via Win32 Mutex and local loopback IPC.
2. Directs the active instance to restore and focus its dashboard window.
3. The secondary instance immediately exits cleanly without creating duplicate tray icons
   or duplicate filesystem watchers.
"""

import os
import sys
import socket
import logging
import threading
from typing import Optional, Callable

logger = logging.getLogger("xsheild.single_instance")

IPC_DEFAULT_PORT = 49281
IPC_HOST = "127.0.0.1"


class SingleInstanceManager:
    """Manages cross-process single instance locking and inter-process activation commands."""

    def __init__(self, port: int = IPC_DEFAULT_PORT, mutex_name: str = "Local\\XSHEILD_Security_Sentinel_Mutex"):
        self.port = port
        self.mutex_name = mutex_name
        self._mutex_handle = None
        self._server_socket: Optional[socket.socket] = None
        self._listener_thread: Optional[threading.Thread] = None
        self._running = False
        self._on_command: Optional[Callable[[str], None]] = None

    def acquire(self, on_command: Optional[Callable[[str], None]] = None) -> bool:
        """
        Attempts to acquire single-instance master ownership.
        Returns True if this is the PRIMARY instance.
        Returns False if an instance is ALREADY RUNNING.
        """
        self._on_command = on_command

        # 1. First probe if an existing instance's IPC server is responsive
        if self._probe_existing_instance():
            logger.info("Existing XSHEILD instance detected via IPC. Notifying existing instance to focus.")
            return False

        # 2. On Windows, attempt to acquire named Mutex
        if sys.platform == "win32":
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                self._mutex_handle = kernel32.CreateMutexW(None, True, self.mutex_name)
                last_error = kernel32.GetLastError()
                ERROR_ALREADY_EXISTS = 183
                if last_error == ERROR_ALREADY_EXISTS:
                    logger.info("Win32 Mutex already held by another instance.")
                    # Try sending restore signal again
                    self._send_ipc_command("RESTORE")
                    return False
            except Exception as e:
                logger.warning(f"Win32 Mutex acquisition warning: {e}")

        # 3. Bind local loopback IPC server to receive activation signals
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((IPC_HOST, self.port))
            srv.listen(5)
            self._server_socket = srv
            self._running = True

            self._listener_thread = threading.Thread(
                target=self._listen_loop,
                daemon=True,
                name="XSheildIPCListener"
            )
            self._listener_thread.start()
            logger.info(f"XSHEILD single-instance primary owner established on {IPC_HOST}:{self.port}")
            return True
        except OSError as e:
            logger.warning(f"Could not bind IPC port {self.port}: {e}. Probing for peer...")
            if self._send_ipc_command("RESTORE"):
                return False
            # Port might be in TIME_WAIT or temporarily held; still proceed if mutex succeeded
            return True

    def notify_existing_and_exit(self, command: str = "RESTORE") -> bool:
        """
        Sends activation command to active instance and terminates current process if acknowledged.
        Grants Win32 foreground elevation permission to ensure the primary window surfaces instantly.
        Returns True if acknowledged, False if active instance failed to respond.
        """
        logger.info(f"Dispatching '{command}' to running XSHEILD instance.")
        if sys.platform == "win32":
            try:
                import ctypes
                # ASFW_ANY (-1 / 0xFFFFFFFF): Authorize active process to take foreground window focus
                ctypes.windll.user32.AllowSetForegroundWindow(-1)
            except Exception as e:
                logger.debug(f"AllowSetForegroundWindow notice: {e}")

        delivered = self._send_ipc_command(command)
        if delivered:
            logger.info("Activation command acknowledged by primary instance. Exiting secondary process cleanly.")
            sys.exit(0)
        else:
            logger.warning(f"Activation command '{command}' failed delivery. Primary instance may be unresponsive.")
            return False

    def _probe_existing_instance(self) -> bool:
        """Checks if another instance is listening and responsive."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.6)
                s.connect((IPC_HOST, self.port))
                s.sendall(b"PING\n")
                resp = s.recv(128).decode("utf-8", errors="ignore").strip()
                return "PONG" in resp or "ACK" in resp
        except Exception:
            return False

    def _send_ipc_command(self, command: str) -> bool:
        """Sends a plain command string to the active instance."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1.2)
                s.connect((IPC_HOST, self.port))
                payload = f"{command.strip()}\n".encode("utf-8")
                s.sendall(payload)
                resp = s.recv(128).decode("utf-8", errors="ignore").strip()
                return "ACK" in resp
        except Exception as e:
            logger.debug(f"IPC dispatch error: {e}")
            return False

    def _listen_loop(self) -> None:
        """Background listener accepting activation messages from secondary instances."""
        if not self._server_socket:
            return

        while self._running:
            try:
                client_sock, _ = self._server_socket.accept()
                client_sock.settimeout(1.0)
                threading.Thread(
                    target=self._handle_client,
                    args=(client_sock,),
                    daemon=True,
                    name="XSheildIPCClient"
                ).start()
            except Exception:
                if not self._running:
                    break

    def _handle_client(self, sock: socket.socket) -> None:
        try:
            with sock:
                data = sock.recv(256).decode("utf-8", errors="ignore").strip()
                if not data:
                    return

                if data == "PING":
                    sock.sendall(b"PONG\n")
                    return

                # Send acknowledgment
                sock.sendall(b"ACK\n")

                if self._on_command:
                    try:
                        self._on_command(data)
                    except Exception as e:
                        logger.error(f"Error handling IPC command '{data}': {e}")
        except Exception:
            pass

    def release(self) -> None:
        """Releases the Mutex and stops the IPC server."""
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except Exception:
                pass
            self._server_socket = None

        if self._mutex_handle and sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self._mutex_handle)
            except Exception:
                pass
            self._mutex_handle = None


# Global coordinator instance
single_instance_manager = SingleInstanceManager()
