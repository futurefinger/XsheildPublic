"""
XSHEILD Advanced Script, Living-Off-The-Land (LotL) & Fileless Threat Analyzer
Owner: Future Finger Technologies

Inspects PowerShell, Batch, VBScript, and JavaScript payloads for:
1. Obfuscated Base64-encoded PowerShell commands (decodes UTF-16LE / ASCII inner layers).
2. AMSI (Antimalware Scan Interface) bypass and memory patching primitives.
3. Malicious download cradles (Net.WebClient, Invoke-WebRequest, CertUtil, BitsAdmin).
4. Living-Off-The-Land Binaries (LOLBins) abuse (Mshta, Regsvr32, Wmic, Rundll32).
5. Volume Shadow Copy destruction (vssadmin, bcdedit, wmic shadowcopy).
6. Memory credential dumping signatures (Mimikatz syntax, LSASS access).
"""

import re
import os
import base64
import logging
from typing import Optional, Dict, Any, List, Tuple

from src.core.models import (
    DetectionResult,
    ThreatSeverity,
    DetectionCategory,
    DetectionMethod
)

logger = logging.getLogger("xsheild.script_analyzer")

# Regex to identify Base64-encoded blocks in PowerShell arguments
PS_BASE64_PATTERN = re.compile(
    r"(?:-(?:e|enc|encodedcommand)\s+)([A-Za-z0-9+/=]{20,})",
    re.IGNORECASE
)

def _decode_sig(masked: bytes, key: int = 0x5B) -> bytes:
    return bytes([b ^ key for b in masked])


# High-Severity Signature Indicators (XOR masked to eliminate AV heuristic false positives)
AMSI_BYPASS_PATTERNS: List[Tuple[bytes, str]] = [
    (_decode_sig(bytes([40, 34, 40, 47, 62, 54, 117, 54, 58, 53, 58, 60, 62, 54, 62, 53, 47, 117, 58, 46, 47, 52, 54, 58, 47, 50, 52, 53, 117, 58, 54, 40, 50, 46, 47, 50, 55, 40])), "AMSI.Bypass.AmsiUtilsReflection"),
    (_decode_sig(bytes([58, 54, 40, 50, 50, 53, 50, 47, 61, 58, 50, 55, 62, 63])), "AMSI.Bypass.AmsiInitFailedPatch"),
    (_decode_sig(bytes([58, 54, 40, 50, 40, 56, 58, 53, 57, 46, 61, 61, 62, 41])), "AMSI.Bypass.AmsiScanBufferPatch"),
    (_decode_sig(bytes([58, 54, 40, 50, 117, 63, 55, 55])), "AMSI.Bypass.DirectDllHooking"),
]

DOWNLOAD_CRADLE_PATTERNS: List[Tuple[bytes, str]] = [
    (_decode_sig(bytes([53, 62, 47, 117, 44, 62, 57, 56, 55, 50, 62, 53, 47, 114, 117, 63, 52, 44, 53, 55, 52, 58, 63, 40, 47, 41, 50, 53, 60])), "Script.PowerShell.DownloadCradle.WebClientString"),
    (_decode_sig(bytes([53, 62, 47, 117, 44, 62, 57, 56, 55, 50, 62, 53, 47, 114, 117, 63, 52, 44, 53, 55, 52, 58, 63, 61, 50, 55, 62])), "Script.PowerShell.DownloadCradle.WebClientFile"),
    (_decode_sig(bytes([50, 53, 45, 52, 48, 62, 118, 44, 62, 57, 41, 62, 42, 46, 62, 40, 47])), "Script.PowerShell.DownloadCradle.IWR"),
    (_decode_sig(bytes([56, 62, 41, 47, 46, 47, 50, 55, 123, 118, 46, 41, 55, 56, 58, 56, 51, 62, 123, 118, 40, 43, 55, 50, 47, 123, 118, 61])), "LOLBin.CertUtil.RemoteDownload"),
    (_decode_sig(bytes([56, 62, 41, 47, 46, 47, 50, 55, 117, 62, 35, 62, 123, 118, 46, 41, 55, 56, 58, 56, 51, 62])), "LOLBin.CertUtil.RemoteDownload"),
    (_decode_sig(bytes([57, 50, 47, 40, 58, 63, 54, 50, 53, 123, 116, 47, 41, 58, 53, 40, 61, 62, 41])), "LOLBin.BitsAdmin.DownloadJob"),
    (_decode_sig(bytes([40, 47, 58, 41, 47, 118, 57, 50, 47, 40, 47, 41, 58, 53, 40, 61, 62, 41])), "Script.PowerShell.BitsTransfer"),
]

LOLBIN_EXECUTION_PATTERNS: List[Tuple[bytes, str]] = [
    (_decode_sig(bytes([54, 40, 51, 47, 58, 117, 62, 35, 62, 123, 45, 57, 40, 56, 41, 50, 43, 47, 97, 62, 35, 62, 56, 46, 47, 62])), "LOLBin.Mshta.InlineVBScript"),
    (_decode_sig(bytes([54, 40, 51, 47, 58, 123, 45, 57, 40, 56, 41, 50, 43, 47, 97, 62, 35, 62, 56, 46, 47, 62])), "LOLBin.Mshta.InlineVBScript"),
    (_decode_sig(bytes([54, 40, 51, 47, 58, 123, 51, 47, 47, 43])), "LOLBin.Mshta.RemoteScriptInvocation"),
    (_decode_sig(bytes([41, 62, 60, 40, 45, 41, 104, 105, 123, 116, 40, 123, 116, 53, 123, 116, 46, 123, 116, 50, 97])), "LOLBin.Regsvr32.Squiblydoo"),
    (_decode_sig(bytes([41, 62, 60, 40, 45, 41, 104, 105, 117, 62, 35, 62, 123, 116, 40, 123, 116, 53, 123, 116, 46, 123, 116, 50, 97])), "LOLBin.Regsvr32.Squiblydoo"),
    (_decode_sig(bytes([44, 54, 50, 56, 123, 43, 41, 52, 56, 62, 40, 40, 123, 56, 58, 55, 55, 123, 56, 41, 62, 58, 47, 62])), "LOLBin.Wmic.ProcessInjection"),
]

RANSOMWARE_DEFENSE_PATTERNS: List[Tuple[bytes, str]] = [
    (_decode_sig(bytes([45, 40, 40, 58, 63, 54, 50, 53, 123, 63, 62, 55, 62, 47, 62, 123, 40, 51, 58, 63, 52, 44, 40])), "Behavior.Ransomware.ShadowCopyDeletion"),
    (_decode_sig(bytes([45, 40, 40, 58, 63, 54, 50, 53, 117, 62, 35, 62, 123, 63, 62, 55, 62, 47, 62, 123, 40, 51, 58, 63, 52, 44, 40])), "Behavior.Ransomware.ShadowCopyDeletion"),
    (_decode_sig(bytes([44, 54, 50, 56, 123, 40, 51, 58, 63, 52, 44, 56, 52, 43, 34, 123, 63, 62, 55, 62, 47, 62])), "Behavior.Ransomware.ShadowCopyWmic"),
    (_decode_sig(bytes([44, 57, 58, 63, 54, 50, 53, 123, 63, 62, 55, 62, 47, 62, 123, 56, 58, 47, 58, 55, 52, 60, 123, 118, 42, 46, 50, 62, 47])), "Behavior.Ransomware.BackupDestruction"),
    (_decode_sig(bytes([57, 56, 63, 62, 63, 50, 47, 123, 116, 40, 62, 47, 123, 32, 63, 62, 61, 58, 46, 55, 47, 38, 123, 41, 62, 56, 52, 45, 62, 41, 34, 62, 53, 58, 57, 55, 62, 63, 123, 53, 52])), "Behavior.Ransomware.BcdeditRecoveryDisabled"),
    (_decode_sig(bytes([57, 56, 63, 62, 63, 50, 47, 123, 116, 40, 62, 47, 123, 32, 63, 62, 61, 58, 46, 55, 47, 38, 123, 57, 52, 52, 47, 40, 47, 58, 47, 46, 40, 43, 52, 55, 50, 56, 34, 123, 50, 60, 53, 52, 41, 62, 58, 55, 55, 61, 58, 50, 55, 46, 41, 62, 40])), "Behavior.Ransomware.BcdeditIgnoreFailures"),
]

CREDENTIAL_DUMPING_PATTERNS: List[Tuple[bytes, str]] = [
    (_decode_sig(bytes([40, 62, 48, 46, 41, 55, 40, 58, 97, 97, 55, 52, 60, 52, 53, 43, 58, 40, 40, 44, 52, 41, 63, 40])), "HackTool.Mimikatz.LogonPasswords"),
    (_decode_sig(bytes([55, 40, 58, 63, 46, 54, 43, 97, 97, 40, 58, 54])), "HackTool.Mimikatz.LsaDumpSam"),
    (_decode_sig(bytes([43, 41, 50, 45, 50, 55, 62, 60, 62, 97, 97, 63, 62, 57, 46, 60])), "HackTool.Mimikatz.PrivilegeDebug"),
    (_decode_sig(bytes([40, 62, 48, 46, 41, 55, 40, 58, 97, 97, 47, 50, 56, 48, 62, 47, 40])), "HackTool.Mimikatz.KerberosTickets"),
]


def decode_powershell_base64(encoded_str: str) -> Optional[str]:
    """
    Decodes PowerShell UTF-16LE (or ASCII) base64 strings to plain text.
    Detects whether encoded bytes represent UTF-16LE or ASCII/UTF-8.
    """
    try:
        raw = base64.b64decode(encoded_str)
        # UTF-16LE encoded strings for ASCII characters contain null bytes
        if b"\x00" in raw:
            try:
                return raw.decode("utf-16le")
            except Exception:
                pass
        # Fallback to UTF-8
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                return raw.decode("utf-16le")
            except Exception:
                return raw.decode("latin-1", errors="ignore")
    except Exception:
        return None


def inspect_script_payload(
    content: bytes,
    file_path: str,
    sha256: str = "",
    md5: str = "",
    sha1: str = "",
    file_size: int = 0
) -> Optional[DetectionResult]:
    """
    Deeply analyzes script contents, unrolls Base64 obfuscation, and tests against behavioral indicators.
    """
    lower_content = content.lower()

    # 1. Check direct Volume Shadow Copy Destruction (Ransomware Pre-cursor)
    for pattern, name in RANSOMWARE_DEFENSE_PATTERNS:
        if pattern in lower_content:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.RANSOMWARE,
                detection_name=name,
                severity=ThreatSeverity.CRITICAL,
                detection_method=DetectionMethod.SIGNATURE_MATCH,
                confidence=0.99,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"matched_behavior": pattern.decode("latin-1")}
            )

    # 2. Check Credential Dumping Signatures (Mimikatz / LSASS Injection)
    for pattern, name in CREDENTIAL_DUMPING_PATTERNS:
        if pattern in lower_content:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.TROJAN,
                detection_name=name,
                severity=ThreatSeverity.CRITICAL,
                detection_method=DetectionMethod.SIGNATURE_MATCH,
                confidence=0.98,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"matched_tool_syntax": pattern.decode("latin-1")}
            )

    # 3. Check AMSI Bypass Primitives
    for pattern, name in AMSI_BYPASS_PATTERNS:
        if pattern in lower_content:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.SUSPICIOUS_SCRIPT,
                detection_name=name,
                severity=ThreatSeverity.HIGH,
                detection_method=DetectionMethod.HEURISTIC,
                confidence=0.95,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"amsi_indicator": pattern.decode("latin-1")}
            )

    # 4. Check Living-Off-The-Land (LOLBin) Invocations
    for pattern, name in LOLBIN_EXECUTION_PATTERNS:
        if pattern in lower_content:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.SUSPICIOUS_SCRIPT,
                detection_name=name,
                severity=ThreatSeverity.HIGH,
                detection_method=DetectionMethod.HEURISTIC,
                confidence=0.90,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"lolbin_pattern": pattern.decode("latin-1")}
            )

    # 5. Check Malicious Download Cradles
    for pattern, name in DOWNLOAD_CRADLE_PATTERNS:
        if pattern in lower_content:
            return DetectionResult(
                file_path=file_path,
                sha256=sha256,
                md5=md5,
                sha1=sha1,
                category=DetectionCategory.TROJAN,
                detection_name=name,
                severity=ThreatSeverity.HIGH,
                detection_method=DetectionMethod.SIGNATURE_MATCH,
                confidence=0.92,
                file_size_bytes=file_size,
                recommended_action="QUARANTINE",
                details={"download_cradle": pattern.decode("latin-1")}
            )

    # 6. Unroll Base64 Obfuscated PowerShell Commands
    try:
        content_text = content.decode("utf-8", errors="ignore")
    except Exception:
        content_text = ""

    if content_text:
        matches = PS_BASE64_PATTERN.findall(content_text)
        for b64_match in matches:
            decoded = decode_powershell_base64(b64_match)
            if decoded:
                decoded_lower = decoded.lower()
                # Inspect inner payload
                for pattern, name in (
                    AMSI_BYPASS_PATTERNS +
                    DOWNLOAD_CRADLE_PATTERNS +
                    RANSOMWARE_DEFENSE_PATTERNS +
                    CREDENTIAL_DUMPING_PATTERNS
                ):
                    if pattern.decode("latin-1") in decoded_lower:
                        return DetectionResult(
                            file_path=file_path,
                            sha256=sha256,
                            md5=md5,
                            sha1=sha1,
                            category=DetectionCategory.SUSPICIOUS_SCRIPT,
                            detection_name=f"Obfuscated.{name}",
                            severity=ThreatSeverity.CRITICAL,
                            detection_method=DetectionMethod.HEURISTIC,
                            confidence=0.98,
                            file_size_bytes=file_size,
                            recommended_action="QUARANTINE",
                            details={
                                "obfuscation": "Base64-Encoded PowerShell",
                                "decoded_match": pattern.decode("latin-1"),
                                "snippet": decoded[:120]
                            }
                        )

    return None
