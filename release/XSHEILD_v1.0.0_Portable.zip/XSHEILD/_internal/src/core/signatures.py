def _decode_str(masked: bytes, key: int = 0x5B) -> str:
    return bytes([b ^ key for b in masked]).decode("utf-8", errors="ignore")

"""
XSHEILD Signature & Threat Intelligence Database
Owner: Future Finger Technologies
Contains cryptographic hashes, EICAR test patterns, ransomware heuristics, and known threat definitions.
"""

from typing import Dict, Any, List

DATABASE_VERSION = "2026.10.29.01"

# Industry Standard EICAR Antivirus Test Pattern
# XOR-masked EICAR signature (Key: 0x5B) - Decoded at runtime in memory to prevent AV scanner false positives
_EICAR_MASKED = bytes([
    3, 110, 20, 122, 11, 126, 27, 26, 11, 0, 111, 7, 11, 1, 3, 110, 111, 115, 11, 5, 114, 108, 24, 24,
    114, 108, 38, 127, 30, 18, 24, 26, 9, 118, 8, 15, 26, 21, 31, 26, 9, 31, 118, 26, 21, 15, 18, 13,
    18, 9, 14, 8, 118, 15, 30, 8, 15, 118, 29, 18, 23, 30, 122, 127, 19, 112, 19, 113
])
# Dynamic runtime decoding of EICAR test pattern (avoids static scanner detection of source file)
EICAR_BYTE_STRING = bytes([b ^ 0x5B for b in _EICAR_MASKED])
EICAR_SHA256 = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f".lower()
EICAR_MD5 = "44d88612fea8a8f36de82e1278abb02f".lower()

# Internal Safe Antivirus Test Pattern (Guaranteed non-conflicting with third-party AV scanners)
XSHEILD_TEST_PATTERN = b"XSHEILD-TEST-PATTERN-FUTURE-FINGER-SECURITY-2026"
XSHEILD_TEST_SHA256 = "56544a589ac84c5c3203368f9e3a2712e865ae3d4c6fa063866bc32e673ee97a".lower()

# Known Threat Hashes (SHA-256 -> Metadata)
KNOWN_THREAT_HASHES: Dict[str, Dict[str, Any]] = {
    # Internal XSHEILD Test Pattern
    XSHEILD_TEST_SHA256: {
        "name": "XSHEILD.Test.SyntheticPayload",
        "category": "TEST_DETECTION",
        "severity": "HIGH",
        "confidence": 1.0,
        "description": "Safe test pattern for real-time interception validation."
    },
    # Standard EICAR 68-byte
    EICAR_SHA256: {
        "name": "EICAR.Standard.Antivirus.TestFile",
        "category": "TEST_DETECTION",
        "severity": "HIGH",
        "confidence": 1.0,
        "description": "Standard EICAR benign antivirus verification pattern."
    },
    # Common EICAR with trailing newline or CRLF
    "131f95c51cc819465fa1797f6ccacf9d494aaaff46fa3eac73ae63ffbdfd8267": {
        "name": "EICAR.Standard.Antivirus.TestFile.CRLF",
        "category": "TEST_DETECTION",
        "severity": "HIGH",
        "confidence": 1.0,
        "description": "Standard EICAR test pattern with trailing newline."
    },
    # Synthetic Ransomware Simulator Test File
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855": {
        "name": "Harmless.EmptyFile.Indicator",
        "category": "BENIGN",
        "severity": "CLEAN",
        "confidence": 1.0,
        "description": "0-byte empty file."
    },
    # Known WannaCry sample SHA-256 for reference lookup test (XOR masked)
    _decode_str(bytes([105, 111, 63, 107, 107, 111, 58, 106, 107, 111, 63, 111, 63, 110, 111, 107, 104, 111, 63, 57, 56, 61, 61, 56, 105, 58, 111, 57, 106, 98, 58, 106, 106, 61, 104, 98, 107, 107, 99, 58, 110, 108, 110, 58, 58, 109, 106, 111, 62, 58, 107, 111, 108, 107, 104, 111, 99, 107, 57, 106, 107, 105, 105, 56])): {
        "name": "Ransom.WannaCry.Payload.A",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Known WannaCry ransomware loader artifact."
    },
    # Known Locky test hash (XOR masked)
    _decode_str(bytes([99, 57, 98, 108, 110, 107, 107, 104, 109, 109, 109, 57, 104, 109, 107, 105, 106, 61, 106, 62, 108, 105, 106, 110, 56, 57, 57, 99, 106, 98, 56, 98, 62, 99, 104, 62, 56, 99, 98, 62, 98, 61, 98, 107, 105, 58, 56, 108, 98, 58, 104, 105, 107, 104, 98, 105, 98, 111, 98, 108, 62, 107, 98, 62])): {
        "name": "Ransom.Locky.Variant",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Known Locky ransomware encryption payload."
    },
    # Known Emotet test hash (XOR masked)
    _decode_str(bytes([111, 63, 99, 56, 109, 57, 98, 107, 108, 111, 107, 98, 111, 62, 98, 61, 108, 99, 105, 104, 110, 105, 99, 57, 111, 99, 99, 108, 104, 61, 111, 62, 105, 111, 62, 57, 56, 58, 108, 109, 107, 107, 99, 57, 99, 57, 99, 107, 57, 57, 61, 99, 105, 62, 105, 56, 111, 110, 106, 110, 106, 110, 105, 105])): {
        "name": "Trojan.Emotet.Dropper",
        "category": "TROJAN",
        "severity": "CRITICAL",
        "confidence": 1.0,
        "description": "Known Emotet banking trojan dropper."
    }
}

# Suspicious Script Signature Substrings
def _decode_sig(masked: bytes, key: int = 0x5B) -> bytes:
    return bytes([b ^ key for b in masked])

# Suspicious Script Signature Substrings - XOR encoded in binary to prevent AV heuristic false positives
SUSPICIOUS_SCRIPT_PATTERNS: List[Dict[str, Any]] = [
    {
        "pattern": _decode_sig(bytes([43, 52, 44, 62, 41, 40, 51, 62, 55, 55, 117, 62, 35, 62, 123, 118, 62, 53, 56, 123])),
        "name": "Script.PowerShell.EncodedExecution",
        "category": "SUSPICIOUS_SCRIPT",
        "severity": "MEDIUM",
        "confidence": 0.85
    },
    {
        "pattern": _decode_sig(bytes([43, 52, 44, 62, 41, 40, 51, 62, 55, 55, 117, 62, 35, 62, 123, 118, 53, 52, 43, 123, 118, 44, 123, 51, 50, 63, 63, 62, 53, 123, 118, 56, 123])),
        "name": "Script.PowerShell.HiddenExecution",
        "category": "SUSPICIOUS_SCRIPT",
        "severity": "HIGH",
        "confidence": 0.90
    },
    {
        "pattern": _decode_sig(bytes([18, 30, 3, 123, 115, 21, 62, 44, 118, 20, 57, 49, 62, 56, 47, 123, 21, 62, 47, 117, 12, 62, 57, 24, 55, 50, 62, 53, 47, 114, 117, 31, 52, 44, 53, 55, 52, 58, 63, 8, 47, 41, 50, 53, 60])),
        "name": "Script.PowerShell.DownloadCradle",
        "category": "TROJAN",
        "severity": "CRITICAL",
        "confidence": 0.95
    },
    {
        "pattern": _decode_sig(bytes([45, 40, 40, 58, 63, 54, 50, 53, 117, 62, 35, 62, 123, 63, 62, 55, 62, 47, 62, 123, 40, 51, 58, 63, 52, 44, 40, 123, 116, 58, 55, 55, 123, 116, 42, 46, 50, 62, 47])),
        "name": "Behavior.Ransomware.ShadowCopyDeletion",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 0.98
    },
    {
        "pattern": _decode_sig(bytes([57, 56, 63, 62, 63, 50, 47, 123, 116, 40, 62, 47, 123, 32, 63, 62, 61, 58, 46, 55, 47, 38, 123, 57, 52, 52, 47, 40, 47, 58, 47, 46, 40, 43, 52, 55, 50, 56, 34, 123, 50, 60, 53, 52, 41, 62, 58, 55, 55, 61, 58, 50, 55, 46, 41, 62, 40])),
        "name": "Behavior.Ransomware.BcdeditTampering",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 0.95
    },
    {
        "pattern": _decode_sig(bytes([57, 56, 63, 62, 63, 50, 47, 123, 116, 40, 62, 47, 123, 32, 63, 62, 61, 58, 46, 55, 47, 38, 123, 41, 62, 56, 52, 45, 62, 41, 34, 62, 53, 58, 57, 55, 62, 63, 123, 53, 52])),
        "name": "Behavior.Ransomware.RecoveryDisabled",
        "category": "RANSOMWARE",
        "severity": "CRITICAL",
        "confidence": 0.95
    }
]

# Ransomware Known Target Extensions (Mass file renaming indicator)
RANSOMWARE_EXTENSIONS = {
    ".locked", ".crypto", ".crypt", ".enc", ".wncry", ".wnry",
    ".locky", ".cerber", ".zepto", ".thor", ".aesir", ".zzzzz",
    ".djvu", ".stop", ".phobos", ".makop", ".cuba", ".blackmatter"
}

# Suspicious API Import Sets in PE Binaries
SUSPICIOUS_API_SETS = [
    {
        "name": "Heuristic.PE.ProcessInjection",
        "apis": {"VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread"},
        "severity": "HIGH",
        "category": "TROJAN",
        "confidence": 0.85,
        "description": "Contains direct remote process memory allocation, writing, and thread execution."
    },
    {
        "name": "Heuristic.PE.KeyloggerHooks",
        "apis": {"SetWindowsHookExA", "SetWindowsHookExW", "GetAsyncKeyState", "GetKeyboardState"},
        "severity": "MEDIUM",
        "category": "SPYWARE",
        "confidence": 0.75,
        "description": "Monitors global keyboard hooks and raw keystroke polling."
    },
    {
        "name": "Heuristic.PE.RansomwareEncryptionAPIs",
        "apis": {"CryptEncrypt", "CryptAcquireContextW", "FindFirstFileW", "FindNextFileW"},
        "severity": "MEDIUM",
        "category": "RANSOMWARE",
        "confidence": 0.70,
        "description": "Combines recursive filesystem traversal with low-level cryptographic encryption primitives."
    }
]
