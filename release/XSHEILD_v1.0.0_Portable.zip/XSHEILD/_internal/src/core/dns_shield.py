"""
XSHEILD Encrypted DNS Shield & Zero-Trust Web Protection
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, India
Official Destination: futurefingerindia@gmail.com

Provides encrypted DNS-over-HTTPS (DoH, RFC 8484) resolution and real-time blocking
of phishing, malware, C2 beaconing, and cryptomining domains.
"""

import os
import sys
import time
import json
import socket
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [DNS-SHIELD] %(message)s")
logger = logging.getLogger("xsheild.dns_shield")

# Upstream DoH Providers
DOH_PROVIDERS = [
    {"name": "Cloudflare Security", "url": "https://security.cloudflare-dns.com/dns-query"},
    {"name": "Quad9 Threat Blocking", "url": "https://dns.quad9.net/dns-query"},
    {"name": "Google DNS", "url": "https://dns.google/dns-query"}
]

# Blocked domain categories
BLOCKLIST_CATEGORIES = {
    "PHISHING": [
        "login-update-security-portal.xyz",
        "verify-account-wallet.top",
        "secure-bank-login-update.online",
        "paypal-resolution-center.support"
    ],
    "MALWARE_C2": [
        "evil-botnet-c2.cc",
        "lockbit-ransomware-payment.biz",
        "cobaltstrike-beacon-node.club"
    ],
    "CRYPTOMINER": [
        "coinhive-miner-worker.info",
        "xmr-pool-browser-miner.ru"
    ]
}


class EncryptedDnsShield:
    """Manages encrypted DNS resolution and proactive threat domain filtering."""

    def __init__(self, provider_idx: int = 0):
        self.provider = DOH_PROVIDERS[provider_idx % len(DOH_PROVIDERS)]
        self.blocked_domains = set()
        self._init_blocklist()
        self.total_queries = 0
        self.blocked_queries = 0

    def _init_blocklist(self):
        for cat, domains in BLOCKLIST_CATEGORIES.items():
            for d in domains:
                self.blocked_domains.add(d.lower().strip())

    def add_custom_block(self, domain: str):
        """Adds custom domain to real-time shield blocklist."""
        self.blocked_domains.add(domain.lower().strip())

    def is_domain_blocked(self, domain: str) -> bool:
        """Checks if a domain is flagged as phishing, malware, or C2."""
        d = domain.lower().strip().replace("https://", "").replace("http://", "").split("/")[0]
        # Check exact and parent domain
        parts = d.split(".")
        for i in range(len(parts) - 1):
            sub = ".".join(parts[i:])
            if sub in self.blocked_domains:
                return True
        return False

    def resolve_domain_doh(self, domain: str, query_type: str = "A") -> Dict[str, Any]:
        """
        Resolves domain using Encrypted DNS-over-HTTPS (DoH).
        If the domain is on the threat blocklist, it returns an NXDOMAIN / BLOCKED verdict.
        """
        self.total_queries += 1
        clean_domain = domain.lower().strip()

        if self.is_domain_blocked(clean_domain):
            self.blocked_queries += 1
            logger.warning(f"[BLOCKED] Malicious domain resolution intercepted: {clean_domain}")
            return {
                "domain": clean_domain,
                "status": "BLOCKED",
                "reason": "Threat Domain Intercepted by XSHEILD DNS Shield",
                "ip_addresses": ["0.0.0.0"],
                "provider": self.provider["name"],
                "encrypted": True
            }

        # Query upstream DoH provider with JSON wire protocol
        url = f"{self.provider['url']}?name={clean_domain}&type={query_type}"
        try:
            req = urllib.request.Request(
                url,
                headers={"Accept": "application/dns-json", "User-Agent": "XSHEILD-DnsShield/1.0"}
            )
            with urllib.request.urlopen(req, timeout=3) as res:
                if res.status == 200:
                    data = json.loads(res.read().decode("utf-8"))
                    answers = data.get("Answer", [])
                    ips = [a.get("data") for a in answers if "data" in a]
                    return {
                        "domain": clean_domain,
                        "status": "RESOLVED",
                        "ip_addresses": ips or [socket.gethostbyname(clean_domain)],
                        "provider": self.provider["name"],
                        "encrypted": True
                    }
        except Exception:
            pass

        # Fallback to local resolver if DoH is unreachable
        try:
            ip = socket.gethostbyname(clean_domain)
            return {
                "domain": clean_domain,
                "status": "RESOLVED_FALLBACK",
                "ip_addresses": [ip],
                "provider": "Local OS Resolver",
                "encrypted": False
            }
        except Exception as e:
            return {
                "domain": clean_domain,
                "status": "FAILED",
                "error": str(e),
                "ip_addresses": [],
                "provider": self.provider["name"],
                "encrypted": True
            }

    def get_shield_stats(self) -> Dict[str, Any]:
        return {
            "total_dns_queries": self.total_queries,
            "threats_blocked": self.blocked_queries,
            "active_blocklist_rules": len(self.blocked_domains),
            "doh_provider": self.provider["name"],
            "doh_endpoint": self.provider["url"],
            "encryption_protocol": "DNS-over-HTTPS (RFC 8484, TLS 1.3)",
            "publisher": "Future Finger Technologies",
            "jurisdiction": "New Delhi, Delhi, India"
        }
