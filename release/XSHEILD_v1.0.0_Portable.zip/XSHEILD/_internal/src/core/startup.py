"""
XSHEILD Windows Startup & Boot Integration Service
Owner: Future Finger Technologies

Manages automatic startup execution on Windows user login via:
1. Current User Registry Run Key: HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
2. User Startup Folder: %APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup

Enables the animated "YOU ARE SAFE" splash screen and real-time protection on boot.
"""

import os
import sys
import winreg
from typing import Dict, Any, Optional

RUN_KEY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_VALUE_NAME = "XSHEILD"


def get_application_executable() -> str:
    """
    Returns the absolute path to the executable to run on Windows startup.
    If running as a compiled PyInstaller binary, returns sys.executable.
    If running in development mode, checks for installed binary or dist/XSHEILD/XSHEILD.exe.
    """
    if getattr(sys, "frozen", False):
        return sys.executable

    # 1. Check installed program location
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    if local_app_data:
        installed_exe = os.path.join(local_app_data, "Programs", "XSHEILD", "XSHEILD.exe")
        if os.path.isfile(installed_exe):
            return installed_exe

    # 2. Check if compiled binary exists in dist
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    dist_exe = os.path.join(root_dir, "dist", "XSHEILD", "XSHEILD.exe")
    if os.path.isfile(dist_exe):
        return dist_exe

    # Development fallback
    return sys.executable


def get_startup_folder_path(create: bool = False) -> str:
    """Returns the user's Windows Startup folder path."""
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        p = os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup")
        if create and not os.path.exists(p):
            try:
                os.makedirs(p, exist_ok=True)
            except Exception:
                pass
        if os.path.exists(p):
            return p
    return ""


def get_startup_command(with_splash: bool = True) -> str:
    """Constructs the exact Windows command line to execute on startup."""
    target_exe = get_application_executable()
    flag = "--startup" if with_splash else "--minimized"

    if target_exe.lower().endswith("xsheild.exe"):
        return f'"{target_exe}" {flag}'
    else:
        # Development mode invocation via Python
        return f'"{target_exe}" -m src.ui.app {flag}'


def is_windows_startup_enabled() -> bool:
    """Checks whether XSHEILD is currently registered to launch on Windows startup."""
    # 1. Check HKCU Run registry key
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY_PATH, 0, winreg.KEY_READ) as key:
            val, _ = winreg.QueryValueEx(key, RUN_VALUE_NAME)
            if val:
                return True
    except (FileNotFoundError, OSError):
        pass

    # 2. Check Startup folder shortcut or batch file
    startup_dir = get_startup_folder_path(create=False)
    if startup_dir:
        for name in ("XSHEILD_Startup.cmd", "XSHEILD.bat", "XSHEILD.cmd", "XSHEILD.lnk"):
            p = os.path.join(startup_dir, name)
            if os.path.exists(p):
                return True

    return False


def enable_windows_startup(with_splash: bool = True) -> bool:
    """
    Registers XSHEILD to run automatically on Windows user login.
    Configures HKCU Run registry key and creates a backup trigger in Startup folder.
    """
    command = get_startup_command(with_splash=with_splash)

    # 1. Register in HKCU\Software\Microsoft\Windows\CurrentVersion\Run
    reg_success = False
    try:
        # CreateKey opens existing or creates key if absent (preventing WinError 2 on clean VM images)
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY_PATH)
        with key:
            winreg.SetValueEx(key, RUN_VALUE_NAME, 0, winreg.REG_SZ, command)
            reg_success = True
    except Exception as e:
        print(f"[XSHEILD STARTUP] Registry registration warning: {e}")

    # 2. Cleanup Startup folder if registry registration succeeded to prevent double-instance race on boot.
    # Only write a fallback batch file in Startup folder if registry registration failed.
    folder_success = False
    startup_dir = get_startup_folder_path(create=not reg_success)
    if startup_dir and os.path.isdir(startup_dir):
        launcher_bat = os.path.join(startup_dir, "XSHEILD_Startup.cmd")
        if reg_success:
            if os.path.exists(launcher_bat):
                try:
                    os.remove(launcher_bat)
                except Exception:
                    pass
        else:
            try:
                with open(launcher_bat, "w", encoding="utf-8") as f:
                    f.write("@echo off\r\n")
                    f.write(f'start "" {command}\r\n')
                folder_success = True
            except Exception as e:
                print(f"[XSHEILD STARTUP] Startup folder fallback warning: {e}")

    return reg_success or folder_success


def disable_windows_startup() -> bool:
    """Removes XSHEILD from Windows startup registry and Startup folder."""
    # 1. Delete from HKCU Run key
    try:
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY_PATH)
        with key:
            try:
                winreg.DeleteValue(key, RUN_VALUE_NAME)
            except (FileNotFoundError, OSError):
                pass
    except Exception:
        pass

    # 2. Remove files from Startup folder
    startup_dir = get_startup_folder_path(create=False)
    if startup_dir and os.path.isdir(startup_dir):
        for name in ("XSHEILD_Startup.cmd", "XSHEILD.bat", "XSHEILD.cmd", "XSHEILD.lnk"):
            p = os.path.join(startup_dir, name)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

    return True


def get_startup_configuration() -> Dict[str, Any]:
    """Returns detailed startup registration status and configured execution command."""
    enabled = is_windows_startup_enabled()
    cmd = ""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY_PATH, 0, winreg.KEY_READ) as key:
            cmd, _ = winreg.QueryValueEx(key, RUN_VALUE_NAME)
    except Exception:
        pass

    if not cmd and enabled:
        cmd = get_startup_command()

    return {
        "enabled": enabled,
        "command": cmd,
        "executable": get_application_executable(),
        "startup_folder": get_startup_folder_path(),
        "splash_enabled": "--startup" in cmd or "--splash" in cmd
    }
