"""
XSHEILD Installation & Lifecycle Tracker
Owner: Future Finger Technologies (futurefingerindia@gmail.com)

Tracks:
1. First-time machine installation timestamp & persistent date.
2. Upgrade / Re-installation history and version tracking.
3. Accurate evaluation trial countdown based on genuine installation timestamp.
4. Windows Registry persistence in HKCU\\Software\\XSHEILD.
"""

import os
import sys
import json
import time
import math
from datetime import datetime, timezone
from typing import Dict, Any, Optional

try:
    import winreg
    WINREG_AVAILABLE = True
except ImportError:
    WINREG_AVAILABLE = False

try:
    from src.core.version import __version__ as APP_VERSION
except ImportError:
    APP_VERSION = "2.6.26"
CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
INSTALLATION_INFO_FILE = os.path.join(CONFIG_DIR, "installation_info.json")
REGISTRY_KEY = r"Software\XSHEILD"


def _read_registry_install_info() -> Dict[str, Any]:
    """Reads installation date from Windows Registry if available."""
    if not WINREG_AVAILABLE:
        return {}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REGISTRY_KEY, 0, winreg.KEY_READ) as key:
            install_ts = winreg.QueryValueEx(key, "InstallTimestamp")[0]
            install_date = winreg.QueryValueEx(key, "InstallDate")[0]
            version = winreg.QueryValueEx(key, "InstalledVersion")[0]
            return {
                "install_timestamp": int(install_ts),
                "install_date": str(install_date),
                "version": str(version)
            }
    except Exception:
        return {}


def _write_registry_install_info(info: Dict[str, Any]) -> None:
    """Persists installation date to Windows Registry."""
    if not WINREG_AVAILABLE:
        return
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REGISTRY_KEY) as key:
            winreg.SetValueEx(key, "InstallTimestamp", 0, winreg.REG_SZ, str(info.get("install_timestamp", int(time.time()))))
            winreg.SetValueEx(key, "InstallDate", 0, winreg.REG_SZ, str(info.get("install_date", "")))
            winreg.SetValueEx(key, "InstalledVersion", 0, winreg.REG_SZ, str(info.get("version", APP_VERSION)))
            winreg.SetValueEx(key, "LastUpdatedTimestamp", 0, winreg.REG_SZ, str(info.get("last_updated_timestamp", int(time.time()))))
            winreg.SetValueEx(key, "Publisher", 0, winreg.REG_SZ, "Future Finger Technologies")
    except Exception:
        pass


def get_installation_info() -> Dict[str, Any]:
    """
    Returns the authoritative machine installation record.
    Preserves initial install date across software updates and re-installs.
    """
    os.makedirs(CONFIG_DIR, exist_ok=True)

    # 1. Try reading persistent JSON file
    if os.path.isfile(INSTALLATION_INFO_FILE):
        try:
            with open(INSTALLATION_INFO_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("install_timestamp"):
                    return data
        except Exception:
            pass

    # 2. Try reading Windows Registry
    reg_data = _read_registry_install_info()
    if reg_data.get("install_timestamp"):
        info = {
            "install_timestamp": reg_data["install_timestamp"],
            "install_date": reg_data.get("install_date", datetime.fromtimestamp(reg_data["install_timestamp"]).strftime("%d %b %Y")),
            "last_updated_timestamp": int(time.time()),
            "last_updated_date": datetime.now(timezone.utc).strftime("%d %b %Y"),
            "version": APP_VERSION,
            "machine_name": os.environ.get("COMPUTERNAME", "PC"),
            "install_path": os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "XSHEILD")
        }
        try:
            with open(INSTALLATION_INFO_FILE, "w", encoding="utf-8") as f:
                json.dump(info, f, indent=2)
        except Exception:
            pass
        return info

    # 3. Check if existing legal_consent.json exists to deduce historical install date
    consent_file = os.path.join(CONFIG_DIR, "legal_consent.json")
    if os.path.isfile(consent_file):
        try:
            mtime = int(os.path.getmtime(consent_file))
            info = {
                "install_timestamp": mtime,
                "install_date": datetime.fromtimestamp(mtime).strftime("%d %b %Y"),
                "last_updated_timestamp": int(time.time()),
                "last_updated_date": datetime.now(timezone.utc).strftime("%d %b %Y"),
                "version": APP_VERSION,
                "machine_name": os.environ.get("COMPUTERNAME", "PC"),
                "install_path": os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "XSHEILD")
            }
            with open(INSTALLATION_INFO_FILE, "w", encoding="utf-8") as f:
                json.dump(info, f, indent=2)
            _write_registry_install_info(info)
            return info
        except Exception:
            pass

    # 4. First run on a pristine machine
    now_ts = int(time.time())
    now_date = datetime.now().strftime("%d %b %Y")
    info = {
        "install_timestamp": now_ts,
        "install_date": now_date,
        "last_updated_timestamp": now_ts,
        "last_updated_date": now_date,
        "version": APP_VERSION,
        "machine_name": os.environ.get("COMPUTERNAME", "PC"),
        "install_path": os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "XSHEILD")
    }
    try:
        with open(INSTALLATION_INFO_FILE, "w", encoding="utf-8") as f:
            json.dump(info, f, indent=2)
        _write_registry_install_info(info)
    except Exception:
        pass
    return info


def record_software_upgrade(new_version: str = APP_VERSION) -> Dict[str, Any]:
    """Records an in-place software update while strictly preserving initial installation date."""
    info = get_installation_info()
    now_ts = int(time.time())
    info["last_updated_timestamp"] = now_ts
    info["last_updated_date"] = datetime.now().strftime("%d %b %Y")
    info["version"] = new_version

    try:
        with open(INSTALLATION_INFO_FILE, "w", encoding="utf-8") as f:
            json.dump(info, f, indent=2)
        _write_registry_install_info(info)
    except Exception:
        pass
    return info


def calculate_trial_days(trial_duration_days: int = 14) -> Dict[str, Any]:
    """
    Computes exact days remaining in evaluation based on genuine installation timestamp.
    """
    if not isinstance(trial_duration_days, (int, float)) or trial_duration_days is None:
        trial_duration_days = 14
    info = get_installation_info()
    install_ts = info.get("install_timestamp", int(time.time()))
    now = time.time()
    total_trial_sec = trial_duration_days * 86400
    expires_at = install_ts + total_trial_sec

    remaining_sec = expires_at - now
    if remaining_sec <= 0:
        days_remaining = 0
        is_expired = True
    else:
        # Exactly decrements by 1 day per 24 hours (86,400s) elapsed since install
        days_remaining = min(int(trial_duration_days), max(1, int(math.ceil(remaining_sec / 86400.0))))
        is_expired = False

    days_passed = max(0, int((now - install_ts) / 86400.0))

    return {
        "days_remaining": days_remaining,
        "days_passed": days_passed,
        "is_expired": is_expired,
        "expires_at": int(expires_at),
        "install_date": info.get("install_date", datetime.fromtimestamp(install_ts).strftime("%d %b %Y")),
        "install_timestamp": install_ts,
        "trial_duration_days": trial_duration_days
    }
