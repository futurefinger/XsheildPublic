"""
XSHEILD Command Line Interface (CLI)
Owner: Future Finger Technologies
Allows security operators and automated pipelines to perform scans, audit persistence, manage quarantine,
and verify anti-tamper and asymmetric licensing integrity.
"""

import sys
import argparse
import os
import json

from src.core.scanner import AntivirusScanner
from src.core.quarantine import QuarantineManager
from src.core.models import ScanMode
from src.realtime.persistence import PersistenceAuditor
from src.licensing.client import LicensingClient, PLAN_FEATURES
from src.licensing.token_verifier import create_signed_token, create_asymmetric_token, DEFAULT_HMAC_SECRET
from src.core.anti_tamper import AntiTamperGuard
from src.core.signatures import DATABASE_VERSION


def main():
    parser = argparse.ArgumentParser(
        description="XSHEILD Endpoint Security CLI — Future Finger Technologies"
    )
    parser.add_argument("--version", action="version", version=f"XSHEILD v1.0.0 (Database {DATABASE_VERSION})")

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # 1. Scan command
    scan_p = subparsers.add_parser("scan", help="Scan files or directories for threats")
    scan_p.add_argument("--path", required=True, help="Target file or directory path")
    scan_p.add_argument("--mode", choices=["quick", "full", "custom"], default="custom", help="Scan mode")

    # 2. Quarantine command
    quar_p = subparsers.add_parser("quarantine", help="Manage the encrypted quarantine vault")
    quar_p.add_argument("--list", action="store_true", help="List quarantined items")
    quar_p.add_argument("--restore", help="Restore quarantined item by ID")
    quar_p.add_argument("--delete", help="Permanently delete quarantined item by ID")

    # 3. Persistence command
    subparsers.add_parser("persistence", help="Audit Windows autorun and Run registry keys")

    # 4. Licensing command
    lic_p = subparsers.add_parser("license", help="Display local entitlement or generate free activation tokens")
    lic_p.add_argument("--generate-free", action="store_true", help="Generate a cryptographic offline license token")
    lic_p.add_argument("--asymmetric", action="store_true", help="Sign using uncrackable Ed25519 asymmetric cryptography")
    lic_p.add_argument("--plan", choices=["PRO", "BUSINESS", "FAMILY"], default="PRO", help="Target plan tier")
    lic_p.add_argument("--days", type=int, default=365, help="Validity period in days (e.g. 365 or 3650 for lifetime)")
    lic_p.add_argument("--device-id", help="Bind token to specific hardware device ID (optional)")

    # 5. Startup command
    startup_p = subparsers.add_parser("startup", help="Manage Windows boot startup registration and animated safety splash")
    startup_p.add_argument("--status", action="store_true", help="Display current startup configuration")
    startup_p.add_argument("--enable", action="store_true", help="Enable launch on Windows boot with animated splash")
    startup_p.add_argument("--disable", action="store_true", help="Disable launch on Windows boot")

    # 6. Anti-Tamper command
    anti_p = subparsers.add_parser("anti-tamper", help="Run anti-debugging, memory hook, and binary integrity audit")
    anti_p.add_argument("--strict", action="store_true", help="Run in strict enforcement mode")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "scan":
        scanner = AntivirusScanner()
        target = os.path.abspath(args.path)
        print(f"[XSHEILD] Scanning target: {target} (Mode: {args.mode.upper()})...")

        if os.path.isfile(target):
            res = scanner.scan_file(target)
            print(f"File: {res.file_path}")
            print(f"Verdict: {res.detection_name} ({res.severity.value})")
            print(f"SHA-256: {res.sha256}")
            print(f"Is Threat: {res.is_threat}")
        else:
            mode_enum = ScanMode.CUSTOM if args.mode == "custom" else (ScanMode.QUICK if args.mode == "quick" else ScanMode.FULL)
            report = scanner.scan_directory(target, mode=mode_enum)
            print(f"\n--- Scan Report ---")
            print(f"Files Scanned: {report.scanned_files}")
            print(f"Threats Detected: {report.infected_files}")
            print(f"Duration: {report.duration_seconds:.2f}s")

    elif args.command == "quarantine":
        mgr = QuarantineManager()
        if args.list:
            items = mgr.list_quarantine()
            print(f"[XSHEILD] Quarantined Items ({len(items)}):")
            for it in items:
                print(f"  [{it.item_id}] {it.original_filename} - {it.detection_name} ({it.quarantined_at})")
        elif args.restore:
            try:
                dest = mgr.restore_file(args.restore)
                print(f"[XSHEILD] Restored item {args.restore} to: {dest}")
            except Exception as e:
                print(f"[ERROR] Restoration failed: {e}")
        elif args.delete:
            try:
                mgr.delete_item(args.delete)
                print(f"[XSHEILD] Permanently deleted item: {args.delete}")
            except Exception as e:
                print(f"[ERROR] Deletion failed: {e}")

    elif args.command == "persistence":
        auditor = PersistenceAuditor()
        print("[XSHEILD] Auditing Windows Persistence Keys...")
        entries = auditor.audit_all()
        for e in entries:
            flag = "[SUSPICIOUS]" if e.is_suspicious else "[BENIGN]"
            print(f"{flag} {e.location} | {e.entry_name} -> {e.target_executable or e.raw_command}")
            if e.reasons:
                print(f"    Reasons: {', '.join(e.reasons)}")

    elif args.command == "license":
        client = LicensingClient()
        if getattr(args, "generate_free", False):
            import uuid
            import time
            days = args.days or 365
            plan = args.plan or "PRO"
            dev_id = args.device_id or client.device_id
            now = time.time()
            payload = {
                "token_id": f"tok_{'asym_' if getattr(args, 'asymmetric', False) else 'free_'}{uuid.uuid4().hex[:12]}",
                "user_id": f"usr_fft_{dev_id[:8]}",
                "plan": plan,
                "device_id": dev_id,
                "issued_at": int(now),
                "expires_at": int(now + (days * 86400)),
                "features": PLAN_FEATURES.get(plan, PLAN_FEATURES["PRO"])
            }

            if getattr(args, "asymmetric", False):
                token = create_asymmetric_token(payload)
                sig_type = "Ed25519 Asymmetric (Uncrackable / Mathematically Unforgeable)"
            else:
                token = create_signed_token(payload, DEFAULT_HMAC_SECRET)
                sig_type = "HMAC-SHA256 Symmetric"

            print(f"[XSHEILD] Generated Free {plan} License Token ({days} Days):")
            print(f"Algorithm: {sig_type}")
            print(f"Device Bound: {dev_id}")
            print(f"Token:\n{token}")
        else:
            status = client.get_entitlement_status()
            print(json.dumps(status, indent=2))

    elif args.command == "startup":
        from src.core.startup import (
            enable_windows_startup,
            disable_windows_startup,
            get_startup_configuration
        )
        if args.enable:
            enable_windows_startup(with_splash=True)
            print("[XSHEILD] Successfully registered XSHEILD to run on Windows startup with animated safety verification splash.")
        elif args.disable:
            disable_windows_startup()
            print("[XSHEILD] Disabled XSHEILD from running on Windows startup.")
        else:
            cfg = get_startup_configuration()
            print(json.dumps(cfg, indent=2))

    elif args.command == "anti-tamper":
        guard = AntiTamperGuard(enable_strict_mode=getattr(args, "strict", False))
        print("[XSHEILD] Initiating Anti-Tamper & Security Integrity Audit...")
        report = guard.perform_full_tamper_audit()
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
