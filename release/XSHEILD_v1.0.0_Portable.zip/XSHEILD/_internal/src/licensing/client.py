"""
XSHEILD Licensing Client & Entitlement Manager
Owner: Future Finger Technologies
Enforces local entitlement state, device fingerprinting, and integration with the anti-clock-tamper tracker.
"""

import os
import sys
import json
import uuid
import hashlib
import time
from typing import Dict, Any, Optional, Tuple
from datetime import datetime, timezone, timedelta

from src.licensing.clock import ClockIntegrityTracker
from src.licensing.token_verifier import verify_signed_token, create_signed_token, DEFAULT_HMAC_SECRET
from src.core.installation import get_installation_info, calculate_trial_days

try:
    import winreg
    WINREG_AVAILABLE = True
except ImportError:
    WINREG_AVAILABLE = False

DEFAULT_LICENSE_STORE = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "license_state.json"
)

# Standard Feature Bundles
PLAN_FEATURES = {
    "FREE_EVALUATION": [
        "quick_scan", "custom_scan", "basic_heuristics", "quarantine"
    ],
    "PRO": [
        "quick_scan", "full_scan", "custom_scan", "basic_heuristics", "quarantine",
        "realtime_protection", "persistence_audit", "cloud_reputation", "ransomware_defense",
        "firewall_defense", "vulnerability_audit", "system_cleaner", "ai_copilot", "scheduled_scans",
        "auto_shield", "wifi_sentry", "clipboard_shield", "usb_shield"
    ],
    "FAMILY": [
        "quick_scan", "full_scan", "custom_scan", "basic_heuristics", "quarantine",
        "realtime_protection", "persistence_audit", "cloud_reputation", "ransomware_defense",
        "firewall_defense", "vulnerability_audit", "system_cleaner", "ai_copilot", "scheduled_scans",
        "auto_shield", "wifi_sentry", "clipboard_shield", "usb_shield",
        "multi_device_management"
    ],
    "BUSINESS": [
        "quick_scan", "full_scan", "custom_scan", "basic_heuristics", "quarantine",
        "realtime_protection", "persistence_audit", "cloud_reputation", "ransomware_defense",
        "firewall_defense", "vulnerability_audit", "system_cleaner", "ai_copilot", "scheduled_scans",
        "auto_shield", "wifi_sentry", "clipboard_shield", "usb_shield",
        "multi_device_management", "policy_enforcement", "central_telemetry"
    ]
}

# Strong / Advanced Features gated in unpaid mode
PRO_GATED_FEATURES = {
    "realtime_protection": {
        "title": "Real-Time Kernel Minifilter Guard",
        "description": "Continuous zero-day file interception and live kernel notification surveillance before disk execution.",
        "view": "realtime",
        "icon": "👁️"
    },
    "ransomware_defense": {
        "title": "Ransomware Canary Traps & Anti-Cryptolocker",
        "description": "Canary decoy tripwires and automatic mass-encryption anomaly detection with instant process kill.",
        "view": "ransomware",
        "icon": "🛑"
    },
    "firewall_defense": {
        "title": "Active Network & Firewall Sentry",
        "description": "Real-time port monitoring, automated IP blocking, and outbound command-and-control beacon containment.",
        "view": "network",
        "icon": "🌐"
    },
    "cloud_reputation": {
        "title": "Web & Cloud Phishing Guardian",
        "description": "Live cloud threat intelligence, domain safety verification, and zero-day malicious URL shielding.",
        "view": "web-protection",
        "icon": "🔗"
    },
    "persistence_audit": {
        "title": "Deep Startup & Persistence Auditor",
        "description": "Deep inspection of Windows autoruns, Registry RUN keys, scheduled tasks, and hidden WMI persistence traps.",
        "view": "persistence",
        "icon": "🚀"
    },
    "vulnerability_audit": {
        "title": "Vulnerability & CVE Exploit Scanner",
        "description": "Exhaustive audit of unpatched CVEs, UAC configuration flaws, and operating system misconfigurations.",
        "view": "vulnerability",
        "icon": "⚙️"
    },
    "system_cleaner": {
        "title": "Deep System Optimizer & Cleaner",
        "description": "Safe Win32 filesystem optimization across crash dumps, caches, temporary artifacts, and RAM.",
        "view": "cleaner",
        "icon": "🧹"
    },
    "ai_copilot": {
        "title": "Neural AI Security Copilot",
        "description": "Interactive AI cybersecurity advisor for custom endpoint hardening, threat diagnosis, and security guidance.",
        "view": "copilot",
        "icon": "🤖"
    },
    "multi_device_management": {
        "title": "Multi-Device Fleet Manager",
        "description": "Centralized hardware authorization, multi-endpoint fleet visibility, and remote security coordination.",
        "view": "devices",
        "icon": "💻"
    },
    "scheduled_scans": {
        "title": "Automated Scheduled Background Scans",
        "description": "Autonomous background maintenance schedules that run non-disruptively without user intervention.",
        "view": "scheduled",
        "icon": "⏰"
    },
    "full_scan": {
        "title": "Deep Exhaustive Drive Scanner",
        "description": "Exhaustive sector-by-sector scan across all connected drives, partitions, and system binaries.",
        "view": "scan-full",
        "icon": "🔍"
    },
    "auto_shield": {
        "title": "1-Click Autonomous PC Hardening & Auto-Shield",
        "description": "Instantly hardens Windows security posture, eliminates attack surfaces, and immunizes all endpoints.",
        "view": "dashboard",
        "icon": "⚡"
    },
    "wifi_sentry": {
        "title": "Wi-Fi Network Sentry & Anti-ARP Spoofing",
        "description": "Real-time gateway MAC surveillance, ARP poisoning deterrence, and unauthorized device detection.",
        "view": "network",
        "icon": "🌐"
    },
    "clipboard_shield": {
        "title": "Crypto-Clipper & Financial Clipboard Guard",
        "description": "Protects Bitcoin, Ethereum, USDT, Solana addresses and card numbers from background Trojan hijacking.",
        "view": "dashboard",
        "icon": "📋"
    },
    "usb_shield": {
        "title": "Removable Media & USB Autorun Vaccine Guard",
        "description": "Continuous removable media detection, USB shortcut virus neutralization, and autorun vaccination.",
        "view": "scan-custom",
        "icon": "💾"
    }
}


def get_hardware_device_id() -> str:
    """
    Computes a privacy-preserving SHA-256 fingerprint for the current device.
    Uses Windows MachineGuid if accessible, plus ComputerName and User.
    """
    machine_guid = ""
    if WINREG_AVAILABLE:
        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
                0,
                winreg.KEY_READ | winreg.KEY_WOW64_64KEY
            ) as k:
                machine_guid = str(winreg.QueryValueEx(k, "MachineGuid")[0])
        except Exception:
            pass

    raw_id = f"{machine_guid}:{os.environ.get('COMPUTERNAME', '')}:{os.environ.get('USERNAME', '')}"
    return hashlib.sha256(raw_id.encode("utf-8")).hexdigest()[:24]


class LicensingClient:
    """Manages active product license, trial periods, and feature gates."""

    def __init__(self, store_path: Optional[str] = None, clock_tracker: Optional[ClockIntegrityTracker] = None):
        self.store_path = os.path.abspath(store_path or DEFAULT_LICENSE_STORE)
        self.clock_tracker = clock_tracker or ClockIntegrityTracker(
            journal_path=os.path.join(os.path.dirname(self.store_path), "clock_journal.json")
        )
        self.device_id = get_hardware_device_id()
        self._cached_state = None
        self._cached_mtime = 0.0
        os.makedirs(os.path.dirname(self.store_path), exist_ok=True)

    def _load_state(self) -> Dict[str, Any]:
        try:
            if os.path.exists(self.store_path):
                mtime = os.path.getmtime(self.store_path)
                if self._cached_state is not None and mtime == self._cached_mtime:
                    return self._cached_state
                with open(self.store_path, "r", encoding="utf-8") as f:
                    self._cached_state = json.load(f)
                    self._cached_mtime = mtime
                    return self._cached_state
            return self._cached_state or {}
        except Exception:
            return self._cached_state or {}

    def _save_state(self, state: Dict[str, Any]) -> None:
        self._cached_state = state
        temp_p = self.store_path + ".tmp"
        with open(temp_p, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        os.replace(temp_p, self.store_path)
        try:
            self._cached_mtime = os.path.getmtime(self.store_path)
        except Exception:
            pass

    def activate_trial(self, trial_days: int = 14) -> Dict[str, Any]:
        """Activates a 14-day evaluation license bound to this device."""
        now = time.time()
        expires_at = now + (trial_days * 86400)

        trial_payload = {
            "token_id": str(uuid.uuid4()),
            "user_id": f"eval_{self.device_id[:8]}",
            "plan": "FREE_EVALUATION",
            "device_id": self.device_id,
            "issued_at": int(now),
            "expires_at": int(expires_at),
            "features": PLAN_FEATURES["FREE_EVALUATION"]
        }

        token = create_signed_token(trial_payload, DEFAULT_HMAC_SECRET)

        state = {
            "active_token": token,
            "activated_at": datetime.now(timezone.utc).isoformat(),
            "plan": "FREE_EVALUATION",
            "is_trial": True
        }
        self._save_state(state)
        return trial_payload

    def install_license_token(self, token_str: str) -> Tuple[bool, str]:
        """Validates and installs a newly issued commercial entitlement token."""
        valid, payload, reason = verify_signed_token(
            token_str,
            secret=DEFAULT_HMAC_SECRET,
            expected_device_id=self.device_id
        )

        if not valid or not payload:
            return False, f"Failed to activate license: {reason}"

        state = {
            "active_token": token_str,
            "activated_at": datetime.now(timezone.utc).isoformat(),
            "plan": payload.get("plan", "PRO"),
            "is_trial": False,
            "expires_at": payload.get("expires_at")
        }
        self._save_state(state)
        return True, "License activated successfully"

    def activate_promo_or_key(self, code_or_token: str) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Activates a license using either:
        1. A signed offline cryptographic token string (format: <b64>.<b64>).
        2. A promotional voucher / free tier code (e.g. FFT-FREE-PRO, XSHEILD-FREE-2026, FFT-LIFETIME-VIP, COMMUNITY-FREE).
        """
        clean = code_or_token.strip()
        if not clean:
            return False, "Please enter a valid license key or promo code.", {}

        # 1. Cryptographic Signed Token Format (HMAC 2-part or Ed25519 3-part)
        if "." in clean and len(clean.split(".")) in (2, 3):
            ok, msg = self.install_license_token(clean)
            return ok, msg, self.get_entitlement_status()

        # 2. Promotional & Developer / Owner Free Codes
        upper_code = clean.upper()
        now = time.time()

        PROMO_DEFINITIONS = {
            "FFT-FREE-PRO": {"plan": "PRO", "days": 365, "name": "Future Finger Technologies 1-Year Free Pro"},
            "XSHEILD-FREE-2026": {"plan": "PRO", "days": 365, "name": "XSHEILD 2026 Community Promotion"},
            "FFT-LIFETIME-VIP": {"plan": "BUSINESS", "days": 3650, "name": "Future Finger VIP Lifetime Full Entitlement"},
            "COMMUNITY-FREE": {"plan": "FREE_EVALUATION", "days": 3650, "name": "XSHEILD Community Edition (Permanent Free)"},
        }

        promo = PROMO_DEFINITIONS.get(upper_code)
        if not promo:
            return False, "Invalid license key or unrecognized promo code. Check formatting.", {}

        duration_days = promo["days"]
        expires_at = now + (duration_days * 86400)
        plan_name = promo["plan"]

        payload = {
            "token_id": f"promo_{uuid.uuid4().hex[:12]}",
            "user_id": f"usr_promo_{self.device_id[:8]}",
            "plan": plan_name,
            "device_id": self.device_id,
            "issued_at": int(now),
            "expires_at": int(expires_at),
            "features": PLAN_FEATURES.get(plan_name, PLAN_FEATURES["PRO"]),
            "promo_code": upper_code,
            "promo_name": promo["name"]
        }

        token = create_signed_token(payload, DEFAULT_HMAC_SECRET)
        state = {
            "active_token": token,
            "activated_at": datetime.now(timezone.utc).isoformat(),
            "plan": plan_name,
            "is_trial": (plan_name == "FREE_EVALUATION"),
            "expires_at": int(expires_at)
        }
        self._save_state(state)
        return True, f"Successfully activated {promo['name']}! Valid for {duration_days} days.", self.get_entitlement_status()

    def get_entitlement_status(self) -> Dict[str, Any]:
        """Returns current entitlement status with anti-clock-tamper verification."""
        clock_valid, clock_reason = self.clock_tracker.check_and_update()
        if not clock_valid:
            return {
                "is_active": False,
                "plan": "LOCKED",
                "reason": f"Clock Tampering Detected: {clock_reason}",
                "features": ["quick_scan"],  # Fallback minimum protection
                "device_id": self.device_id
            }

        state = self._load_state()
        token = state.get("active_token")

        if not token:
            # Auto-activate trial if first run
            self.activate_trial(trial_days=14)
            state = self._load_state()
            token = state.get("active_token")

        valid, payload, reason = verify_signed_token(
            token,
            secret=DEFAULT_HMAC_SECRET,
            expected_device_id=self.device_id
        )

        is_trial = state.get("is_trial", False) or (payload and payload.get("plan") == "FREE_EVALUATION")
        install_info = get_installation_info()

        if is_trial:
            trial_calc = calculate_trial_days(14)
            days_remaining = trial_calc["days_remaining"]
            is_active = not trial_calc["is_expired"]
            expires_at = trial_calc["expires_at"]
            plan_name = "FREE_EVALUATION" if is_active else "EXPIRED"

            return {
                "is_active": is_active,
                "plan": plan_name,
                "expires_at": expires_at,
                "days_remaining": days_remaining,
                "install_date": trial_calc["install_date"],
                "install_timestamp": trial_calc["install_timestamp"],
                "features": PLAN_FEATURES["FREE_EVALUATION"],
                "device_id": self.device_id,
                "user_id": payload.get("user_id") if payload else f"eval_{self.device_id[:8]}",
                "is_trial": True
            }

        if not valid or not payload:
            return {
                "is_active": False,
                "plan": "EXPIRED",
                "reason": reason,
                "features": ["quick_scan"],
                "device_id": self.device_id,
                "days_remaining": 0,
                "install_date": install_info.get("install_date", "")
            }

        expires_at = payload.get("expires_at", 0)
        days_remaining = max(0, int((expires_at - time.time()) / 86400)) if expires_at else 365

        return {
            "is_active": True,
            "plan": payload.get("plan", "PRO"),
            "expires_at": expires_at,
            "days_remaining": days_remaining,
            "install_date": install_info.get("install_date", ""),
            "install_timestamp": install_info.get("install_timestamp", 0),
            "features": payload.get("features", []),
            "device_id": self.device_id,
            "user_id": payload.get("user_id"),
            "is_trial": False
        }

    def is_feature_allowed(self, feature_key: str) -> bool:
        """
        Determines whether a specific feature key is unlocked under the current license.
        Free evaluation tier only allows basic on-demand scanning and quarantine.
        Strong/advanced capabilities require an active PRO or BUSINESS license.
        """
        status = self.get_entitlement_status()
        if not status.get("is_active"):
            return feature_key in ("quick_scan", "quarantine", "history", "about", "diagnostics", "support", "account", "subscription", "referrals")

        plan = (status.get("plan") or "FREE_EVALUATION").upper()
        if plan in ("PRO", "BUSINESS", "FAMILY", "ENTERPRISE", "ULTIMATE", "LIFETIME") and not status.get("is_trial"):
            return True

        # For FREE_EVALUATION / trial / unpaid, strictly enforce current FREE_EVALUATION bundle
        free_allowed = PLAN_FEATURES.get("FREE_EVALUATION", ["quick_scan", "custom_scan", "basic_heuristics", "quarantine"])
        return feature_key in free_allowed

    def get_feature_gating_status(self) -> Dict[str, Any]:
        """
        Returns full feature unlock matrix for UI presentation and enforcement.
        """
        status = self.get_entitlement_status()
        plan = (status.get("plan") or "FREE_EVALUATION").upper()
        is_paid = bool(status.get("is_active") and not status.get("is_trial") and plan in ("PRO", "BUSINESS", "FAMILY", "ENTERPRISE", "ULTIMATE", "LIFETIME"))

        gating_map = {}
        for key, meta in PRO_GATED_FEATURES.items():
            gating_map[key] = {
                "key": key,
                "title": meta["title"],
                "description": meta["description"],
                "view": meta["view"],
                "icon": meta["icon"],
                "unlocked": is_paid or (key in status.get("features", []) and not status.get("is_trial")),
                "requires_pro": True
            }

        return {
            "is_paid": is_paid,
            "plan": plan,
            "days_remaining": status.get("days_remaining", 0),
            "is_trial": status.get("is_trial", True),
            "features": gating_map
        }
