"""
XSHEILD Monotonic Clock & Anti-Rollback Tracker
Owner: Future Finger Technologies
Defends against system time rollback attacks attempting to artificially extend expired trials or subscriptions.
"""

import os
import json
import time
from typing import Tuple, Optional
from datetime import datetime, timezone

DEFAULT_CLOCK_JOURNAL = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "XSHEILD",
    "clock_journal.json"
)

# Maximum allowable backward drift in seconds before declaring clock tampering (e.g. NTP sync adjustment)
MAX_TOLERABLE_BACKWARD_DRIFT_SEC = 300.0  # 5 minutes


class ClockIntegrityTracker:
    """Maintains a persistent high-water mark of observed timestamps to defeat clock rollback."""

    def __init__(self, journal_path: Optional[str] = None, initial_epoch: Optional[float] = None):
        self.journal_path = os.path.abspath(journal_path or DEFAULT_CLOCK_JOURNAL)
        self._cached_journal = None
        self._last_disk_sync = 0.0
        os.makedirs(os.path.dirname(self.journal_path), exist_ok=True)
        if not os.path.exists(self.journal_path):
            init_time = initial_epoch if initial_epoch is not None else time.time()
            data = {
                "last_observed_epoch": init_time,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "tamper_incidents": 0
            }
            self._save_journal(data)
            self._cached_journal = data
            self._last_disk_sync = time.time()

    def _load_journal(self) -> dict:
        if self._cached_journal is not None:
            return self._cached_journal
        try:
            with open(self.journal_path, "r", encoding="utf-8") as f:
                self._cached_journal = json.load(f)
                return self._cached_journal
        except Exception:
            self._cached_journal = {"last_observed_epoch": time.time(), "tamper_incidents": 0}
            return self._cached_journal

    def _save_journal(self, data: dict) -> None:
        self._cached_journal = data
        try:
            temp_path = self.journal_path + ".tmp"
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(temp_path, self.journal_path)
            self._last_disk_sync = time.time()
        except Exception:
            pass

    def check_and_update(self, current_epoch: Optional[float] = None) -> Tuple[bool, str]:
        """
        Validates current time against high-water mark.
        Returns: (is_valid: bool, reason: str)
        If valid, updates high-water mark.
        """
        now = current_epoch if current_epoch is not None else time.time()
        journal = self._load_journal()
        last_observed = journal.get("last_observed_epoch", 0.0)

        # Check for backward clock shift
        if now < (last_observed - MAX_TOLERABLE_BACKWARD_DRIFT_SEC):
            drift_minutes = round((last_observed - now) / 60.0, 1)
            journal["tamper_incidents"] = journal.get("tamper_incidents", 0) + 1
            journal["last_tamper_detected_at"] = datetime.now(timezone.utc).isoformat()
            self._save_journal(journal)
            return False, f"System clock was rolled backward by ~{drift_minutes} minutes"

        # Update high-water mark if moving forward
        if now > last_observed:
            journal["last_observed_epoch"] = now
            # Only sync to disk once every 60 seconds to prevent constant I/O latency
            if (now - self._last_disk_sync) >= 60.0:
                self._save_journal(journal)

        return True, "Clock verified monotonic"
