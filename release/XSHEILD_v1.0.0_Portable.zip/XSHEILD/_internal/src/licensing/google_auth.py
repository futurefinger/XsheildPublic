"""
XSHEILD Google OAuth 2.0 Authentication Service
Owner: Future Finger Technologies

Implements the official desktop Loopback IP OAuth 2.0 flow (RFC 8252) for Google Sign-In.
1. Spawns an ephemeral local loopback HTTP listener on 127.0.0.1:54123.
2. Directs the user's default system browser to Google's OAuth consent endpoint.
3. Captures the authorization code on loopback redirect.
4. Exchanges code for tokens via https://oauth2.googleapis.com/token.
5. Queries https://www.googleapis.com/oauth2/v3/userinfo for verified identity.
6. Seamlessly authenticates the user into XSHEILD and closes the loopback server.
"""

import os
import sys
import json
import secrets
import logging
import threading
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Any, Optional, Callable

logger = logging.getLogger("xsheild.google_auth")

DEFAULT_CLIENT_ID = "1059506465767-bectm54a81vf8fjv0d5mp4jpfmv81osj.apps.googleusercontent.com"
DEFAULT_CLIENT_SECRET = "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"
DEFAULT_PORT = 54123
DEFAULT_REDIRECT_URI = f"http://127.0.0.1:{DEFAULT_PORT}/oauth/callback"

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"

HTML_SUCCESS_PAGE = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>XSHEILD — Authentication Successful</title>
  <style>
    body {
      background: radial-gradient(circle at 50% 30%, #0c1a30 0%, #060914 70%);
      color: #e2e8f0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }
    .card {
      background: rgba(13, 22, 45, 0.85);
      border: 1px solid rgba(0, 240, 255, 0.4);
      border-radius: 16px;
      padding: 40px;
      text-align: center;
      box-shadow: 0 0 50px rgba(0, 240, 255, 0.2);
      max-width: 440px;
    }
    .shield-icon {
      font-size: 54px;
      margin-bottom: 16px;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%, 100% { transform: scale(1); filter: drop-shadow(0 0 10px #00f0ff); }
      50% { transform: scale(1.08); filter: drop-shadow(0 0 20px #10b981); }
    }
    h1 { color: #00f0ff; margin: 0 0 10px 0; font-size: 24px; letter-spacing: 0.5px; }
    p { color: #94a3b8; font-size: 15px; line-height: 1.5; margin: 0 0 20px 0; }
    .badge {
      display: inline-block;
      padding: 8px 18px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid #10b981;
      border-radius: 20px;
      color: #10b981;
      font-weight: 600;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="shield-icon">🛡️</div>
    <h1>Authentication Verified</h1>
    <p>Your Google account has been successfully authenticated with <strong>XSHEILD</strong>. You may close this tab and return to the application.</p>
    <div class="badge">✓ Return to XSHEILD Desktop</div>
  </div>
  <script>
    setTimeout(function() { window.close(); }, 4000);
  </script>
</body>
</html>
"""


class GoogleOAuthService:
    """Manages Google OAuth 2.0 loopback authentication for desktop endpoint security."""

    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        port: int = DEFAULT_PORT
    ):
        if client_id is not None:
            self.client_id = client_id
        else:
            self.client_id = os.environ.get("GOOGLE_CLIENT_ID", DEFAULT_CLIENT_ID)

        if client_secret is not None:
            self.client_secret = client_secret
        else:
            self.client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", DEFAULT_CLIENT_SECRET)

        self.port = port
        self.redirect_uri = f"http://127.0.0.1:{self.port}/oauth/callback"
        self._current_server: Optional[HTTPServer] = None
        self._expected_state: Optional[str] = None
        self._lock = threading.Lock()

    def initiate_login(
        self,
        on_success: Callable[[Dict[str, Any]], None],
        on_error: Optional[Callable[[str], None]] = None
    ) -> Dict[str, Any]:
        """
        Starts the local loopback server and opens the user's browser to the Google OAuth consent page.
        """
        if not self.client_id or not self.client_secret:
            return {"success": False, "error": "Google OAuth Client credentials are not configured"}

        with self._lock:
            # Stop any existing server instance if still hanging
            self._stop_server()

            self._expected_state = secrets.token_urlsafe(24)

            # Build Google Auth URI
            params = {
                "client_id": self.client_id,
                "redirect_uri": self.redirect_uri,
                "response_type": "code",
                "scope": "openid email profile",
                "state": self._expected_state,
                "access_type": "offline",
                "prompt": "select_account"
            }
            auth_url = f"{GOOGLE_AUTH_URL}?{urllib.parse.urlencode(params)}"

            try:
                # Start loopback server
                server = self._create_server(on_success, on_error)
                self._current_server = server
                server_thread = threading.Thread(
                    target=server.serve_forever,
                    daemon=True,
                    name="XSheildGoogleOAuthServer"
                )
                server_thread.start()
                logger.info(f"Google OAuth loopback server listening on 127.0.0.1:{self.port}")
            except OSError as e:
                logger.error(f"Failed to bind Google OAuth loopback port {self.port}: {e}")
                return {"success": False, "error": f"Failed to start local OAuth receiver: {e}"}

        # Open in default system browser
        try:
            webbrowser.open(auth_url)
        except Exception as e:
            logger.warning(f"Could not automatically open browser: {e}")

        return {
            "success": True,
            "message": "Opening your browser to complete Google Sign-In...",
            "auth_url": auth_url
        }

    def _create_server(
        self,
        on_success: Callable[[Dict[str, Any]], None],
        on_error: Optional[Callable[[str], None]]
    ) -> HTTPServer:
        service = self

        class OAuthCallbackHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # Suppress default console clutter

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != "/oauth/callback":
                    self.send_response(404)
                    self.end_headers()
                    self.wfile.write(b"Not Found")
                    return

                query_params = urllib.parse.parse_qs(parsed.query)
                code = query_params.get("code", [None])[0]
                state = query_params.get("state", [None])[0]
                error = query_params.get("error", [None])[0]

                if error:
                    err_msg = f"Google Sign-In was cancelled or denied: {error}"
                    logger.warning(err_msg)
                    self._send_error_response(err_msg)
                    if on_error:
                        on_error(err_msg)
                    threading.Thread(target=service._stop_server, daemon=True).start()
                    return

                if not state or state != service._expected_state:
                    err_msg = "Security state mismatch. Possible CSRF attempt."
                    logger.error(err_msg)
                    self._send_error_response(err_msg)
                    if on_error:
                        on_error(err_msg)
                    threading.Thread(target=service._stop_server, daemon=True).start()
                    return

                if not code:
                    err_msg = "No authorization code received from Google."
                    logger.error(err_msg)
                    self._send_error_response(err_msg)
                    if on_error:
                        on_error(err_msg)
                    threading.Thread(target=service._stop_server, daemon=True).start()
                    return

                # Exchange code for user details
                try:
                    user_info = service._exchange_code_for_userinfo(code)
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    self.wfile.write(HTML_SUCCESS_PAGE.encode("utf-8"))

                    logger.info(f"Google OAuth verified for: {user_info.get('email')}")
                    if on_success:
                        on_success(user_info)
                except Exception as ex:
                    err_msg = f"Failed to retrieve Google profile: {ex}"
                    logger.error(err_msg)
                    self._send_error_response(err_msg)
                    if on_error:
                        on_error(err_msg)
                finally:
                    threading.Thread(target=service._stop_server, daemon=True).start()

            def _send_error_response(self, message: str):
                self.send_response(400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                html = f"<html><body style='font-family:sans-serif;padding:40px;background:#060914;color:#ef4444;'><h2>Authentication Error</h2><p>{message}</p></body></html>"
                self.wfile.write(html.encode("utf-8"))

        return HTTPServer(("127.0.0.1", self.port), OAuthCallbackHandler)

    def _exchange_code_for_userinfo(self, code: str) -> Dict[str, Any]:
        """Exchanges authorization code for Google access token and retrieves user profile."""
        import httpx

        # 1. Exchange token
        token_payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": self.redirect_uri
        }

        with httpx.Client(timeout=10.0) as client:
            token_resp = client.post(GOOGLE_TOKEN_URL, data=token_payload)
            token_data = token_resp.json()

            if token_resp.status_code != 200:
                raise ValueError(token_data.get("error_description", token_data.get("error", "Token exchange failed")))

            access_token = token_data.get("access_token")
            if not access_token:
                raise ValueError("Access token missing in Google response")

            # 2. Fetch User Profile
            headers = {"Authorization": f"Bearer {access_token}"}
            user_resp = client.get(GOOGLE_USERINFO_URL, headers=headers)
            user_data = user_resp.json()

            if user_resp.status_code != 200:
                raise ValueError("Failed to fetch Google userinfo")

            return {
                "provider": "google",
                "sub": user_data.get("sub"),
                "email": user_data.get("email"),
                "email_verified": user_data.get("email_verified", True),
                "name": user_data.get("name") or user_data.get("email", "").split("@")[0],
                "picture": user_data.get("picture")
            }

    def _stop_server(self):
        """Stops the active HTTP loopback server."""
        if self._current_server:
            try:
                self._current_server.shutdown()
                self._current_server.server_close()
            except Exception:
                pass
            self._current_server = None
            logger.debug("Google OAuth loopback server stopped.")


# Global singleton instance
google_oauth_service = GoogleOAuthService()
