"""
XSHEILD User Account & Authentication Manager
Owner: Future Finger Technologies

Manages user registration (Sign Up), authentication (Sign In), and profile persistence
for XSHEILD desktop clients. Integrates with device hardware licensing and tier entitlements.
"""

import os
import re
import json
import time
import uuid
import hashlib
import logging
from typing import Dict, Any, Optional, Tuple
from datetime import datetime, timezone

from src.licensing.client import LicensingClient, get_hardware_device_id, PLAN_FEATURES

logger = logging.getLogger("xsheild.auth")

CONFIG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
PROFILE_FILE = os.path.join(CONFIG_DIR, "user_profile.json")

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


def _hash_password(password: str, salt: Optional[str] = None) -> Tuple[str, str]:
    """Hashes a password with PBKDF2-HMAC-SHA256 and a 16-byte random salt."""
    if not salt:
        salt = os.urandom(16).hex()
    key = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        iterations=100_000
    ).hex()
    return key, salt


class UserAuthManager:
    """Manages user registration, login, and active profile state."""

    def __init__(self, profile_path: str = PROFILE_FILE, licensing_client: Optional[LicensingClient] = None):
        self.profile_path = profile_path
        self.licensing_client = licensing_client or LicensingClient()
        self.device_id = get_hardware_device_id()
        self._profile_data: Optional[Dict[str, Any]] = None
        self._load_profile()

    def _load_profile(self) -> None:
        if os.path.isfile(self.profile_path):
            try:
                with open(self.profile_path, "r", encoding="utf-8") as f:
                    self._profile_data = json.load(f)
            except Exception as e:
                logger.warning(f"Error loading user profile: {e}")
                self._profile_data = None
        else:
            self._profile_data = None

    def _save_profile(self, data: Dict[str, Any]) -> None:
        try:
            os.makedirs(os.path.dirname(self.profile_path), exist_ok=True)
            temp_p = self.profile_path + ".tmp"
            with open(temp_p, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(temp_p, self.profile_path)
            self._profile_data = data
        except Exception as e:
            logger.error(f"Failed to persist user profile: {e}")

    def is_authenticated(self) -> bool:
        """Checks if a user is currently registered and logged in."""
        return self._profile_data is not None and bool(self._profile_data.get("is_logged_in", False))

    def get_current_user(self) -> Dict[str, Any]:
        """Returns public profile details of current user or guest fallback."""
        lic = self.licensing_client.get_entitlement_status()
        if self._profile_data and self._profile_data.get("is_logged_in"):
            return {
                "authenticated": True,
                "user_id": self._profile_data.get("user_id"),
                "full_name": self._profile_data.get("full_name"),
                "email": self._profile_data.get("email"),
                "provider": self._profile_data.get("provider", "local"),
                "provider_id": self._profile_data.get("provider_id"),
                "picture": self._profile_data.get("picture"),
                "email_verified": self._profile_data.get("email_verified", True),
                "plan_tier": lic.get("plan", self._profile_data.get("plan", "FREE_EVALUATION")),
                "is_trial": lic.get("is_trial", True),
                "device_id": self.device_id,
                "registered_at": self._profile_data.get("created_at"),
                "last_login": self._profile_data.get("last_login")
            }
        return {
            "authenticated": False,
            "user_id": None,
            "full_name": "Guest User",
            "email": None,
            "provider": None,
            "provider_id": None,
            "picture": None,
            "email_verified": False,
            "plan_tier": lic.get("plan", "FREE_EVALUATION"),
            "is_trial": lic.get("is_trial", True),
            "device_id": self.device_id,
            "registered_at": None,
            "last_login": None
        }

    def register_user(
        self,
        full_name: str,
        email: str,
        password: str,
        confirm_password: Optional[str] = None,
        otp_code: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Registers a new user account, validates constraints, checks OTP if provided, and activates evaluation tier.
        """
        # 1. Validation
        name_clean = full_name.strip()
        email_clean = email.strip().lower()

        if len(name_clean) < 2:
            return {"success": False, "error": "Full name must be at least 2 characters"}

        if not EMAIL_REGEX.match(email_clean):
            return {"success": False, "error": "Please provide a valid email address (e.g. user@example.com)"}

        if len(password) < 6:
            return {"success": False, "error": "Password must be at least 6 characters"}

        if confirm_password is not None and password != confirm_password:
            return {"success": False, "error": "Passwords do not match"}

        # 1b. OTP Verification if provided
        email_verified = False
        if otp_code:
            from src.licensing.otp import otp_service
            otp_res = otp_service.verify_otp(email_clean, otp_code)
            if not otp_res.get("success"):
                return {"success": False, "error": otp_res.get("error", "Invalid verification OTP code")}
            email_verified = True

        # 2. Hash password securely
        pwd_hash, salt = _hash_password(password)
        now_iso = datetime.now(timezone.utc).isoformat()
        user_id = f"usr_{uuid.uuid4().hex[:12]}"

        # 3. Create profile record
        profile = {
            "user_id": user_id,
            "full_name": name_clean,
            "email": email_clean,
            "password_hash": pwd_hash,
            "password_salt": salt,
            "provider": "local",
            "provider_id": None,
            "picture": None,
            "email_verified": email_verified,
            "created_at": now_iso,
            "last_login": now_iso,
            "is_logged_in": True,
            "plan": "FREE_EVALUATION",
            "device_id": self.device_id
        }

        # 4. Activate local trial license for new user
        try:
            self.licensing_client.activate_trial(trial_days=14)
        except Exception as e:
            logger.warning(f"Trial activation notice during registration: {e}")

        # 5. Save profile
        self._save_profile(profile)

        return {
            "success": True,
            "message": f"Welcome to XSHEILD, {name_clean}! Your account is active.",
            "user": self.get_current_user()
        }

    def login_or_register_oauth(
        self,
        email: str,
        full_name: str,
        provider: str = "google",
        provider_id: Optional[str] = None,
        picture: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Authenticates or signs up a user via OAuth provider (Google, etc.).
        Activates evaluation license if this is a new registration.
        """
        email_clean = email.strip().lower()
        name_clean = full_name.strip() or email_clean.split("@")[0]

        now_iso = datetime.now(timezone.utc).isoformat()

        # Check if existing profile matches this email or reuse user_id
        existing_uid = None
        created_at = now_iso
        plan = "FREE_EVALUATION"

        if self._profile_data:
            if self._profile_data.get("email", "").lower() == email_clean:
                existing_uid = self._profile_data.get("user_id")
                created_at = self._profile_data.get("created_at", now_iso)
                plan = self._profile_data.get("plan", "FREE_EVALUATION")

        user_id = existing_uid or f"usr_{uuid.uuid4().hex[:12]}"

        profile = {
            "user_id": user_id,
            "full_name": name_clean,
            "email": email_clean,
            "password_hash": None,
            "password_salt": None,
            "provider": provider,
            "provider_id": provider_id,
            "picture": picture,
            "email_verified": True,
            "created_at": created_at,
            "last_login": now_iso,
            "is_logged_in": True,
            "plan": plan,
            "device_id": self.device_id
        }

        # Activate trial license if not yet active
        try:
            ent = self.licensing_client.get_entitlement_status()
            if not ent.get("is_active"):
                self.licensing_client.activate_trial(trial_days=14)
        except Exception as e:
            logger.warning(f"Trial check notice during OAuth login: {e}")

        self._save_profile(profile)

        logger.info(f"User authenticated via {provider}: {email_clean} (ID: {user_id})")
        return {
            "success": True,
            "message": f"Welcome to XSHEILD, {name_clean}!",
            "user": self.get_current_user()
        }

    def login_user(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticates user against stored credentials."""
        email_clean = email.strip().lower()

        if not self._profile_data:
            return {"success": False, "error": "No registered user found on this system. Please sign up first."}

        stored_email = self._profile_data.get("email", "").lower()
        if stored_email != email_clean:
            return {"success": False, "error": "Email does not match the registered user on this device."}

        stored_hash = self._profile_data.get("password_hash", "")
        salt = self._profile_data.get("password_salt", "")

        computed_hash, _ = _hash_password(password, salt)
        if computed_hash != stored_hash:
            return {"success": False, "error": "Incorrect password. Please try again."}

        # Update login timestamp & state
        self._profile_data["last_login"] = datetime.now(timezone.utc).isoformat()
        self._profile_data["is_logged_in"] = True
        self._save_profile(self._profile_data)

        return {
            "success": True,
            "message": f"Welcome back, {self._profile_data.get('full_name')}!",
            "user": self.get_current_user()
        }

    def logout_user(self) -> Dict[str, Any]:
        """Logs out the active user session."""
        if self._profile_data:
            self._profile_data["is_logged_in"] = False
            self._save_profile(self._profile_data)
        return {"success": True, "message": "Logged out successfully"}


# Global singleton authentication instance
auth_manager = UserAuthManager()
