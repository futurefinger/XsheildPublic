"""
XSHEILD JavaScript <-> Python IPC Bridge
Owner: Future Finger Technologies
Provides authenticated, strongly-typed JSON-RPC communication between the WebView2 desktop interface and backend engines.
"""

import os
import sys
import json
import time
import uuid
import hmac
import hashlib
import ctypes
import threading
import webbrowser
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

from src.core.scanner import AntivirusScanner
from src.core.quarantine import QuarantineManager
from src.core.models import ScanMode
from src.realtime.watcher import RealtimeProtectionEngine, ThreatDetectedEvent
from src.realtime.persistence import PersistenceAuditor
from src.licensing.client import LicensingClient, PLAN_FEATURES
from src.backend.razorpay_service import RazorpayService, PLAN_PRICING
from src.core.signatures import DATABASE_VERSION, KNOWN_THREAT_HASHES


# Memory status structure for ctypes
class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def get_windows_system_metrics() -> Dict[str, Any]:
    """Retrieves live memory and system metrics via kernel32 without external packages."""
    mem_load = 45
    total_gb = 16.0
    avail_gb = 8.0

    try:
        kernel32 = ctypes.windll.kernel32
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            mem_load = stat.dwMemoryLoad
            total_gb = round(stat.ullTotalPhys / (1024 ** 3), 1)
            avail_gb = round(stat.ullAvailPhys / (1024 ** 3), 1)
    except Exception:
        pass

    return {
        "memory_load_percent": mem_load,
        "total_ram_gb": total_gb,
        "available_ram_gb": avail_gb,
        "engine_status": "ONLINE",
        "realtime_active": True,
        "database_version": DATABASE_VERSION
    }


class SplashBridge:
    """Dedicated lightweight IPC bridge for the startup safety verification splash screen."""

    def __init__(self, webview_window=None):
        self._window = webview_window

    def set_window(self, win) -> None:
        self._window = win

    def dismiss_splash(self) -> None:
        """Closes or hides the startup splash window and pre-stages the full dashboard."""
        import pathlib
        from src.core.logger import get_logger
        get_logger("ui.bridge").info("Splash screen dismissed: pre-staging dashboard & background protection active in tray.")
        if self._window:
            try:
                hwnd = self._get_window_hwnd() if hasattr(self, "_get_window_hwnd") else 0
                if hwnd:
                    import ctypes
                    ctypes.windll.user32.ShowWindowAsync(hwnd, 0)
                if getattr(self._window, "native", None):
                    native = self._window.native
                    if hasattr(native, "BeginInvoke"):
                        import System
                        native.BeginInvoke(System.Action(native.Hide))
                from src.ui.app import INDEX_HTML, get_centered_window_geometry
                uri = pathlib.Path(INDEX_HTML).as_uri()
                w, h, x, y = get_centered_window_geometry(1220, 695)
                self._window.load_url(uri)
                self._window.resize(w, h)
                self._window.move(x, y)
            except Exception as e:
                get_logger("ui.bridge").debug(f"Splash dismiss pre-stage notice: {e}")

    def open_dashboard_from_splash(self) -> None:
        """Transitions from splash screen to the full XSHEILD dashboard."""
        import pathlib
        from src.core.logger import get_logger
        get_logger("ui.bridge").info("Splash action: launching full dashboard.")
        if self._window:
            try:
                from src.ui.app import INDEX_HTML, get_centered_window_geometry
                w, h, x, y = get_centered_window_geometry(1220, 695)
                uri = pathlib.Path(INDEX_HTML).as_uri()
                self._window.load_url(uri)
                self._window.resize(w, h)
                self._window.move(x, y)
                self._window.show()
                self._window.restore()
                if getattr(self._window, "native", None):
                    try:
                        import ctypes
                        hwnd = self._window.native.Handle.ToInt32()
                        ctypes.windll.user32.ShowWindowAsync(hwnd, 5)  # SW_SHOW
                        ctypes.windll.user32.ShowWindowAsync(hwnd, 9)  # SW_RESTORE
                        ctypes.windll.user32.SetForegroundWindow(hwnd)
                        ctypes.windll.user32.BringWindowToTop(hwnd)
                    except Exception:
                        pass
                return
            except Exception as e:
                get_logger("ui.bridge").warning(f"In-window transition note: {e}")
        import subprocess
        from src.core.startup import get_application_executable
        try:
            exe = get_application_executable()
            if exe.lower().endswith("xsheild.exe"):
                subprocess.Popen([exe])
            else:
                subprocess.Popen([sys.executable, "-m", "src.ui.app"])
        except Exception as e:
            get_logger("ui.bridge").error(f"Error launching dashboard from splash: {e}")
        self.dismiss_splash()

    def get_gaming_mode_status(self) -> Dict[str, Any]:
        """Returns whether Silent/Gaming Mode is active."""
        from src.core.notifications import gaming_mode_manager
        return {"enabled": gaming_mode_manager.is_active}

    def start_window_drag(self) -> Dict[str, Any]:
        """Titlebar dragging is handled natively via .pywebview-drag-region."""
        return {"success": True}


class XSheildBridge:
    """Exposed to JavaScript in the PyWebView window under `window.pywebview.api`."""

    def __init__(self, webview_window=None):
        self._window = webview_window
        self.scanner = AntivirusScanner()
        self.quarantine_mgr = QuarantineManager()
        self.realtime_engine = RealtimeProtectionEngine(
            scanner=self.scanner,
            quarantine_mgr=self.quarantine_mgr,
            auto_quarantine=True
        )
        self.persistence_auditor = PersistenceAuditor(scanner=self.scanner)
        self.licensing_client = LicensingClient()
        self.razorpay_service = RazorpayService()

        # Connect threat events to UI callback
        self.realtime_engine.register_threat_listener(self._on_realtime_threat)

        # Start real-time surveillance by default
        try:
            self.realtime_engine.start_protection()
        except Exception:
            pass

        self._active_scan_report = None
        self._is_scanning = False
        self._is_maximized = False
        self._tray = None
        self._oauth_state = {"status": "idle", "message": None, "user": None}

        # High-performance in-memory cache to prevent IPC thread blocks
        self._cleaner_cache = None
        self._vuln_cache = None
        self._net_cache = None
        self._persistence_cache = None
        self._telemetry_cache = None

        # Initialize Autonomous Viral Marketing & Growth Engine
        try:
            from src.core.autonomous_growth_worker import AutonomousGrowthWorker
            self._growth_worker = AutonomousGrowthWorker()
            self._growth_worker.start_autonomous_engine()
        except Exception:
            self._growth_worker = None

        try:
            from src.marketing.ai_sales_team import ai_sales_engine
            ai_sales_engine.start_background_loop()
        except Exception:
            pass

    def set_window(self, win, hwnd_getter=None) -> None:
        """Assigns the pywebview host window safely without exposing native COM properties."""
        self._window = win
        self._hwnd_getter = hwnd_getter

    def set_tray(self, tray) -> None:
        """Assigns the system tray instance for background lifecycle coordination."""
        self._tray = tray

    def _on_realtime_threat(self, event: ThreatDetectedEvent):
        """Dispatches real-time alerts to the frontend via evaluate_js and triggers autonomous viral promotion."""
        if hasattr(self, "_growth_worker") and self._growth_worker:
            try:
                self._growth_worker.on_threat_neutralized(event.result.detection_name, event.result.file_path)
            except Exception:
                pass

        if self._window:
            payload = {
                "file_path": event.result.file_path,
                "detection_name": event.result.detection_name,
                "severity": event.result.severity.value,
                "action": event.action_taken,
                "timestamp": event.timestamp
            }
            try:
                js_code = f"window.onRealtimeThreatAlert({json.dumps(payload)});"
                self._window.evaluate_js(js_code)
            except Exception:
                pass

    # --- Scanning APIs ---

    def start_scan(self, mode_str: str = "QUICK", custom_path: Optional[str] = None) -> Dict[str, Any]:
        """Initiates an asynchronous scan job."""
        if self._is_scanning:
            return {"success": False, "error": "A scan is already in progress"}

        mode = ScanMode.QUICK
        if mode_str == "FULL":
            mode = ScanMode.FULL
        elif mode_str == "CUSTOM":
            mode = ScanMode.CUSTOM

        # Determine target path
        target = custom_path
        if not target:
            user_home = os.path.expanduser("~")
            if mode == ScanMode.QUICK:
                target = os.path.join(user_home, "Downloads")
            elif mode == ScanMode.FULL:
                target = user_home
            else:
                target = user_home

        self._is_scanning = True

        def run_worker():
            last_progress_time = [0.0]

            def on_progress(pct: int, current_file: str, threats: int):
                now = time.time()
                # Throttle progress events to WebView2 (max 12 updates/sec) to keep UI silky smooth
                if now - last_progress_time[0] >= 0.08 or pct >= 100 or threats > 0:
                    last_progress_time[0] = now
                    if self._window:
                        data = {"percent": pct, "file": os.path.basename(current_file), "threats": threats}
                        try:
                            self._window.evaluate_js(f"window.onScanProgress({json.dumps(data)});")
                        except Exception:
                            pass

            if mode == ScanMode.QUICK and not custom_path:
                report = self.scanner.scan_quick(progress_callback=on_progress)
            else:
                max_items = 500
                report = self.scanner.scan_directory(
                    target_path=target,
                    mode=mode,
                    progress_callback=on_progress,
                    max_files=max_items
                )
            self._active_scan_report = report
            self._is_scanning = False

            # Convert detections to JSON-serializable list
            detections_list = [
                {
                    "file_path": d.file_path,
                    "filename": os.path.basename(d.file_path),
                    "detection_name": d.detection_name,
                    "severity": d.severity.value,
                    "category": d.category.value,
                    "method": d.detection_method.value,
                    "sha256": d.sha256,
                    "recommended_action": d.recommended_action
                }
                for d in report.detections
            ]

            report_summary = {
                "scan_id": report.scan_id,
                "mode": report.mode.value,
                "total_scanned": report.total_files_scanned,
                "threats_found": report.threats_detected,
                "duration_seconds": report.duration_seconds,
                "clean_cache_hits": report.clean_cache_hits,
                "is_cancelled": report.is_cancelled,
                "detections": detections_list
            }

            # Play cyber sound alert and dispatch toast
            try:
                from src.core.audio import sound_engine
                if report.threats_detected > 0:
                    sound_engine.play_threat_intercepted()
                else:
                    sound_engine.play_system_safe()
            except Exception:
                pass

            try:
                from src.core.notifications import notification_service
                notification_service.show_scan_complete(
                    report.total_files_scanned,
                    report.threats_detected,
                    report.duration_seconds
                )
            except Exception:
                pass

            if self._window:
                try:
                    self._window.evaluate_js(f"window.onScanComplete({json.dumps(report_summary)});")
                except Exception:
                    pass

        threading.Thread(target=run_worker, daemon=True).start()
        return {"success": True, "target": target, "mode": mode.value}

    def cancel_scan(self) -> Dict[str, Any]:
        self.scanner.cancel_scan()
        self._is_scanning = False
        return {"success": True, "message": "Scan cancellation requested"}

    # --- Quarantine APIs ---

    def get_quarantine_items(self) -> List[Dict[str, Any]]:
        items = self.quarantine_mgr.list_items(include_restored=False)
        return [
            {
                "item_id": it.item_id,
                "original_path": it.original_path,
                "filename": it.original_filename,
                "detection_name": it.detection_name,
                "severity": it.severity.value,
                "category": it.detection_category.value,
                "quarantined_at": it.quarantined_at,
                "sha256": it.sha256,
                "file_size": it.file_size_bytes
            }
            for it in items
        ]

    def restore_quarantine_item(self, item_id: str) -> Dict[str, Any]:
        try:
            path = self.quarantine_mgr.restore_file(item_id)
            return {"success": True, "restored_path": path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_quarantine_item(self, item_id: str) -> Dict[str, Any]:
        try:
            self.quarantine_mgr.delete_item(item_id)
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # --- Real-Time Protection Control ---

    def toggle_realtime_protection(self, enable: bool) -> Dict[str, Any]:
        if enable:
            self.realtime_engine.start_protection()
        else:
            self.realtime_engine.stop_protection()
        return {"success": True, "is_active": self.realtime_engine.is_active}

    def get_realtime_status(self) -> Dict[str, Any]:
        return {
            "is_active": self.realtime_engine.is_active,
            "monitored_paths": self.realtime_engine.monitored_paths,
            "recent_threats_count": len(self.realtime_engine.threat_history)
        }

    # --- Ransomware Shield & Canary Surveillance ---

    def get_ransomware_status(self) -> Dict[str, Any]:
        """Returns the current operational status of the Ransomware Shield and Canary honeypots."""
        from src.core.ransomware_shield import ransomware_shield
        incidents = ransomware_shield.get_incident_history()
        return {
            "is_active": ransomware_shield.is_active,
            "emergency_mode": ransomware_shield.emergency_mode,
            "canary_count": len(ransomware_shield.canary_mgr._canary_manifest),
            "incidents_count": len(incidents),
            "recent_incidents": incidents[:5]
        }

    def audit_canaries(self) -> Dict[str, Any]:
        """Performs immediate integrity verification across all deployed canary decoys."""
        from src.core.ransomware_shield import ransomware_shield
        incidents = ransomware_shield.audit_canary_integrity()
        return {
            "status": "COMPLETED",
            "violations_detected": len(incidents),
            "emergency_mode": ransomware_shield.emergency_mode
        }

    def get_ransomware_incidents(self) -> List[Dict[str, Any]]:
        """Returns the complete audit log of ransomware and encryption incidents."""
        from src.core.ransomware_shield import ransomware_shield
        return ransomware_shield.get_incident_history()

    # --- Advanced Firewall & Network Surveillance ---

    def get_active_network_connections(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """Enumerates live TCP connections with responsive caching to prevent UI latency."""
        now = time.time()
        if not force_refresh and getattr(self, "_net_cache", None):
            cache_time, data = self._net_cache
            if now - cache_time < 15.0:
                return data

        from src.core.firewall import advanced_firewall
        conns = advanced_firewall.get_active_connections()
        data = [
            {
                "protocol": c.protocol,
                "local_address": f"{c.local_address}:{c.local_port}",
                "remote_address": f"{c.remote_address}:{c.remote_port}",
                "state": c.state,
                "pid": c.pid,
                "process_name": c.process_name,
                "is_suspicious": c.is_suspicious,
                "reason": c.suspicious_reason or "Normal traffic"
            }
            for c in conns
        ]
        self._net_cache = (now, data)
        return data

    def block_firewall_ip(self, ip_address: str) -> Dict[str, Any]:
        """Adds a target IP to the firewall blocklist."""
        from src.core.firewall import advanced_firewall
        ok = advanced_firewall.block_ip(ip_address, reason="Manual user block from Dashboard")
        return {"success": ok, "ip": ip_address}

    def unblock_firewall_ip(self, ip_address: str) -> Dict[str, Any]:
        """Removes a target IP from the firewall blocklist."""
        from src.core.firewall import advanced_firewall
        ok = advanced_firewall.unblock_ip(ip_address)
        return {"success": ok, "ip": ip_address}

    def audit_dns_hosts(self) -> Dict[str, Any]:
        """Audits the Windows hosts file for malicious DNS redirection."""
        from src.core.firewall import advanced_firewall
        return advanced_firewall.audit_hosts_file()

    def get_firewall_events(self) -> List[Dict[str, Any]]:
        """Returns the history of network events and firewall actions."""
        from src.core.firewall import advanced_firewall
        return advanced_firewall.get_network_events()

    # --- USB & Removable Media Security & Auto-Shield ---

    def get_usb_drives(self) -> List[Dict[str, Any]]:
        """Enumerates connected removable flash drives and storage volumes."""
        from src.core.usb_security import usb_guard
        drives = usb_guard.get_connected_drives()
        from dataclasses import asdict
        return [asdict(d) for d in drives]

    def immunize_usb_drive(self, drive_path: str) -> Dict[str, Any]:
        """Creates an immutable autorun.inf vaccine on the selected drive."""
        from src.core.usb_security import usb_guard
        return usb_guard.immunize_drive(drive_path)

    def scan_usb_drive(self, drive_path: str) -> Dict[str, Any]:
        """Deep scans removable media, neutralizes all threats, and unhides folders."""
        from src.core.usb_security import usb_guard
        from dataclasses import asdict
        result = usb_guard.disinfect_and_clean_drive(drive_path)
        return asdict(result)

    def get_usb_auto_shield_status(self) -> Dict[str, Any]:
        """Returns live status of background USB auto-detection and last disinfected drive."""
        from src.core.usb_security import usb_guard
        from dataclasses import asdict
        drives = [asdict(d) for d in usb_guard.get_connected_drives()]
        return {
            "is_auto_shield_running": usb_guard.is_auto_shield_running(),
            "connected_drives": drives,
            "removable_count": sum(1 for d in drives if d.get("is_removable")),
            "last_scan_result": usb_guard.get_last_scan_result()
        }

    def toggle_usb_auto_shield(self, enabled: bool) -> Dict[str, Any]:
        """Enables or disables real-time external media insertion auto-scan."""
        from src.core.usb_security import usb_guard
        usb_guard.set_auto_shield_enabled(enabled)
        return {
            "success": True,
            "is_auto_shield_running": usb_guard.is_auto_shield_running(),
            "message": f"USB Auto-Shield is now {'ACTIVE' if enabled else 'PAUSED'}"
        }

    def disinfect_and_clean_usb(self, drive_path: str) -> Dict[str, Any]:
        """Executes zero-tolerance threat neutralization, making drive 100% free from virus/threat."""
        from src.core.usb_security import usb_guard
        from dataclasses import asdict
        result = usb_guard.disinfect_and_clean_drive(drive_path)
        return asdict(result)

    # --- Identity, Authenticode & Microsoft WDSI Trust ---

    def get_trust_and_smartscreen_status(self) -> Dict[str, Any]:
        """Audits Authenticode digital signature, EV token readiness, and SmartScreen reputation."""
        from src.core.trust_verifier import trust_verifier
        return trust_verifier.audit_ev_readiness()

    def generate_wdsi_whitelisting_manifest(self) -> Dict[str, Any]:
        """Generates Microsoft Windows Defender Security Intelligence partner submission manifest."""
        from src.core.trust_verifier import trust_verifier
        return trust_verifier.generate_wdsi_whitelisting_manifest()

    # --- Viral Referral & Growth Engine ("Invite 3 Friends, Get 6 Months Pro Free") ---

    def claim_referral_reward(self) -> Dict[str, Any]:
        """Unlocks 6 months of Pro when 3 friends have been referred."""
        from src.core.referral_engine import referral_engine
        ok, msg, overview = referral_engine.claim_reward()
        return {"success": ok, "message": msg, "overview": overview}

    def apply_referral_code(self, code: str) -> Dict[str, Any]:
        """Applies a friend's referral code to receive +15 bonus evaluation days."""
        from src.core.referral_engine import referral_engine
        ok, msg = referral_engine.apply_invited_by_code(code)
        return {"success": ok, "message": msg, "overview": referral_engine.get_overview()}

    def credit_test_referral(self, friend_tag: str = "FRIEND_TEST_NODE") -> Dict[str, Any]:
        """Simulates or adds a referral credit for verification."""
        from src.core.referral_engine import referral_engine
        return referral_engine.add_referral_credit(friend_tag)

    # --- On-Device Neural Zero-Day ML Threat Classifier ---

    def evaluate_file_neural_ml(self, file_path: str) -> Dict[str, Any]:
        """Evaluates an unknown binary through the 3-layer neural structural anomaly model."""
        from src.core.ml_classifier import NeuralZeroDayClassifier
        return NeuralZeroDayClassifier.evaluate(file_path)

    # --- B2B Cloud Fleet Management Console & Section 65B Compliance ---

    def get_fleet_inventory(self) -> List[Dict[str, Any]]:
        """Returns inventory of managed endpoints in the corporate fleet."""
        from src.core.fleet_manager import fleet_manager
        return fleet_manager.get_fleet_inventory()

    def get_fleet_policy(self) -> Dict[str, Any]:
        """Returns corporate fleet security policies."""
        from src.core.fleet_manager import fleet_manager
        return fleet_manager.get_fleet_policy()

    def dispatch_fleet_command(self, command: str, target_hwid: str) -> Dict[str, Any]:
        """Dispatches administrative remote commands across fleet nodes."""
        from src.core.fleet_manager import fleet_manager
        return fleet_manager.dispatch_remote_command(command, target_hwid)

    def generate_section_65b_certificate(self, company_name: str = "Future Finger Technologies") -> Dict[str, Any]:
        """Generates court-admissible Section 65B Electronic Record Compliance Certificate."""
        from src.core.fleet_manager import fleet_manager
        return fleet_manager.generate_section_65b_compliance_certificate(company_name)

    # --- Privacy Guard & Sensor Auditing ---

    def get_privacy_report(self) -> Dict[str, Any]:
        """Audits active and recent webcam and microphone sensor access."""
        from src.core.privacy_guard import privacy_guard
        return privacy_guard.get_full_privacy_report()

    # --- Vulnerability Scanner ---

    def run_vulnerability_audit(self, force_refresh: bool = False) -> Dict[str, Any]:
        """Runs CIS baseline security audit with caching for instantaneous view responsiveness."""
        now = time.time()
        if not force_refresh and getattr(self, "_vuln_cache", None):
            cache_time, data = self._vuln_cache
            if now - cache_time < 120.0:
                return data

        from src.core.vulnerability_scanner import vulnerability_scanner
        data = vulnerability_scanner.run_full_vulnerability_audit()
        self._vuln_cache = (now, data)
        return data

    # --- AI Security Copilot ---

    def ask_copilot(self, user_query: str) -> Dict[str, Any]:
        """Processes on-device natural language security query without data exfiltration."""
        from src.core.copilot import ai_copilot
        from dataclasses import asdict
        resp = ai_copilot.process_query(user_query)
        return asdict(resp)

    # --- Persistence Surveillance ---

    def get_persistence_inventory(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        now = time.time()
        if not force_refresh and getattr(self, "_persistence_cache", None):
            cache_time, data = self._persistence_cache
            if now - cache_time < 45.0:
                return data

        entries = self.persistence_auditor.audit_all()
        data = [
            {
                "location": e.location,
                "name": e.entry_name,
                "command": e.raw_command,
                "target": e.target_executable,
                "exists": e.exists_on_disk,
                "is_suspicious": e.is_suspicious,
                "reasons": e.reasons
            }
            for e in entries
        ]
        self._persistence_cache = (now, data)
        return data

    # --- Licensing & Payments ---

    def get_licensing_status(self) -> Dict[str, Any]:
        return self.licensing_client.get_entitlement_status()

    def get_installation_info(self) -> Dict[str, Any]:
        """Returns machine installation date, version, and lifecycle details."""
        from src.core.installation import get_installation_info
        return get_installation_info()

    def activate_license_key(self, key_or_code: str) -> Dict[str, Any]:
        """
        Activates a commercial license key, free promotional code, or cryptographic offline token.
        Supported Free Codes include: FFT-FREE-PRO, XSHEILD-FREE-2026, FFT-LIFETIME-VIP, COMMUNITY-FREE
        """
        ok, msg, status = self.licensing_client.activate_promo_or_key(key_or_code)
        return {
            "success": ok,
            "message": msg if ok else None,
            "error": msg if not ok else None,
            "status": status
        }

    def create_razorpay_checkout(self, plan_id: str, email: str) -> Dict[str, Any]:
        """
        Creates a real, live Razorpay payment link and opens it in the default browser.
        Returns the link details for payment status tracking.
        """
        try:
            link = self.razorpay_service.create_payment_link(
                plan_id=plan_id,
                customer_email=email,
                device_id=self.licensing_client.device_id
            )
            # Open official Razorpay Checkout page in user's default browser
            short_url = link.get("short_url")
            if short_url:
                webbrowser.open(short_url)

            return {
                "success": True,
                "link_id": link["id"],
                "short_url": link["short_url"],
                "amount": link["amount"],
                "plan_id": plan_id
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def check_payment_status_and_activate(
        self,
        link_id: str,
        plan_id: str,
        email: str
    ) -> Dict[str, Any]:
        """
        Polls Razorpay server directly to verify if the payment link has been completed.
        Only issues and installs an entitlement token if Razorpay confirms status == 'paid'.
        """
        try:
            status_res = self.razorpay_service.verify_payment_link_status(link_id)
            if not status_res.get("is_paid"):
                return {
                    "success": False,
                    "is_paid": False,
                    "status": status_res.get("status", "pending"),
                    "error": "Payment is not yet completed on Razorpay. Please complete payment."
                }

            # Razorpay verified: issue signed entitlement token
            plan_info = PLAN_PRICING.get(plan_id, PLAN_PRICING["PRO_MONTHLY"])
            now = time.time()
            expires_at = now + (plan_info["duration_days"] * 86400)

            payload = {
                "token_id": f"tok_{uuid.uuid4().hex[:12]}",
                "user_id": f"usr_{uuid.uuid4().hex[:8]}",
                "plan": plan_info["plan_tier"],
                "device_id": self.licensing_client.device_id,
                "issued_at": int(now),
                "expires_at": int(expires_at),
                "features": PLAN_FEATURES.get(plan_info["plan_tier"], PLAN_FEATURES["PRO"]),
                "payment_id": status_res.get("payment_id", f"pay_live_{link_id}")
            }

            from src.licensing.token_verifier import create_signed_token, DEFAULT_HMAC_SECRET
            token = create_signed_token(payload, DEFAULT_HMAC_SECRET)

            ok, reason = self.licensing_client.install_license_token(token)
            if not ok:
                return {"success": False, "is_paid": True, "error": reason}

            return {
                "success": True,
                "is_paid": True,
                "plan": plan_info["plan_tier"],
                "expires_at": int(expires_at)
            }
        except Exception as e:
            return {"success": False, "is_paid": False, "error": str(e)}

    def open_external_url(self, url: str) -> bool:
        """Opens external URL in default desktop web browser."""
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False

    def create_razorpay_order(self, plan_id: str, email: str) -> Dict[str, Any]:
        """Creates official Razorpay order without fake simulated signature bypass."""
        try:
            order = self.razorpay_service.create_order(
                plan_id=plan_id,
                customer_email=email,
                device_id=self.licensing_client.device_id
            )
            return {"success": True, "order": order}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def verify_payment_and_activate(
        self,
        order_id: str,
        payment_id: str,
        signature: str,
        plan_id: str,
        email: str
    ) -> Dict[str, Any]:
        # Cryptographically verify signature against live secret
        if not self.razorpay_service.verify_payment_signature(order_id, payment_id, signature):
            return {"success": False, "error": "Invalid Razorpay payment signature"}

        plan_info = PLAN_PRICING.get(plan_id, PLAN_PRICING["PRO_MONTHLY"])
        now = time.time()
        expires_at = now + (plan_info["duration_days"] * 86400)

        payload = {
            "token_id": f"tok_{uuid.uuid4().hex[:12]}",
            "user_id": f"usr_{uuid.uuid4().hex[:8]}",
            "plan": plan_info["plan_tier"],
            "device_id": self.licensing_client.device_id,
            "issued_at": int(now),
            "expires_at": int(expires_at),
            "features": PLAN_FEATURES.get(plan_info["plan_tier"], PLAN_FEATURES["PRO"]),
            "payment_id": payment_id
        }

        from src.licensing.token_verifier import create_signed_token, DEFAULT_HMAC_SECRET
        token = create_signed_token(payload, DEFAULT_HMAC_SECRET)

        ok, reason = self.licensing_client.install_license_token(token)
        if not ok:
            return {"success": False, "error": reason}

        return {"success": True, "plan": plan_info["plan_tier"], "expires_at": int(expires_at)}

    def get_wsc_status(self) -> Dict[str, Any]:
        """Queries Windows Security Center coexistence and registered protection status."""
        from src.core.wsc_monitor import query_windows_security_products
        return query_windows_security_products()

    # --- System Metrics & Telemetry ---

    def get_system_telemetry(self) -> Dict[str, Any]:
        metrics = get_windows_system_metrics()
        now = time.time()
        if not getattr(self, "_telemetry_cache", None) or (now - self._telemetry_cache[0] > 12.0):
            lic = self.licensing_client.get_entitlement_status()
            quar_count = len(self.quarantine_mgr.list_items(include_restored=False))
            self._telemetry_cache = (now, lic, quar_count)
        else:
            _, lic, quar_count = self._telemetry_cache

        metrics["subscription"] = lic
        metrics["quarantine_count"] = quar_count
        metrics["realtime_running"] = self.realtime_engine.is_active
        return metrics

    def check_updates(self) -> Dict[str, Any]:
        """Checks for signed threat definition updates and queries threat intelligence status."""
        from src.core.auto_updater import auto_update_daemon
        return auto_update_daemon.check_now()

    # --- Software Updates & GitHub Distribution APIs ---

    def check_software_updates(self, channel: Optional[str] = None) -> Dict[str, Any]:
        """Queries distribution engine for latest XSHEILD software updates."""
        try:
            from src.core.software_updater import SoftwareUpdateManager
            mgr = SoftwareUpdateManager()
            return mgr.check_for_updates(channel=channel, force=True)
        except Exception as e:
            return {"update_available": False, "error": str(e), "current_version": "2.6.3", "latest_version": "2.6.3"}

    def apply_software_update(self, download_url: Optional[str] = None, expected_sha256: Optional[str] = None) -> Dict[str, Any]:
        """Downloads latest setup from GitHub asynchronously in background worker thread and executes update installation."""
        url = download_url or "https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/XSHEILD_Setup.exe"

        def _download_and_apply_worker():
            try:
                from src.core.software_updater import SoftwareUpdateManager
                mgr = SoftwareUpdateManager()

                def _progress_callback(pct, downloaded, total):
                    if self._window:
                        try:
                            self._window.evaluate_js(f"if (window.app && window.app.onDownloadProgress) window.app.onDownloadProgress({pct});")
                        except Exception:
                            pass

                ok, staged_path, msg = mgr.download_update(url, "XSHEILD_Setup.exe", expected_sha256=expected_sha256, progress_cb=_progress_callback)
                if not ok:
                    if self._window:
                        try:
                            self._window.evaluate_js(f"if (window.app && window.app.onDownloadComplete) window.app.onDownloadComplete(false, '{msg}');")
                        except Exception:
                            pass
                    return

                installed_ok, install_msg = mgr.apply_update_safely(staged_path, "2.6.3")
                if self._window:
                    try:
                        self._window.evaluate_js(f"if (window.app && window.app.onDownloadComplete) window.app.onDownloadComplete({str(installed_ok).lower()}, '{install_msg}');")
                    except Exception:
                        pass
            except Exception as ex:
                logger.error(f"Background update download error: {ex}")
                if self._window:
                    try:
                        self._window.evaluate_js(f"if (window.app && window.app.onDownloadComplete) window.app.onDownloadComplete(false, '{str(ex)}');")
                    except Exception:
                        pass

        threading.Thread(target=_download_and_apply_worker, daemon=True, name="SoftwareUpdateDownloaderWorker").start()
        return {"success": True, "status": "STARTED", "message": "Background update download started."}

    def download_and_install_software_update(self, download_url: str, target_filename: str, expected_sha256: str = "") -> Dict[str, Any]:
        """Downloads verified update from GitHub asynchronously and initiates atomic installation with rollback."""
        return self.apply_software_update(download_url=download_url, expected_sha256=expected_sha256 or None)

    # --- GitHub Cloud Decentralized Sync APIs ---

    def get_github_sync_status(self) -> Dict[str, Any]:
        """Returns the status of GitHub cloud synchronization across licenses, devices, contracts, and telemetry."""
        from src.core.github_sync_manager import github_sync_manager
        return github_sync_manager.get_sync_status()

    def trigger_github_sync(self) -> Dict[str, Any]:
        """Executes bidirectional cloud synchronization in background thread without blocking UI."""
        from src.core.github_sync_manager import github_sync_manager

        def _sync_worker():
            res = github_sync_manager.perform_full_sync()
            if self._window:
                try:
                    import json
                    json_str = json.dumps(res)
                    self._window.evaluate_js(f"if (window.app && window.app._updateGithubSyncUI) window.app._updateGithubSyncUI({json_str});")
                except Exception:
                    pass

        threading.Thread(target=_sync_worker, daemon=True, name="ManualSyncWorker").start()
        return github_sync_manager.get_sync_status()

    def get_software_update_settings(self) -> Dict[str, Any]:
        """Returns auto-update preferences and selected distribution channel."""
        try:
            from src.core.software_updater import SoftwareUpdateManager
            mgr = SoftwareUpdateManager()
            settings = mgr.get_settings()
            settings["current_version"] = mgr.current_version
            return settings
        except Exception as e:
            return {"channel": "stable", "auto_check": True, "auto_install": False, "current_version": "1.0.0"}

    def update_software_settings(self, new_settings: Dict[str, Any]) -> Dict[str, Any]:
        """Updates channel, check interval, or auto-install preferences."""
        try:
            from src.core.software_updater import SoftwareUpdateManager
            mgr = SoftwareUpdateManager()
            return mgr.update_settings(new_settings)
        except Exception as e:
            return {"error": str(e)}

    def get_software_update_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Returns historical journal of software update events and rollbacks."""
        try:
            from src.core.software_updater import SoftwareUpdateManager
            mgr = SoftwareUpdateManager()
            return mgr.get_update_history(limit=limit)
        except Exception:
            return []

    # --- Windows Startup & Animated Splash APIs ---

    def get_startup_status(self) -> Dict[str, Any]:
        """Returns whether XSHEILD is registered to run on Windows system startup."""
        from src.core.startup import get_startup_configuration
        return get_startup_configuration()

    def toggle_startup(self, enable: bool) -> Dict[str, Any]:
        """Enables or disables automatic execution on Windows startup."""
        from src.core.startup import enable_windows_startup, disable_windows_startup, get_startup_configuration
        if enable:
            enable_windows_startup(with_splash=True)
        else:
            disable_windows_startup()
        return get_startup_configuration()

    def dismiss_splash(self) -> None:
        """Closes or hides the startup splash window and pre-stages the full dashboard."""
        import pathlib
        from src.core.logger import get_logger
        get_logger("ui.bridge").info("Splash screen dismissed: pre-staging dashboard & background protection active in tray.")
        if self._window:
            try:
                hwnd = self._get_window_hwnd() if hasattr(self, "_get_window_hwnd") else 0
                if hwnd:
                    import ctypes
                    ctypes.windll.user32.ShowWindowAsync(hwnd, 0)
                if getattr(self._window, "native", None):
                    native = self._window.native
                    if hasattr(native, "BeginInvoke"):
                        import System
                        native.BeginInvoke(System.Action(native.Hide))
                from src.ui.app import INDEX_HTML, get_centered_window_geometry
                uri = pathlib.Path(INDEX_HTML).as_uri()
                w, h, x, y = get_centered_window_geometry(1220, 695)
                self._window.load_url(uri)
                self._window.resize(w, h)
                self._window.move(x, y)
            except Exception as e:
                get_logger("ui.bridge").debug(f"Splash dismiss pre-stage notice: {e}")

    def open_dashboard_from_splash(self) -> None:
        """Transitions from splash screen to the full XSHEILD dashboard."""
        import pathlib
        from src.core.logger import get_logger
        get_logger("ui.bridge").info("Splash action: launching full dashboard.")
        if self._window:
            try:
                from src.ui.app import INDEX_HTML, get_centered_window_geometry
                w, h, x, y = get_centered_window_geometry(1220, 695)
                uri = pathlib.Path(INDEX_HTML).as_uri()
                self._window.load_url(uri)
                self._window.resize(w, h)
                self._window.move(x, y)
                self._window.show()
                self._window.restore()
                if getattr(self._window, "native", None):
                    try:
                        import ctypes
                        hwnd = self._window.native.Handle.ToInt32()
                        ctypes.windll.user32.ShowWindowAsync(hwnd, 5)  # SW_SHOW
                        ctypes.windll.user32.ShowWindowAsync(hwnd, 9)  # SW_RESTORE
                        ctypes.windll.user32.SetForegroundWindow(hwnd)
                        ctypes.windll.user32.BringWindowToTop(hwnd)
                    except Exception:
                        pass
                return
            except Exception as e:
                get_logger("ui.bridge").warning(f"In-window transition note: {e}")
        import subprocess
        from src.core.startup import get_application_executable
        try:
            exe = get_application_executable()
            if exe.lower().endswith("xsheild.exe"):
                subprocess.Popen([exe])
            else:
                subprocess.Popen([sys.executable, "-m", "src.ui.app"])
        except Exception as e:
            get_logger("ui.bridge").error(f"Error launching dashboard from splash: {e}")
        self.dismiss_splash()

    # --- Gaming Mode & Native Notification APIs ---

    def get_gaming_mode_status(self) -> Dict[str, Any]:
        """Returns whether Silent/Gaming Mode is active."""
        from src.core.notifications import gaming_mode_manager
        return {"enabled": gaming_mode_manager.is_active}

    def toggle_gaming_mode(self, enable: bool) -> Dict[str, Any]:
        """Toggles Silent/Gaming Mode to suppress or allow popups and chimes."""
        from src.core.notifications import gaming_mode_manager
        active = gaming_mode_manager.set_gaming_mode(enable)
        return {"enabled": active}

    def trigger_test_notification(self) -> Dict[str, Any]:
        """Sends a sample notification to verify Windows Action Center connectivity."""
        from src.core.notifications import notification_service
        ok = notification_service.show_toast(
            title="🛡️ XSHEILD Security Test",
            message="Windows Action Center notification channel is operational."
        )
        return {"success": ok}

    # --- Scheduled Scans APIs ---

    def get_scheduled_scans(self) -> List[Dict[str, Any]]:
        """Returns all configured scheduled scanning jobs."""
        from src.core.scheduler import scan_scheduler
        return scan_scheduler.list_jobs()

    def save_scheduled_scan(self, job_data: Dict[str, Any]) -> Dict[str, Any]:
        """Creates or updates a scheduled scan job."""
        from src.core.scheduler import scan_scheduler
        return scan_scheduler.save_job(job_data)

    def delete_scheduled_scan(self, job_id: str) -> Dict[str, Any]:
        """Deletes a scheduled scan job."""
        from src.core.scheduler import scan_scheduler
        ok = scan_scheduler.delete_job(job_id)
        return {"success": ok}

    def trigger_scheduled_scan_now(self, job_id: str) -> Dict[str, Any]:
        """Immediately executes a scheduled scan."""
        from src.core.scheduler import scan_scheduler
        res = scan_scheduler.trigger_job(job_id)
        return res or {"status": "error", "message": "Job not found"}

    # --- Scan Exclusions & Allowlist APIs ---

    def get_exclusions(self) -> Dict[str, Any]:
        """Returns all configured path, extension, and hash exclusions."""
        from src.core.exclusions import exclusion_manager
        return {"success": True, "exclusions": exclusion_manager.get_all_exclusions()}

    def add_path_exclusion(self, path: str) -> Dict[str, Any]:
        """Adds a path or directory exclusion."""
        from src.core.exclusions import exclusion_manager
        ok = exclusion_manager.add_path_exclusion(path)
        return {"success": ok, "exclusions": exclusion_manager.get_all_exclusions()}

    def remove_path_exclusion(self, path: str) -> Dict[str, Any]:
        """Removes a path exclusion."""
        from src.core.exclusions import exclusion_manager
        ok = exclusion_manager.remove_path_exclusion(path)
        return {"success": ok, "exclusions": exclusion_manager.get_all_exclusions()}

    def add_extension_exclusion(self, ext: str) -> Dict[str, Any]:
        """Adds a file extension exclusion."""
        from src.core.exclusions import exclusion_manager
        ok = exclusion_manager.add_extension_exclusion(ext)
        return {"success": ok, "exclusions": exclusion_manager.get_all_exclusions()}

    def remove_extension_exclusion(self, ext: str) -> Dict[str, Any]:
        """Removes an extension exclusion."""
        from src.core.exclusions import exclusion_manager
        ok = exclusion_manager.remove_extension_exclusion(ext)
        return {"success": ok, "exclusions": exclusion_manager.get_all_exclusions()}

    def add_trusted_hash(self, sha256_hash: str) -> Dict[str, Any]:
        """Adds a trusted SHA-256 hash to allowlist."""
        from src.core.exclusions import exclusion_manager
        ok = exclusion_manager.add_trusted_hash(sha256_hash)
        return {"success": ok, "exclusions": exclusion_manager.get_all_exclusions()}

    # --- User Account & Registration APIs ---

    def get_user_account(self) -> Dict[str, Any]:
        """Returns the profile of the current registered or guest user."""
        from src.licensing.auth import auth_manager
        return auth_manager.get_current_user()

    def signup_user(
        self,
        full_name: str,
        email: str,
        password: str,
        confirm_password: str,
        otp_code: Optional[str] = None
    ) -> Dict[str, Any]:
        """Registers a new user account with credentials, optional OTP validation, and activates protection."""
        from src.licensing.auth import auth_manager
        return auth_manager.register_user(full_name, email, password, confirm_password, otp_code=otp_code)

    def login_user(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticates user with email and password."""
        from src.licensing.auth import auth_manager
        return auth_manager.login_user(email, password)

    def logout_user(self) -> Dict[str, Any]:
        """Logs out current active user session."""
        from src.licensing.auth import auth_manager
        return auth_manager.logout_user()

    def send_email_otp(self, email: str) -> Dict[str, Any]:
        """Generates and dispatches a 6-digit email verification OTP."""
        from src.licensing.otp import otp_service
        return otp_service.generate_otp(email)

    def verify_email_otp(self, email: str, otp_code: str) -> Dict[str, Any]:
        """Validates an entered 6-digit OTP code against the pending record."""
        from src.licensing.otp import otp_service
        return otp_service.verify_otp(email, otp_code)

    def login_with_google(self) -> Dict[str, Any]:
        """
        Initiates Google OAuth 2.0 loopback flow in the user's default browser.
        Handles authorization code capture, token exchange, and account synchronization.
        """
        from src.licensing.google_auth import google_oauth_service
        from src.licensing.auth import auth_manager
        from src.core.logger import get_logger

        log = get_logger("ui.bridge")
        self._oauth_state = {
            "status": "in_progress",
            "message": "Awaiting Google Sign-In in browser...",
            "user": None
        }

        def on_success(user_info: Dict[str, Any]):
            try:
                res = auth_manager.login_or_register_oauth(
                    email=user_info.get("email", ""),
                    full_name=user_info.get("name", ""),
                    provider="google",
                    provider_id=user_info.get("sub"),
                    picture=user_info.get("picture")
                )
                self._oauth_state = {
                    "status": "success",
                    "message": res.get("message", "Google Sign-In successful"),
                    "user": res.get("user")
                }
                log.info(f"Google OAuth flow completed for {user_info.get('email')}")
                if self._window:
                    try:
                        safe_json = json.dumps(res).replace("'", "\\'")
                        js_cmd = f"if (window.app && window.app.onOAuthSuccess) window.app.onOAuthSuccess({json.dumps(res)});"
                        self._window.evaluate_js(js_cmd)
                    except Exception as e:
                        log.debug(f"Direct JS OAuth callback note: {e}")
            except Exception as ex:
                log.error(f"Failed to complete OAuth user setup: {ex}")
                self._oauth_state = {
                    "status": "error",
                    "message": f"Account registration failed: {ex}",
                    "user": None
                }

        def on_error(err_msg: str):
            log.warning(f"Google OAuth flow failed or cancelled: {err_msg}")
            self._oauth_state = {
                "status": "error",
                "message": err_msg,
                "user": None
            }
            if self._window:
                try:
                    js_cmd = f"if (window.app && window.app.onOAuthError) window.app.onOAuthError({json.dumps(err_msg)});"
                    self._window.evaluate_js(js_cmd)
                except Exception:
                    pass

        return google_oauth_service.initiate_login(on_success=on_success, on_error=on_error)

    def get_oauth_status(self) -> Dict[str, Any]:
        """Queries the current status of any in-flight Google OAuth flow."""
        return self._oauth_state

    # --- Error Management & Support Escalation APIs ---

    def get_recent_errors(self) -> List[Dict[str, Any]]:
        """Returns the list of recorded crash and error events."""
        from src.core.error_reporter import error_reporter
        return error_reporter.list_recent_errors(limit=10)

    def submit_error_report(
        self,
        error_type: str,
        error_message: str,
        stack_trace: str,
        source: str = "DesktopUI",
        user_notes: str = ""
    ) -> Dict[str, Any]:
        """
        Records an application error and provides automated support dispatch to futurefingerindia@gmail.com.
        """
        from src.core.error_reporter import error_reporter
        record = error_reporter.record_error(
            error_type=error_type,
            error_message=error_message,
            stack_trace=stack_trace,
            source=source,
            user_notes=user_notes
        )
        mailto_url = error_reporter.generate_mailto_url(record)
        return {
            "success": True,
            "record_id": record["record_id"],
            "support_email": error_reporter.support_email,
            "mailto_url": mailto_url
        }

    def open_support_email_client(self, user_notes: str = "", error_type: str = "User Issue Report") -> Dict[str, Any]:
        """
        Opens Windows default mail client pre-filled with support address futurefingerindia@gmail.com.
        """
        from src.core.error_reporter import error_reporter
        record = error_reporter.record_error(
            error_type=error_type,
            error_message="User requested direct support assistance",
            stack_trace="No crash. Manual inquiry submitted via Desktop UI.",
            source="UserHelpDesk",
            user_notes=user_notes
        )
        opened = error_reporter.open_email_client_for_report(record)
        return {
            "success": opened,
            "support_email": error_reporter.support_email,
            "mailto_url": error_reporter.generate_mailto_url(record)
        }

    # --- Live Engine Logs & Subsystem Health Diagnostics ---

    def get_engine_logs(self, lines: int = 80, log_type: str = "all") -> Dict[str, Any]:
        """Returns the recent tail of rolling application activity or error logs."""
        from src.core.logger import read_recent_logs
        log_lines = read_recent_logs(lines=lines, log_type=log_type)
        return {
            "success": True,
            "log_type": log_type,
            "lines": log_lines,
            "count": len(log_lines)
        }

    def get_health_status(self) -> Dict[str, Any]:
        """Runs full health and issue diagnostics across all operational security layers."""
        from src.core.health_checker import health_checker
        return health_checker.run_full_diagnostic()

    def export_diagnostics_bundle(self) -> Dict[str, Any]:
        """Packages rolling logs, crash journals, and metrics into a support zip in Downloads."""
        from src.core.logger import create_diagnostics_bundle
        return create_diagnostics_bundle()

    # --- Frameless Window Controls & Hardware Dragging ---

    def _get_window_hwnd(self) -> Optional[int]:
        """Resolves the Win32 HWND of the pywebview application window."""
        if os.name != "nt":
            return None
        try:
            import ctypes
            user32 = ctypes.windll.user32
            if self._window:
                for attr in ("gui", "native", "handle"):
                    obj = getattr(self._window, attr, None)
                    if obj:
                        if hasattr(obj, "Handle"):
                            return int(obj.Handle)
                        elif isinstance(obj, int):
                            return obj

            current_pid = os.getpid()
            found_hwnd = []

            def _enum_windows_cb(hwnd, _):
                if user32.IsWindowVisible(hwnd):
                    proc_id = ctypes.c_ulong()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(proc_id))
                    if proc_id.value == current_pid:
                        found_hwnd.append(hwnd)
                return True

            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
            user32.EnumWindows(WNDENUMPROC(_enum_windows_cb), 0)
            if found_hwnd:
                return found_hwnd[0]

            return user32.GetForegroundWindow()
        except Exception:
            return None

    def start_window_drag(self) -> Dict[str, Any]:
        """
        Initiates native Windows titlebar dragging on mouse-down.
        Engages the Windows Desktop Window Manager (DWM) for zero-latency,
        hardware-accelerated window movement with Aero Snap support.
        """
        if os.name == "nt":
            try:
                import ctypes
                user32 = ctypes.windll.user32
                hwnd = self._get_window_hwnd()
                if hwnd and user32.IsWindow(hwnd):
                    user32.ReleaseCapture()
                    # 0x00A1 = WM_NCLBUTTONDOWN, 2 = HTCAPTION
                    user32.SendMessageW(hwnd, 0x00A1, 2, 0)
                    return {"success": True}
            except Exception as e:
                return {"success": False, "error": str(e)}
        return {"success": False, "error": "Non-Windows or window not ready"}

    def move_window(self, x: int, y: int) -> Dict[str, Any]:
        """Moves the desktop application window to exact desktop coordinates (x, y)."""
        if self._window:
            try:
                self._window.move(int(x), int(y))
                return {"success": True, "x": int(x), "y": int(y)}
            except Exception as e:
                return {"success": False, "error": str(e)}
        return {"success": False, "error": "No window host"}

    def minimize_app_window(self) -> Dict[str, Any]:
        """Minimizes the window cleanly to the taskbar with zero hang risk."""
        hwnd = self._hwnd_getter() if getattr(self, "_hwnd_getter", None) else 0
        if not hwnd:
            hwnd = self._get_window_hwnd() or 0
        if hwnd:
            try:
                import ctypes
                ctypes.windll.user32.ShowWindowAsync(hwnd, 6) # SW_MINIMIZE
                ctypes.windll.user32.PostMessageW(hwnd, 0x0112, 0xF020, 0) # SC_MINIMIZE
            except Exception:
                pass
        try:
            if self._window:
                self._window.minimize()
        except Exception:
            pass
        return {"success": True}

    def toggle_maximize_window(self) -> Dict[str, Any]:
        """Toggles between maximized and restored window states cleanly using native Win32 IsZoomed query."""
        hwnd = self._hwnd_getter() if getattr(self, "_hwnd_getter", None) else 0
        if not hwnd:
            hwnd = self._get_window_hwnd() or 0
        if hwnd:
            try:
                import ctypes
                is_zoomed = (ctypes.windll.user32.IsZoomed(hwnd) != 0)
                target_max = not is_zoomed
                self._is_maximized = target_max
                sw_cmd = 3 if target_max else 9 # SW_MAXIMIZE = 3, SW_RESTORE = 9
                ctypes.windll.user32.ShowWindowAsync(hwnd, sw_cmd)
                sc_cmd = 0xF030 if target_max else 0xF120
                ctypes.windll.user32.PostMessageW(hwnd, 0x0112, sc_cmd, 0)
                return {"success": True, "maximized": target_max}
            except Exception:
                pass

        self._is_maximized = not getattr(self, "_is_maximized", False)
        try:
            if self._window:
                if self._is_maximized:
                    self._window.maximize()
                else:
                    self._window.restore()
        except Exception:
            pass
        return {"success": True, "maximized": self._is_maximized}

    def close_app_window(self) -> Dict[str, Any]:
        """Closes or hides the desktop application window cleanly with ZERO hang or deadlock risk."""
        def _deferred_hide():
            import time
            time.sleep(0.04)  # Allow pywebview IPC to deliver return value while window is still visible
            hwnd = self._hwnd_getter() if getattr(self, "_hwnd_getter", None) else 0
            if not hwnd:
                hwnd = self._get_window_hwnd() or 0
            if hwnd:
                try:
                    import ctypes
                    ctypes.windll.user32.ShowWindowAsync(hwnd, 0)  # SW_HIDE = 0
                except Exception:
                    pass

        import threading
        threading.Thread(target=_deferred_hide, daemon=True, name="DeferredHideWorker").start()
        return {"success": True, "action": "hidden_to_tray"}

    def exit_application(self) -> Dict[str, Any]:
        """Completely terminates XSHEILD application and background services."""
        self._force_exit = True
        hwnd = self._hwnd_getter() if getattr(self, "_hwnd_getter", None) else 0
        if not hwnd:
            hwnd = self._get_window_hwnd() or 0
        if hwnd:
            try:
                import ctypes
                ctypes.windll.user32.ShowWindowAsync(hwnd, 0) # SW_HIDE
            except Exception:
                pass
        if self._tray:
            try:
                self._tray.stop()
            except Exception:
                pass
        import threading
        def _delayed_exit():
            import time
            time.sleep(0.1)
            import os
            os._exit(0)
        threading.Thread(target=_delayed_exit, daemon=True, name="DelayedExitWorker").start()
        return {"success": True}


    # --- System Cleaner APIs (CCleaner Equivalent) ---

    def get_cleaner_categories(self) -> Dict[str, Any]:
        """Returns metadata for all available system cleaner modules."""
        from src.core.system_cleaner import system_cleaner
        cats = system_cleaner.get_supported_categories()
        data = {}
        for cat_id, meta in cats.items():
            data[cat_id] = {
                "id": meta.category_id,
                "name": meta.display_name,
                "description": meta.description,
                "icon": meta.icon,
                "target_count": len(meta.paths_or_targets)
            }
        return {"success": True, "categories": data}

    def analyze_system_cleaner(self, force_refresh: bool = False) -> Dict[str, Any]:
        """Deep analysis of junk files across all system areas with memory caching to prevent lag."""
        now = time.time()
        if not force_refresh and getattr(self, "_cleaner_cache", None):
            cache_time, data = self._cleaner_cache
            if now - cache_time < 90.0:
                return data

        from src.core.system_cleaner import system_cleaner
        data = system_cleaner.analyze()
        self._cleaner_cache = (now, data)
        return data

    def run_system_cleaner(self, categories: Optional[List[str]] = None) -> Dict[str, Any]:
        """Safely cleans specified junk categories and returns exact freed bytes."""
        self._cleaner_cache = None
        from src.core.system_cleaner import system_cleaner
        return system_cleaner.clean(category_ids=categories)

    # --- Legal Onboarding, EULA & Exclusive Delhi Jurisdiction APIs ---

    def get_legal_agreement_info(self) -> Dict[str, Any]:
        """Returns the legal agreement text, mandatory clauses, and consent status."""
        from src.core.legal_terms import EULA_AND_TERMS_TEXT, SUMMARY_DISCLAIMER_BULLETS, OFFICIAL_JURISDICTION, PUBLISHER_NAME, AGREEMENT_VERSION
        from src.core.legal_telemetry import legal_consent_manager
        return {
            "is_agreed": legal_consent_manager.is_consent_given(),
            "agreement_text": EULA_AND_TERMS_TEXT,
            "bullets": SUMMARY_DISCLAIMER_BULLETS,
            "jurisdiction": OFFICIAL_JURISDICTION,
            "publisher": PUBLISHER_NAME,
            "version": AGREEMENT_VERSION,
            "recipient_email": "futurefingerindia@gmail.com",
            "consent_record": legal_consent_manager.get_consent_record()
        }

    def submit_legal_consent(
        self,
        user_name: str,
        user_email: str,
        organization: str = "",
        agree_terms: bool = False,
        agree_delhi: bool = False,
        agree_telemetry: bool = False
    ) -> Dict[str, Any]:
        """Validates click-wrap checkboxes, registers consent, and dispatches dossier to futurefingerindia@gmail.com."""
        from src.core.legal_telemetry import legal_consent_manager
        checkboxes = {
            "agree_terms": bool(agree_terms),
            "agree_delhi_jurisdiction": bool(agree_delhi),
            "agree_telemetry": bool(agree_telemetry)
        }
        return legal_consent_manager.record_and_dispatch_consent(
            user_name=user_name,
            user_email=user_email,
            organization=organization,
            checkboxes=checkboxes
        )

    # --- Referral & Viral Growth Engine APIs ---

    def get_referral_overview(self) -> Dict[str, Any]:
        """Retrieves or creates the user's viral referral profile, sharing URLs, and reward stats."""
        from src.core.growth_engine import growth_engine
        from src.core.legal_telemetry import legal_consent_manager
        from src.core.referral_engine import referral_engine

        consent = legal_consent_manager.get_consent_record() or {}
        user_name = consent.get("user_name") or "Valued Sentinel"
        user_email = consent.get("user_email") or f"user_{self.licensing_client.device_id[:6]}@xsheild.io"

        profile = growth_engine.get_or_create_user_referral_profile(user_name, user_email)
        milestone = referral_engine.get_overview()
        profile["milestone_target"] = milestone.get("referrals_target", 3)
        profile["milestone_count"] = milestone.get("referrals_count", 0)
        profile["is_reward_eligible"] = milestone.get("is_reward_eligible", False)
        profile["reward_claimed"] = milestone.get("reward_claimed", False)
        profile["reward_description"] = milestone.get("reward_description", "6 Months XSHEILD Pro License Free (180 Days)")

        return {"success": True, "profile": profile, "milestone": milestone}

    def redeem_referral_code(self, referral_code: str) -> Dict[str, Any]:
        """Redeems an invitation code for +16 extra Pro trial days and credits referrer +30 days."""
        from src.core.growth_engine import growth_engine
        from src.core.legal_telemetry import legal_consent_manager

        consent = legal_consent_manager.get_consent_record() or {}
        user_name = consent.get("user_name") or "Referred User"
        user_email = consent.get("user_email") or f"user_{self.licensing_client.device_id[:6]}@xsheild.io"

        res = growth_engine.process_referral_attribution(
            referred_code=referral_code,
            new_user_name=user_name,
            new_user_email=user_email,
            new_device_id=self.licensing_client.device_id
        )

        if res.get("success"):
            # Automatically extend active license state on this machine by 16 days
            try:
                state = self.licensing_client._load_state()
                curr_exp = state.get("expires_at", int(time.time()))
                state["expires_at"] = max(curr_exp, int(time.time())) + (16 * 86400)
                state["plan"] = "PRO"
                state["is_trial"] = False
                self.licensing_client._save_state(state)
            except Exception:
                pass

        return res

    def get_share_links(self, custom_message: str = "") -> Dict[str, Any]:
        """Returns updated share URLs across WhatsApp, Telegram, Email, and Facebook."""
        from src.core.growth_engine import growth_engine, BASE_DOWNLOAD_URL
        import urllib.parse

        ref_info = self.get_referral_overview().get("profile", {})
        code = ref_info.get("referral_code", "")
        ref_url = f"{BASE_DOWNLOAD_URL}?ref={code}"

        msg = custom_message.strip() or f"Protect your Windows PC with XSHEILD Next-Gen Antivirus! Use my referral code {code} for free Pro security: {ref_url}"
        enc_msg = urllib.parse.quote(msg)
        enc_url = urllib.parse.quote(ref_url)

        return {
            "referral_url": ref_url,
            "referral_code": code,
            "share_links": {
                "whatsapp": f"https://api.whatsapp.com/send?text={enc_msg}",
                "telegram": f"https://t.me/share/url?url={enc_url}&text={enc_msg}",
                "email": f"mailto:?subject=Free%20XSHEILD%20Pro%20Antivirus%20License&body={enc_msg}",
                "facebook": f"https://www.facebook.com/sharer/sharer.php?u={enc_url}"
            }
        }

    def get_autonomous_viral_payload(self) -> Dict[str, Any]:
        """Provides pre-computed 1-click sharing URLs and referral stats for client UI."""
        if not hasattr(self, "_growth_worker") or not self._growth_worker:
            from src.core.autonomous_growth_worker import AutonomousGrowthWorker
            self._growth_worker = AutonomousGrowthWorker()
        return self._growth_worker.generate_share_payload()

    # --- AI Marketing Agents APIs ---
    def get_marketing_ecosystem_status(self) -> Dict[str, Any]:
        """Queries status of Outclaw, Loopmark, UnifAPI, and MCP marketing connectors."""
        try:
            from src.marketing.orchestrator import marketing_orchestrator
            return marketing_orchestrator.get_marketing_ecosystem_status()
        except Exception as e:
            return {"status": "ERROR", "error": str(e)}

    def run_ai_marketing_campaign(self) -> Dict[str, Any]:
        """Executes a full multi-agent marketing campaign across all squads and platforms."""
        try:
            from src.marketing.orchestrator import marketing_orchestrator
            return marketing_orchestrator.run_comprehensive_growth_campaign()
        except Exception as e:
            return {"status": "ERROR", "error": str(e)}

    # --- Autonomous AI Sales Team APIs ---
    def get_ai_sales_status(self) -> Dict[str, Any]:
        """Returns autonomous AI sales team dashboard, active roster, and cycle metrics."""
        try:
            from src.marketing.ai_sales_team import ai_sales_engine
            return ai_sales_engine.get_dashboard_status()
        except Exception as e:
            return {"engine_status": "ERROR", "error": str(e)}

    def trigger_ai_sales_sprint(self) -> Dict[str, Any]:
        """Triggers an on-demand autonomous self-marketing sprint across all 6 sales agents."""
        try:
            from src.marketing.ai_sales_team import ai_sales_engine
            return ai_sales_engine.execute_sales_cycle()
        except Exception as e:
            return {"status": "ERROR", "error": str(e)}

    def get_recent_marketing_campaigns(self) -> Dict[str, Any]:
        """Retrieves recently persisted campaigns from %LOCALAPPDATA%\\XSHEILD\\marketing_campaigns\\."""
        try:
            import json
            local_data = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD")
            camp_dir = os.path.join(local_data, "marketing_campaigns")
            b2b_p = os.path.join(camp_dir, "b2b_outreach_pitches.json")
            soc_p = os.path.join(camp_dir, "social_media_threads.json")
            prop_p = os.path.join(camp_dir, "enterprise_proposals.json")

            b2b_data = json.load(open(b2b_p, "r", encoding="utf-8")) if os.path.isfile(b2b_p) else None
            soc_data = json.load(open(soc_p, "r", encoding="utf-8")) if os.path.isfile(soc_p) else None
            prop_data = json.load(open(prop_p, "r", encoding="utf-8")) if os.path.isfile(prop_p) else None

            return {
                "success": True,
                "b2b_outreach": b2b_data,
                "social_campaign": soc_data,
                "enterprise_proposal": prop_data
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def trigger_one_click_share(self, channel: str = "whatsapp") -> Dict[str, Any]:
        """Opens WhatsApp, Email, or Telegram share dialog with zero user thinking."""
        if not hasattr(self, "_growth_worker") or not self._growth_worker:
            from src.core.autonomous_growth_worker import AutonomousGrowthWorker
            self._growth_worker = AutonomousGrowthWorker()

        channel_lower = channel.lower()
        if channel_lower == "whatsapp":
            ok = self._growth_worker.share_via_whatsapp()
        elif channel_lower == "email":
            ok = self._growth_worker.share_via_email()
        elif channel_lower == "telegram":
            ok = self._growth_worker.share_via_telegram()
        else:
            payload = self._growth_worker.generate_share_payload()
            import webbrowser
            ok = webbrowser.open(payload.get("linkedin_url", payload["referral_url"]))

        return {"status": "success", "channel": channel, "opened": ok}

    # --- Enterprise License Administration APIs ---

    def admin_get_license_stats(self) -> Dict[str, Any]:
        """Aggregated enterprise metrics: active licenses, seats, revenue."""
        from src.core.license_admin import get_license_admin_manager
        return get_license_admin_manager().get_license_stats()

    def admin_list_licenses(self, status_filter: str = "ALL", query: str = "") -> List[Dict[str, Any]]:
        """Returns managed enterprise licenses matching filter."""
        from src.core.license_admin import get_license_admin_manager
        return get_license_admin_manager().list_licenses(status_filter=status_filter, query=query)

    def admin_issue_license(
        self,
        customer_name: str,
        customer_email: str,
        plan: str = "PRO",
        duration_days: int = 365,
        organization: str = "",
        max_devices: int = 1,
        bound_device_id: str = "",
        notes: str = ""
    ) -> Dict[str, Any]:
        """Issues an Ed25519 cryptographically signed license."""
        from src.core.license_admin import get_license_admin_manager
        try:
            record = get_license_admin_manager().issue_license(
                customer_name=customer_name,
                customer_email=customer_email,
                plan=plan,
                duration_days=int(duration_days),
                organization=organization,
                max_devices=int(max_devices) if max_devices else None,
                bound_device_id=bound_device_id,
                notes=notes
            )
            return {"success": True, "license": record}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def admin_bulk_generate_licenses(
        self,
        count: int = 5,
        plan: str = "PRO",
        duration_days: int = 365,
        org_prefix: str = "Enterprise Bulk",
        max_devices: int = 1
    ) -> Dict[str, Any]:
        """Bulk generates licenses for enterprise batch distribution."""
        from src.core.license_admin import get_license_admin_manager
        try:
            records = get_license_admin_manager().bulk_generate(
                count=int(count),
                plan=plan,
                duration_days=int(duration_days),
                org_prefix=org_prefix,
                max_devices=int(max_devices) if max_devices else 1
            )
            return {"success": True, "count": len(records), "licenses": records}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def admin_revoke_license(self, license_id: str, reason: str = "") -> Dict[str, Any]:
        """Revokes a license."""
        from src.core.license_admin import get_license_admin_manager
        ok, msg = get_license_admin_manager().revoke_license(license_id, reason)
        return {"success": ok, "message": msg}

    def admin_suspend_license(self, license_id: str, reason: str = "") -> Dict[str, Any]:
        """Suspends a license."""
        from src.core.license_admin import get_license_admin_manager
        ok, msg = get_license_admin_manager().suspend_license(license_id, reason)
        return {"success": ok, "message": msg}

    def admin_reactivate_license(self, license_id: str) -> Dict[str, Any]:
        """Reactivates a suspended license."""
        from src.core.license_admin import get_license_admin_manager
        ok, msg = get_license_admin_manager().reactivate_license(license_id)
        return {"success": ok, "message": msg}

    def admin_extend_license(self, license_id: str, additional_days: int = 30) -> Dict[str, Any]:
        """Extends license duration."""
        from src.core.license_admin import get_license_admin_manager
        ok, msg = get_license_admin_manager().extend_license(license_id, int(additional_days))
        return {"success": ok, "message": msg}

    def admin_transfer_device_seat(
        self,
        license_id: str,
        old_device_id: str,
        new_device_id: str,
        new_device_name: str = ""
    ) -> Dict[str, Any]:
        """Transfers device seat from old hardware to new hardware."""
        from src.core.license_admin import get_license_admin_manager
        ok, msg = get_license_admin_manager().transfer_device_seat(
            license_id, old_device_id, new_device_id, new_device_name
        )
        return {"success": ok, "message": msg}

    def admin_get_audit_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Returns tamper-evident admin action audit logs."""
        from src.core.license_admin import get_license_admin_manager
        return get_license_admin_manager().get_license_audit_logs(limit=int(limit))

    def admin_export_licenses(self, export_format: str = "json") -> Dict[str, Any]:
        """Exports licenses as JSON or CSV content."""
        from src.core.license_admin import get_license_admin_manager
        mgr = get_license_admin_manager()
        if export_format.lower() == "csv":
            return {"success": True, "format": "csv", "data": mgr.export_licenses_csv()}
        return {"success": True, "format": "json", "data": mgr.export_licenses_json()}

    # --- Customer CRM & Growth Intelligence APIs ---

    def admin_get_crm_leads(self) -> List[Dict[str, Any]]:
        """Returns all inbound prospects in the lead CRM."""
        from src.core.growth_engine import growth_engine
        return growth_engine.get_crm_leads()

    def admin_add_crm_lead(
        self,
        name: str,
        email: str,
        phone: str = "",
        organization: str = "",
        source: str = "INBOUND",
        notes: str = ""
    ) -> Dict[str, Any]:
        """Registers a new prospective customer lead into the CRM."""
        from src.core.growth_engine import growth_engine
        return growth_engine.add_crm_lead(
            name=name,
            email=email,
            phone=phone,
            organization=organization,
            source=source,
            notes=notes
        )

    def get_ai_growth_metrics(self) -> Dict[str, Any]:
        """Calculates growth velocity, conversion, CAC, MRR, and ARR."""
        from src.core.growth_engine import growth_engine
        return growth_engine.compute_growth_metrics()

    def get_ai_growth_recommendations(self) -> Dict[str, Any]:
        """Returns AI growth recommendations and strategy."""
        from src.core.growth_engine import growth_engine
        return growth_engine.generate_ai_growth_strategy()

    def generate_ai_marketing_content(self, campaign_type: str = "WHATSAPP") -> Dict[str, str]:
        """Generates viral campaign copy tailored for WhatsApp, Email, or Social Media."""
        from src.core.growth_engine import growth_engine
        return growth_engine.generate_marketing_campaign_copy(campaign_type=campaign_type)

    def dispatch_growth_report_to_futurefinger(self, report_type: str = "DAILY_EXECUTIVE_SUMMARY") -> Dict[str, Any]:
        """Assembles and dispatches the comprehensive growth intelligence report to futurefingerindia@gmail.com."""
        from src.core.growth_engine import growth_engine
        return growth_engine.dispatch_comprehensive_growth_report(report_type=report_type)
