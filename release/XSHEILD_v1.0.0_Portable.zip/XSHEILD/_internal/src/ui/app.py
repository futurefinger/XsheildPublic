"""
XSHEILD Desktop Application Runner
Owner: Future Finger Technologies
Launches hardware-accelerated Microsoft Edge WebView2 desktop application with authenticated IPC bridge.
"""

import os
import sys

# Ensure repository root and PyInstaller bundle paths are in sys.path
def _bootstrap_paths():
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        for p in [os.path.join(exe_dir, "_internal"), exe_dir]:
            if p not in sys.path:
                sys.path.insert(0, p)
        
        # Safely prioritize local src disk files without shadowing 3rd-party binary extensions (e.g. cryptography)
        class _DiskSrcFinder:
            @classmethod
            def find_spec(cls, fullname, path=None, target=None):
                if fullname == "src" or fullname.startswith("src."):
                    from importlib.machinery import PathFinder
                    return PathFinder.find_spec(fullname, path, target)
                return None

        if not any(getattr(f, "__name__", "") == "_DiskSrcFinder" for f in sys.meta_path):
            sys.meta_path.insert(0, _DiskSrcFinder)
    else:
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if root_dir not in sys.path:
            sys.path.insert(0, root_dir)

_bootstrap_paths()

import argparse
import subprocess
import threading
import webview

from src.ui.bridge import XSheildBridge, SplashBridge
from src.ui.tray import XSheildTray

def _resolve_resource_dir() -> str:
    """Resolves root directory for static UI and branding assets across dev and PyInstaller frozen modes."""
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        candidates = [
            getattr(sys, "_MEIPASS", ""),
            os.path.join(exe_dir, "_internal"),
            exe_dir,
        ]
        for candidate in candidates:
            if candidate and os.path.exists(os.path.join(candidate, "src", "ui", "static", "index.html")):
                return candidate
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


ROOT_DIR = _resolve_resource_dir()
STATIC_DIR = os.path.join(ROOT_DIR, "src", "ui", "static")
INDEX_HTML = os.path.join(STATIC_DIR, "index.html")
SPLASH_HTML = os.path.join(STATIC_DIR, "splash.html")
APP_ICON = os.path.join(ROOT_DIR, "assets", "branding", "xsheild.ico")


def get_centered_window_geometry(target_width: int = 1220, target_height: int = 700):
    """
    Computes responsive window dimensions and exact centered coordinates on Windows.
    Accommodates 1366x768 laptop screens up to 4K displays with taskbar padding.
    """
    import ctypes
    try:
        user32 = ctypes.windll.user32
        user32.SetProcessDPIAware()
        screen_w = user32.GetSystemMetrics(0)  # SM_CXSCREEN
        screen_h = user32.GetSystemMetrics(1)  # SM_CYSCREEN
    except Exception:
        screen_w, screen_h = 1366, 768

    max_allowed_w = max(800, screen_w - 60)
    max_allowed_h = max(550, screen_h - 75)

    w = min(target_width, max_allowed_w)
    h = min(target_height, max_allowed_h)

    x = max(0, (screen_w - w) // 2)
    y = max(0, (screen_h - h) // 2)

    return w, h, x, y


def _open_full_dashboard():
    """Launches or brings up the full XSHEILD dashboard."""
    from src.core.startup import get_application_executable
    try:
        exe = get_application_executable()
        if exe.lower().endswith("xsheild.exe"):
            subprocess.Popen([exe])
        else:
            subprocess.Popen([sys.executable, "-m", "src.ui.app"])
    except Exception as e:
        print(f"[XSHEILD] Error launching dashboard: {e}")


def launch_application():
    """Initializes and runs the XSHEILD desktop application."""
    # 1. Setup centralized rotating activity and error logging
    try:
        from src.core.logger import setup_logging
        setup_logging()
    except Exception as e:
        print(f"[XSHEILD] Logger initialization notice: {e}")

    # 2. Install global exception and crash hooks to report errors to futurefingerindia@gmail.com
    try:
        from src.core.error_reporter import error_reporter
        error_reporter.install_global_exception_hooks()
    except Exception as e:
        print(f"[XSHEILD] Error reporter hook notice: {e}")

    import time
    from src.core.logger import get_logger
    logger = get_logger("ui.app")
    logger.info(f"XSHEILD process launched (PID: {os.getpid()}, Args: {sys.argv})")

    parser = argparse.ArgumentParser(description="XSHEILD Endpoint Security by Future Finger Technologies")
    parser.add_argument("--startup", action="store_true", help="Launch on Windows startup with animated safety verification splash")
    parser.add_argument("--splash", action="store_true", help="Preview animated safety verification splash screen")
    parser.add_argument("--minimized", action="store_true", help="Start background protection silently in system tray")
    parser.add_argument("--tray", action="store_true", help="Start background protection silently in system tray")
    parser.add_argument("--uninstall", action="store_true", help="Uninstall XSHEILD from the system")
    parser.add_argument("--silent", action="store_true", help="Silent mode for uninstallation")
    args, _ = parser.parse_known_args()

    if getattr(args, "uninstall", False):
        logger.info("Uninstall command detected. Launching uninstaller workflow...")
        try:
            from src.core.uninstaller import perform_uninstall
            perform_uninstall(silent=getattr(args, "silent", False))
        except Exception as e:
            logger.error(f"Uninstallation error: {e}")
        sys.exit(0)

    # --- Cross-Process Single Instance & Activation Coordination ---
    from src.core.single_instance import single_instance_manager

    current_window = [None]
    current_bridge = [None]
    cached_hwnd = [0]
    is_in_splash_mode = [bool(getattr(args, "startup", False) or getattr(args, "splash", False))]

    def _get_window_hwnd():
        if cached_hwnd[0]:
            try:
                import ctypes
                if ctypes.windll.user32.IsWindow(cached_hwnd[0]):
                    return cached_hwnd[0]
            except Exception:
                pass
        win = current_window[0]
        if win and getattr(win, "native", None):
            try:
                import ctypes
                h = int(win.native.Handle.ToInt32())
                if h and ctypes.windll.user32.IsWindow(h):
                    cached_hwnd[0] = h
                    return h
            except Exception:
                pass
        try:
            import ctypes
            import ctypes.wintypes
            user32 = ctypes.windll.user32
            my_pid = os.getpid()
            found_h = [0]
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
            def _enum(h, lp):
                pid = ctypes.wintypes.DWORD()
                user32.GetWindowThreadProcessId(h, ctypes.byref(pid))
                if pid.value == my_pid:
                    buf = ctypes.create_unicode_buffer(512)
                    user32.GetWindowTextW(h, buf, 512)
                    if "XSHEILD" in buf.value:
                        found_h[0] = h
                        return False
                return True
            user32.EnumWindows(WNDENUMPROC(_enum), 0)
            if found_h[0]:
                cached_hwnd[0] = found_h[0]
                return found_h[0]
        except Exception:
            pass
        return 0

    def _restore_and_focus_window():
        """Restores XSHEILD window from minimized or hidden state and focuses it to the foreground cleanly without deadlocks."""
        hwnd = _get_window_hwnd()
        logger.info(f"Restoring XSHEILD window presentation (HWND: {hex(hwnd) if hwnd else 'None'})")

        import ctypes
        if not hwnd or not ctypes.windll.user32.IsWindow(hwnd):
            logger.warning("Native window handle is destroyed or invalid. Launching fresh dashboard presentation...")
            try:
                from src.core.startup import get_application_executable
                target_exe = get_application_executable()
                if target_exe.lower().endswith("xsheild.exe"):
                    subprocess.Popen([target_exe])
                else:
                    subprocess.Popen([sys.executable, "-m", "src.ui.app"])
                return
            except Exception as ex_spawn:
                logger.error(f"Error relaunching window: {ex_spawn}")

        # 1. pywebview engine-level show and unminimize
        win = current_window[0]
        if win:
            try:
                win.show()
                win.restore()
            except Exception as e_win:
                logger.debug(f"pywebview win.show/restore notice: {e_win}")

        # 2. Bulletproof Win32 foreground elevation & focus stealing bypass
        if hwnd:
            try:
                import ctypes
                user32 = ctypes.windll.user32
                kernel32 = ctypes.windll.kernel32

                SW_SHOWNORMAL = 1
                SW_SHOW = 5
                SW_RESTORE = 9
                HWND_TOP = 0
                HWND_TOPMOST = -1
                HWND_NOTOPMOST = -2
                SWP_NOMOVE = 0x0002
                SWP_NOSIZE = 0x0001
                SWP_SHOWWINDOW = 0x0040

                # Ensure window is visible and restored
                user32.ShowWindow(hwnd, SW_SHOWNORMAL)
                user32.ShowWindow(hwnd, SW_SHOW)
                user32.ShowWindow(hwnd, SW_RESTORE)

                # Thread input attachment trick to bypass Windows foreground lock
                fore_hwnd = user32.GetForegroundWindow()
                fore_tid = user32.GetWindowThreadProcessId(fore_hwnd, None)
                cur_tid = kernel32.GetCurrentThreadId()

                if fore_tid and fore_tid != cur_tid:
                    user32.AttachThreadInput(cur_tid, fore_tid, True)
                    user32.BringWindowToTop(hwnd)
                    user32.SetForegroundWindow(hwnd)
                    user32.AttachThreadInput(cur_tid, fore_tid, False)
                else:
                    user32.BringWindowToTop(hwnd)
                    user32.SetForegroundWindow(hwnd)

                # Topmost elevation pulse ensures window pops directly to the user's front
                user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                user32.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                user32.SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
            except Exception as ex:
                logger.debug(f"Win32 window presentation elevation notice: {ex}")

        # 3. Native WinForms show if running in CLR environment
        if win and getattr(win, "native", None):
            try:
                native = win.native
                def _do_native_show():
                    try:
                        native.WindowState = 0  # FormWindowState.Normal = 0
                        native.Show()
                        native.Activate()
                        native.BringToFront()
                    except Exception:
                        pass
                if hasattr(native, "BeginInvoke") and getattr(native, "InvokeRequired", False):
                    try:
                        import System
                        native.BeginInvoke(System.Action(_do_native_show))
                    except Exception:
                        _do_native_show()
                else:
                    _do_native_show()
            except Exception as ex:
                logger.debug(f"Native BeginInvoke show notice: {ex}")

        if win:
            try:
                import pathlib
                if is_in_splash_mode[0]:
                    is_in_splash_mode[0] = False
                    uri = pathlib.Path(INDEX_HTML).as_uri()
                    win.load_url(uri)
                    w, h, x, y = get_centered_window_geometry(1220, 695)
                    win.resize(w, h)
                    win.move(x, y)
            except Exception as ex:
                logger.debug(f"Splash transition notice: {ex}")

            try:
                win.evaluate_js("if (window.app && typeof window.app.restoreFocus === 'function') { window.app.restoreFocus(); } else if (window.app && typeof window.app.dismissIntroFlash === 'function') { window.app.dismissIntroFlash(); }")
            except Exception:
                pass

    def _handle_ipc_command(command: str):
        cmd = command.strip().upper()
        logger.info(f"Received IPC activation command: '{cmd}'")
        win = current_window[0]
        br = current_bridge[0]
        if not win:
            logger.warning("IPC command received but window reference is missing.")
            return

        if cmd in ("RESTORE", "SHOW", "OPEN", "FOCUS"):
            _restore_and_focus_window()
        elif cmd == "SCAN":
            _restore_and_focus_window()
            if br:
                br.start_scan("QUICK")

    is_primary = single_instance_manager.acquire(on_command=_handle_ipc_command)
    if not is_primary:
        if args.startup or args.splash or getattr(args, "tray", False) or getattr(args, "minimized", False):
            logger.info("Secondary instance invoked in silent background/tray mode while XSHEILD is already active. Exiting silently.")
            sys.exit(0)
        else:
            logger.info("Secondary instance requested dashboard focus. Notifying primary instance and exiting.")
            single_instance_manager.notify_existing_and_exit(command="RESTORE")
            return

    bridge = XSheildBridge()
    current_bridge[0] = bridge

    # Always ensure real-time protection is spinning up
    try:
        bridge.realtime_engine.start_protection()
        logger.info("Real-time filesystem protection engine armed and active.")
    except Exception as e:
        logger.error(f"Real-time engine start error: {e}")

    # Ensure Windows startup is enabled by default so XSHEILD protects on boot
    try:
        from src.core.startup import is_windows_startup_enabled, enable_windows_startup
        if not is_windows_startup_enabled():
            enable_windows_startup(with_splash=True)
            logger.info("Automatic Windows boot startup enabled for XSHEILD.")
    except Exception as e:
        logger.warning(f"Startup registration check notice: {e}")

    # Configure pywebview settings for hardware-accelerated drag regions
    try:
        webview.settings['DRAG_REGION_SELECTOR'] = '.pywebview-drag-region'
        webview.settings['DRAG_REGION_DIRECT_TARGET_ONLY'] = False
    except Exception:
        pass

    is_splash_mode = bool(getattr(args, "startup", False) or getattr(args, "splash", False))
    if is_splash_mode and os.path.exists(SPLASH_HTML):
        logger.info("Windows Startup/Splash mode detected: Opening 3D animated verification splash screen.")
        initial_url = SPLASH_HTML
        w, h, x, y = get_centered_window_geometry(640, 460)
        title = "XSHEILD — System Safety Verification"
    else:
        if not os.path.exists(INDEX_HTML):
            logger.critical(f"HTML entry point not found: {INDEX_HTML}")
            sys.exit(1)
        initial_url = INDEX_HTML
        w, h, x, y = get_centered_window_geometry(1220, 695)
        title = "XSHEILD — Beyond Antivirus. Your Digital Bodyguard."

    is_tray_mode = bool(getattr(args, "minimized", False) or getattr(args, "tray", False))
    logger.info(f"Creating XSHEILD application window (tray_mode={is_tray_mode}) centered at ({x}, {y}) with size ({w}x{h}) [URL: {initial_url}]...")
    window = webview.create_window(
        hidden=is_tray_mode,
        title=title,
        url=initial_url,
        js_api=bridge,
        width=w,
        height=h,
        x=x,
        y=y,
        min_size=(960, 560),
        frameless=True,
        easy_drag=False,
        draggable=False,
        shadow=True,
        focus=True,
        background_color="#070B19"
    )

    # Ensure foreground focus and bind high-DPI Windows icon after WebView2 is fully loaded
    def on_window_ready():
        logger.info("XSHEILD window loaded event fired. Ensuring top-level active foreground and taskbar minimizability.")
        try:
            hwnd = _get_window_hwnd()
            if hwnd:
                cached_hwnd[0] = hwnd
                import ctypes
                user32 = ctypes.windll.user32

                if not is_tray_mode:
                    # Activate foreground window asynchronously
                    user32.ShowWindowAsync(hwnd, 5)  # SW_SHOW
                    user32.ShowWindowAsync(hwnd, 9)  # SW_RESTORE
                    user32.SetForegroundWindow(hwnd)
                    user32.BringWindowToTop(hwnd)
                else:
                    user32.ShowWindowAsync(hwnd, 0)  # SW_HIDE

                # Bind crisp high-DPI application icon to Taskbar and Alt+Tab switcher
                try:
                    WM_SETICON = 0x0080
                    IMAGE_ICON = 1
                    LR_LOADFROMFILE = 0x0010
                    icon_paths = [
                        os.path.join(ROOT_DIR, "assets", "branding", "xsheild.ico"),
                        os.path.join(ROOT_DIR, "_internal", "assets", "branding", "xsheild.ico"),
                        os.path.join(os.path.dirname(sys.executable), "assets", "branding", "xsheild.ico"),
                        os.path.join(os.path.dirname(sys.executable), "xsheild.ico"),
                    ]
                    for ic_p in icon_paths:
                        if os.path.isfile(ic_p):
                            # Small icon for taskbar & titlebar (32x32)
                            h_icon_sm = ctypes.windll.user32.LoadImageW(None, ic_p, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
                            if h_icon_sm:
                                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 0, h_icon_sm)
                            # Large icon for Alt+Tab switcher (256x256)
                            h_icon_lg = ctypes.windll.user32.LoadImageW(None, ic_p, IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
                            if h_icon_lg:
                                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 1, h_icon_lg)
                            logger.info(f"Bound high-DPI icon from {ic_p} to window handle {hwnd}")
                            break
                except Exception as ex:
                    logger.debug(f"Taskbar icon binding notice: {ex}")
        except Exception as e:
            logger.debug(f"Foreground elevation notice: {e}")

        # If legal consent is already registered on this machine, synchronize directly with WebView2
        try:
            from src.core.legal_telemetry import legal_consent_manager
            if legal_consent_manager.is_consent_given():
                window.evaluate_js("if (typeof localStorage !== 'undefined') { localStorage.setItem('xsheild_legal_agreed', 'true'); if (window.app) window.app.hideLegalConsentModal(); }")
        except Exception as ex:
            logger.debug(f"Consent sync notice: {ex}")

    window.events.loaded += on_window_ready

    def on_window_closing():
        if getattr(bridge, "_force_exit", False):
            logger.info("Application force-exit authorized.")
            return True
        logger.info("Window close event intercepted: hiding cleanly to system tray with zero deadlock risk.")
        def _deferred_closing_hide():
            import time
            time.sleep(0.02)
            hwnd = _get_window_hwnd()
            if hwnd:
                try:
                    import ctypes
                    ctypes.windll.user32.ShowWindowAsync(hwnd, 0)  # SW_HIDE = 0
                except Exception:
                    pass
        import threading
        threading.Thread(target=_deferred_closing_hide, daemon=True, name="DeferredClosingHideWorker").start()
        return False

    window.events.closing += on_window_closing

    bridge.set_window(window, hwnd_getter=_get_window_hwnd)
    current_window[0] = window

    # Initialize System Tray in background thread for continuous surveillance & fast restore
    tray = None
    try:
        def _on_tray_open():
            try:
                _restore_and_focus_window()
            except Exception as e:
                logger.error(f"Error restoring window from tray: {e}")

        def _on_tray_scan():
            try:
                _restore_and_focus_window()
                win = current_window[0]
                if win:
                    win.evaluate_js("if (window.app) { window.app.showView('scan-quick'); window.app.runScan('QUICK'); }")
                else:
                    bridge.start_scan("QUICK")
            except Exception as e:
                logger.error(f"Error starting quick scan from tray: {e}")

        def _on_tray_exit():
            logger.info("Exit requested from tray menu. Terminating cleanly.")
            bridge.exit_application()

        tray = XSheildTray(
            on_open_callback=_on_tray_open,
            on_scan_callback=_on_tray_scan,
            on_exit_callback=_on_tray_exit
        )
        tray.start(daemon=True)
        bridge.set_tray(tray)
    except Exception as e:
        logger.error(f"Failed to start system tray in normal mode: {e}")

    # Start background telemetry heartbeat & activation beacon
    try:
        from src.core.telemetry_beacon import telemetry_beacon
        telemetry_beacon.start_background_daemon()
    except Exception as e:
        logger.warning(f"Telemetry beacon init: {e}")

    # Start background Edge Sales Ambassador & Distributed Marketing Node
    try:
        from src.core.edge_sales_ambassador import edge_ambassador
        edge_ambassador.start_background_daemon()
    except Exception as e:
        logger.warning(f"Edge sales ambassador init: {e}")

    # Start background GitHub Software Auto-Updater & Windows Startup Version Checker
    try:
        def _startup_version_check_worker():
            time.sleep(8)  # Wait for Windows startup network & DNS resolution
            logger.info("Initiating Windows startup software version check against GitHub...")
            try:
                from src.core.software_updater import software_update_manager
                software_update_manager.start_background_scheduler()
                res = software_update_manager.check_for_updates()
                if res.get("update_available"):
                    latest_ver = res.get("latest_version")
                    logger.info(f"Startup Version Check: New release v{latest_ver} discovered! Downloading update package...")
                    download_url = res.get("installer_url") or "https://raw.githubusercontent.com/futurefinger/XsheildPublic/main/release/XSHEILD_Setup.exe"
                    sha = res.get("checksums", {}).get("XSHEILD_Setup.exe") or res.get("raw_release", {}).get("sha256")
                    ok, staged_path, msg = software_update_manager.download_update(download_url, f"XSHEILD_Setup_v{latest_ver}.exe", expected_sha256=sha)
                    if ok:
                        logger.info(f"Startup Version Check: Update package v{latest_ver} staged successfully at {staged_path}")
                        if tray:
                            try:
                                tray.notify(
                                    f"XSHEILD v{latest_ver} is downloaded & ready to install. Click to protect your PC with the latest update.",
                                    "XSHEILD Update Available"
                                )
                            except Exception:
                                pass
                        if current_window[0]:
                            try:
                                current_window[0].evaluate_js(f"if (window.app && window.app.notifyUpdateAvailable) window.app.notifyUpdateAvailable('{latest_ver}');")
                            except Exception:
                                pass
                else:
                    logger.info(f"Startup Version Check: XSHEILD is up to date (Version {software_update_manager.current_version}).")
            except Exception as ex:
                logger.debug(f"Startup version check deferred: {ex}")

            # Also poll threat intelligence definitions
            try:
                from src.core.threat_updater import threat_intel_manager
                threat_intel_manager.poll_definitions_update()
            except Exception as ex:
                logger.debug(f"Startup threat definitions poll deferred: {ex}")

        startup_updater_thread = threading.Thread(target=_startup_version_check_worker, daemon=True, name="XSHEILD-StartupUpdater")
        startup_updater_thread.start()
        logger.info("XSHEILD background startup version checker thread initialized.")

        # Initialize Centralized GitHub Telemetry, Fleet Inventory, and Legal Consent Sync
        try:
            from src.core.github_telemetry_sync import start_background_github_sync
            start_background_github_sync(delay_seconds=4.0)
            logger.info("XSHEILD GitHub Fleet & Legal Telemetry sync engine initialized.")
        except Exception as e_gh_sync:
            logger.debug(f"GitHub fleet sync init notice: {e_gh_sync}")
    except Exception as e:
        logger.warning(f"Startup updater worker init notice: {e}")

    # Play gentle futuristic shield boot chime
    try:
        from src.core.audio import sound_engine
        sound_engine.play_shield_online()
    except Exception:
        pass

    # If launched with --minimized, start with window hidden
    if is_tray_mode:
        try:
            hwnd_initial = _get_window_hwnd()
            if hwnd_initial:
                import ctypes
                ctypes.windll.user32.ShowWindowAsync(hwnd_initial, 0)
        except Exception:
            pass

    # Run with Edge Chromium Evergreen runtime on Windows with persistent profile storage
    webview_storage = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD", "WebView2Data")
    os.makedirs(webview_storage, exist_ok=True)
    try:
        webview.start(gui="edgechromium", debug=False, storage_path=webview_storage)
    except Exception as e:
        logger.critical(f"WebView2 runtime initialization error: {e}")
        try:
            import ctypes
            import webbrowser
            MB_OK = 0x00000000
            MB_ICONERROR = 0x00000010
            MB_TOPMOST = 0x00040000
            MB_SETFOREGROUND = 0x00010000
            msg = (
                "XSHEILD requires the Microsoft Edge WebView2 Runtime to display its user interface.\n\n"
                f"Initialization notice: {e}\n\n"
                "The Microsoft WebView2 Evergreen download page will now open. "
                "Please install the runtime and relaunch XSHEILD."
            )
            ctypes.windll.user32.MessageBoxW(0, msg, "XSHEILD — Microsoft WebView2 Required", MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND)
            webbrowser.open("https://go.microsoft.com/fwlink/p/?LinkId=2124703")
        except Exception:
            pass


if __name__ == "__main__":
    launch_application()
