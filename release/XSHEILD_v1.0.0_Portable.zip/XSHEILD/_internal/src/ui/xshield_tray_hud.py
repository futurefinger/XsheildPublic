"""
XSHEILD Celestial Meditation Sentinel HUD & Hyper-Dimensional Idle Matrix
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
Official Destination: futurefingerindia@gmail.com

Features:
1. Sacred Meditating Human Form (Cosmic Yogi in Lotus Padmasana Silhouette) — Compact 50% Scale (230x220).
2. Core security telemetry, health metrics, and console actions displayed cleanly inside the meditating body.
3. Fully animated 3D/4D/5D/6D sacred geometry, rotating gyroscopic rings & Merkaba field.
4. 7 Luminous Pulsing Chakra gemstones (Sahasrara down to Muladhara) along the Sushumna spine.
5. Levitating prana breathing physics, ascending quantum light particles, and fluid rainbow aura gradients.
6. Genuine Windows Desktop Transparency (-transparentcolor #010409) with zero box clutter.
7. Polite, non-intrusive idle behavior: awakens during idle (>25s), vanishes instantly on touch (<100ms).
"""

import os
import sys
import time
import math
import random
import ctypes
import webbrowser
from typing import Optional, Dict, Any, List, Tuple
import threading
import tkinter as tk

# Adjust paths to import xshield modules
CUR_DIR = os.path.dirname(os.path.abspath(__file__))
XSHIELD_ROOT = os.path.dirname(os.path.dirname(CUR_DIR))
if XSHIELD_ROOT not in sys.path:
    sys.path.insert(0, XSHIELD_ROOT)

try:
    from src.core.software_updater import CURRENT_APP_VERSION
except Exception:
    CURRENT_APP_VERSION = "2.6.3"

try:
    from src.licensing.auth import UserAuthManager
except Exception:
    UserAuthManager = None


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]


def get_system_idle_seconds() -> float:
    """Returns elapsed time in seconds since the last system-wide keyboard/mouse input."""
    try:
        lii = LASTINPUTINFO()
        lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
        if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii)):
            millis = ctypes.windll.kernel32.GetTickCount() - lii.dwTime
            return max(0.0, millis / 1000.0)
    except Exception:
        pass
    return 0.0


def get_taskbar_work_area() -> Tuple[int, int, int, int]:
    """Retrieves current monitor work area excluding Windows taskbar."""
    try:
        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                        ("right", ctypes.c_long), ("bottom", ctypes.c_long)]
        rect = RECT()
        if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0):
            return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)
    except Exception:
        pass
    return 0, 0, 1920, 1080


# 5 Harmonic Psychological Sentinel States with Compact 50% Tags
MEDITATION_PSYCHOLOGY_STATES = [
    {
        "headline": "100% Protected",
        "short_tag": "DEEP WORK • SECURE",
        "badge": "14 KERNEL SHIELDS",
        "metric": "0 Threat Vectors",
        "primary_color": "#00f0ff",
        "secondary_color": "#00f59b",
        "aura_hue": "#8b5cf6"
    },
    {
        "headline": "Silent Eco Guard",
        "short_tag": "ULTRA-LOW 24MB RAM",
        "badge": "ZERO-LAG OPTIMIZED",
        "metric": "CPU: 0.1% • RAM: 23.8MB",
        "primary_color": "#00f59b",
        "secondary_color": "#10b981",
        "aura_hue": "#06b6d4"
    },
    {
        "headline": "Zero-Day Immunity",
        "short_tag": "NEURAL TRIPWIRES ARMED",
        "badge": "HEURISTICS: ARMED",
        "metric": "Behavioral Sentry Live",
        "primary_color": "#38bdf8",
        "secondary_color": "#818cf8",
        "aura_hue": "#ec4899"
    },
    {
        "headline": "Vault Locked",
        "short_tag": "AES-256 ENCRYPTED",
        "badge": "DATA INTEGRITY: OK",
        "metric": "Audit Trail Clean",
        "primary_color": "#f59e0b",
        "secondary_color": "#00f0ff",
        "aura_hue": "#10b981"
    },
    {
        "headline": "Perimeter Active",
        "short_tag": "DNS SHIELD ENFORCED",
        "badge": "SOCKET GUARD: ON",
        "metric": "Inbound Stealth Active",
        "primary_color": "#06b6d4",
        "secondary_color": "#3b82f6",
        "aura_hue": "#f43f5e"
    },
]


class XShieldTrayHUD:
    """
    Multidimensional Meditation Human Form Sentry HUD (Ultra-Compact Micro Scale 116x110).
    Renders a serene yogic human in lotus padmasana with 3D/4D rotating energy rings.
    Sits cleanly in the bottom-right taskbar area with genuine desktop transparency.
    """

    # Ultra-Compact dimensions with generous 3D Action Canvas (152x162)
    WIDTH = 152
    HEIGHT = 162

    def __init__(self, auth_manager: Optional[Any] = None, on_open_dashboard: Optional[Any] = None):
        self.auth_manager = auth_manager or (UserAuthManager() if UserAuthManager else None)
        self.on_open_dashboard = on_open_dashboard
        self.root: Optional[tk.Tk] = None
        self.canvas: Optional[tk.Canvas] = None
        self.is_running = False
        self._hovered = False
        self._hovered_btn = False
        self._hovered_buy_btn = False
        self._state = "INITIAL"  # INITIAL, DISMISSED, IDLE_ANIMATING, FADING_OUT

        # Animation timing
        self._anim_timer = 0.0
        self._state_cycle_timer = 0.0
        self._state_idx = 0

        # Timing and professional antivirus dwell duration
        self._last_dismissed_time = time.time()
        self._idle_anim_started_time = 0.0
        self._user_returned_time: Optional[float] = None
        self._idle_threshold_seconds = 25.0
        self._idle_cooldown_seconds = 180.0
        self._max_idle_animation_sec = 60.0
        self._active_dwell_seconds = 18.0      # Stays visible for at least 18s when user moves mouse, allowing easy clicking
        self._startup_display_seconds = 15.0   # Visible for 15s on app launch

        # Scaled prana particles (x, y, vy, size, hue_offset)
        self._particles = [
            [
                random.uniform(-30, 30),
                random.uniform(25, 90),
                random.uniform(0.4, 1.0),
                random.uniform(0.8, 1.6),
                random.uniform(0.0, 6.28)
            ]
            for _ in range(12)
        ]

    def get_status(self) -> Dict[str, Any]:
        """Determines whether the user is registered/purchased or in trial evaluation."""
        if self.auth_manager:
            try:
                user_info = self.auth_manager.get_current_user()
                is_auth = user_info.get("authenticated", False)
                is_trial = user_info.get("is_trial", True)
                plan = user_info.get("plan_tier", "FREE_EVALUATION")

                if is_auth and not is_trial and plan in ["PRO", "ENTERPRISE", "LIFETIME"]:
                    return {
                        "is_registered": True,
                        "days_left": 999,
                        "title": "System 100% Protected",
                        "short_desc": "Sovereign Pro Active",
                        "badge": "💎 PRO ACTIVE",
                        "cta_text": "🛡️ CONSOLE",
                        "duration_sec": 4.5
                    }
            except Exception:
                pass

        try:
            from src.licensing.client import LicensingClient
            lic_status = LicensingClient().get_entitlement_status()
            plan = (lic_status.get("plan") or "FREE_EVALUATION").upper()
            is_trial = lic_status.get("is_trial", True)
            days_remaining = lic_status.get("days_remaining", 0)

            if not is_trial and plan in ["PRO", "ENTERPRISE", "LIFETIME", "BUSINESS"]:
                return {
                    "is_registered": True,
                    "days_left": days_remaining,
                    "title": "System 100% Protected",
                    "short_desc": "Enterprise Active",
                    "badge": "💎 PRO ACTIVE",
                    "cta_text": "🛡️ CONSOLE",
                    "duration_sec": 4.5
                }

            if days_remaining > 0:
                return {
                    "is_registered": False,
                    "days_left": days_remaining,
                    "title": "XShield Active",
                    "short_desc": f"{days_remaining}d Left • Pro",
                    "badge": f"🛡️ {days_remaining}d Left",
                    "cta_text": "🛡️ CONSOLE",
                    "duration_sec": 5.0
                }
            else:
                return {
                    "is_registered": False,
                    "days_left": 0,
                    "title": "Basic Active",
                    "short_desc": "Standard Shield",
                    "badge": "🛡️ Basic Shield",
                    "cta_text": "UPGRADE ↗",
                    "duration_sec": 5.0
                }
        except Exception:
            pass

        return {
            "is_registered": False,
            "days_left": 14,
            "title": "XShield Active",
            "short_desc": "14d Pro Trial",
            "badge": "🛡️ 14d Remaining",
            "cta_text": "🛡️ CONSOLE",
            "duration_sec": 5.0
        }

    def show(self):
        """Spawns the HUD in a dedicated background UI thread."""
        t = threading.Thread(target=self._run_hud_loop, daemon=True, name="XShield-MeditationHUD")
        t.start()

    def _apply_geometry(self):
        if not self.root:
            return
        w, h = self.WIDTH, self.HEIGHT
        wa_left, wa_top, wa_right, wa_bottom = get_taskbar_work_area()
        pos_x = wa_right - w - 10
        pos_y = wa_bottom - h - 10
        self.root.geometry(f"{w}x{h}+{pos_x}+{pos_y}")

    def _run_hud_loop(self):
        if self.root:
            return

        self.root = tk.Tk()
        self.root.title("XShield Meditation Sentinel")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.0)

        # Transparent window background
        try:
            self.root.attributes("-transparentcolor", "#010409")
        except Exception:
            pass
        self.root.configure(bg="#010409")

        self._apply_geometry()

        self.canvas = tk.Canvas(
            self.root,
            width=self.WIDTH,
            height=self.HEIGHT,
            bg="#010409",
            highlightthickness=0
        )
        self.canvas.pack(fill="both", expand=True)

        def on_enter(e):
            self._hovered = True

        def on_leave(e):
            self._hovered = False
            self._hovered_btn = False
            self._hovered_buy_btn = False
            if self._user_returned_time is not None:
                # Maintain at least 6s grace window after mouse leaves HUD
                self._user_returned_time = max(self._user_returned_time, time.time() - (self._active_dwell_seconds - 6.0))
            if self.canvas:
                try:
                    self.canvas.config(cursor="")
                except Exception:
                    pass

        def on_motion(e):
            status = self.get_status()
            is_reg = status.get("is_registered", False)
            cx = self.WIDTH // 2

            if not is_reg:
                btn_w, btn_h = 138, 38
                btn_x1, btn_x2 = cx - (btn_w // 2), cx + (btn_w // 2)
                btn_y1 = 114
                btn_y2 = btn_y1 + btn_h

                if btn_x1 <= e.x <= btn_x2 and btn_y1 <= e.y <= btn_y2:
                    if not self._hovered_buy_btn:
                        self._hovered_buy_btn = True
                        self._hovered_btn = True
                        self.canvas.config(cursor="hand2")
                elif (14 <= e.y <= 110 and 15 <= e.x <= (self.WIDTH - 15)):
                    if not self._hovered_btn:
                        self._hovered_btn = True
                        self._hovered_buy_btn = False
                        self.canvas.config(cursor="hand2")
                elif e.x >= self.WIDTH - 20 and e.y <= 20:
                    if not self._hovered_btn:
                        self._hovered_btn = True
                        self._hovered_buy_btn = False
                        self.canvas.config(cursor="hand2")
                else:
                    if self._hovered_btn or self._hovered_buy_btn:
                        self._hovered_btn = False
                        self._hovered_buy_btn = False
                        self.canvas.config(cursor="")
            else:
                self._hovered_buy_btn = False
                btn_w, btn_h = 100, 20
                btn_x1, btn_x2 = cx - (btn_w // 2), cx + (btn_w // 2)
                btn_y1 = 126
                btn_y2 = btn_y1 + btn_h

                if (btn_x1 <= e.x <= btn_x2 and btn_y1 <= e.y <= btn_y2) or (14 <= e.y <= 110 and 15 <= e.x <= (self.WIDTH - 15)):
                    if not self._hovered_btn:
                        self._hovered_btn = True
                        self.canvas.config(cursor="hand2")
                elif e.x >= self.WIDTH - 20 and e.y <= 20:
                    if not self._hovered_btn:
                        self._hovered_btn = True
                        self.canvas.config(cursor="hand2")
                else:
                    if self._hovered_btn:
                        self._hovered_btn = False
                        self.canvas.config(cursor="")

        self.root.bind("<Enter>", on_enter)
        self.root.bind("<Leave>", on_leave)
        self.canvas.bind("<Motion>", on_motion)
        self.canvas.bind("<Button-1>", self._on_canvas_click)

        # Fade in greeting
        self._state = "INITIAL"
        self._fade_in_startup()

        # Sentinel loop
        self.root.after(100, self._sentinel_tick)

        try:
            self.root.mainloop()
        except Exception:
            pass

    def _open_local_dashboard(self):
        """Safely launches or focuses the XShield Console / Dashboard."""
        if self.on_open_dashboard:
            try:
                threading.Thread(target=self.on_open_dashboard, daemon=True, name="HUDOpenWorker").start()
                return
            except Exception:
                pass
        try:
            import subprocess
            local_app = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "XSHEILD", "XSHEILD.exe")
            if os.path.isfile(local_app):
                subprocess.Popen([local_app])
            else:
                subprocess.Popen([sys.executable, "-m", "src.ui.app"], cwd=XSHIELD_ROOT)
        except Exception:
            pass

    def _on_canvas_click(self, event):
        # Close button in top-right
        if event.x >= self.WIDTH - 20 and event.y <= 20:
            self._last_dismissed_time = time.time() + 600.0
            self._fade_out_fast()
            return

        status = self.get_status()
        is_reg = status.get("is_registered", False)
        cx = self.WIDTH // 2

        # 1. 3D Animated "Buy Now" Button Click Handler (ONLY when NOT purchased)
        if not is_reg:
            btn_w, btn_h = 138, 38
            btn_x1, btn_x2 = cx - (btn_w // 2), cx + (btn_w // 2)
            btn_y1 = 114
            btn_y2 = btn_y1 + btn_h

            if btn_x1 <= event.x <= btn_x2 and btn_y1 <= event.y <= btn_y2:
                # Direct purchase portal trigger: Opens official pricing & checkout
                try:
                    webbrowser.open("https://futurefinger.github.io/XsheildPublic/#pricing")
                except Exception:
                    pass
                # Also launch local dashboard subscription view so user can enter key or pay
                self._open_local_dashboard()
                self._last_dismissed_time = time.time() + 300.0
                self._fade_out_fast()
                return

        # 2. Click on Meditating Sentinel Body / Console Pill
        if (14 <= event.y <= 110 and 15 <= event.x <= (self.WIDTH - 15)) or (is_reg and 120 <= event.y <= 150):
            self._open_local_dashboard()
            self._last_dismissed_time = time.time() + 300.0
            self._fade_out_fast()
            return

        # Dismiss on general background click
        self._last_dismissed_time = time.time() + 180.0
        self._fade_out_fast()

    def _fade_in_startup(self):
        if not self.root:
            return
        try:
            cur_alpha = self.root.attributes("-alpha")
            if cur_alpha < 0.95:
                self.root.attributes("-alpha", cur_alpha + 0.15)
                self.root.after(20, self._fade_in_startup)
            else:
                # Keep startup greeting on screen for 15 seconds (matches enterprise antivirus behavior)
                self.root.after(int(self._startup_display_seconds * 1000), self._initial_fade_out)
        except Exception:
            pass

    def _initial_fade_out(self):
        if not self.root or self._hovered:
            if self._hovered and self.root:
                self.root.after(2000, self._initial_fade_out)
            return
        try:
            cur_alpha = self.root.attributes("-alpha")
            if cur_alpha > 0.08:
                self.root.attributes("-alpha", cur_alpha - 0.08)
                self.root.after(25, self._initial_fade_out)
            else:
                self.root.attributes("-alpha", 0.0)
                self.root.withdraw()
                self._state = "DISMISSED"
        except Exception:
            self._state = "DISMISSED"

    def _sentinel_tick(self):
        if not self.root:
            return

        idle_sec = get_system_idle_seconds()
        now = time.time()

        if self._state == "DISMISSED":
            if (idle_sec >= self._idle_threshold_seconds) and ((now - self._last_dismissed_time) >= self._idle_cooldown_seconds):
                self._state = "IDLE_ANIMATING"
                self._idle_anim_started_time = now
                self._user_returned_time = None
                self._state_idx = (self._state_idx + 1) % len(MEDITATION_PSYCHOLOGY_STATES)
                try:
                    self.root.deiconify()
                    self.root.attributes("-topmost", True)
                    self.root.attributes("-alpha", 0.0)
                    try:
                        hwnd = self.root.winfo_id()
                        ctypes.windll.user32.ShowWindow(hwnd, 8)
                    except Exception:
                        pass
                except Exception:
                    pass
                self._fade_in_idle()

        elif self._state == "IDLE_ANIMATING":
            # 1. Detect when user returns from idle (mouse moved or key pressed)
            if idle_sec < 1.0:
                if self._user_returned_time is None:
                    # User returned from idle! Start the 18s active interaction window
                    self._user_returned_time = now

            # 2. While user is hovering directly over the HUD, keep it alive indefinitely
            if self._hovered:
                if self._user_returned_time is not None:
                    # Refresh the timer so user has a full window after unhovering
                    self._user_returned_time = now
                self._draw_meditation_frame()
                if self.root:
                    self.root.after(33, self._sentinel_tick)
                return

            # 3. Determine if display duration has completed
            should_dismiss = False
            if self._user_returned_time is not None:
                # User returned from idle: keep visible for at least 18s allowing ample time to click Buy Now
                if (now - self._user_returned_time) >= self._active_dwell_seconds:
                    should_dismiss = True
            elif (now - self._idle_anim_started_time) >= self._max_idle_animation_sec:
                # System was completely idle for full 60s without user touching anything
                should_dismiss = True

            if should_dismiss:
                self._state = "FADING_OUT"
                self._last_dismissed_time = now
                self._user_returned_time = None
                self._fade_out_smooth()
            else:
                self._draw_meditation_frame()

        elif self._state == "INITIAL":
            self._draw_meditation_frame()

        if self.root:
            self.root.after(33, self._sentinel_tick)

    def _fade_in_idle(self):
        if not self.root or self._state != "IDLE_ANIMATING":
            return
        try:
            cur_alpha = self.root.attributes("-alpha")
            if cur_alpha < 0.95:
                self.root.attributes("-alpha", cur_alpha + 0.15)
                self.root.after(20, self._fade_in_idle)
        except Exception:
            pass

    def _fade_out_smooth(self):
        if not self.root:
            return
        # If user hovers during fadeout, cancel fadeout and restore full visibility immediately!
        if self._hovered:
            try:
                self.root.attributes("-alpha", 0.95)
                self._state = "IDLE_ANIMATING"
                self._user_returned_time = time.time()
            except Exception:
                pass
            return
        try:
            cur_alpha = self.root.attributes("-alpha")
            if cur_alpha > 0.08:
                self.root.attributes("-alpha", cur_alpha - 0.08)
                self.root.after(25, self._fade_out_smooth)
            else:
                self.root.attributes("-alpha", 0.0)
                self.root.withdraw()
                self._state = "DISMISSED"
                self._user_returned_time = None
        except Exception:
            self._state = "DISMISSED"
            self._user_returned_time = None

    def _fade_out_fast(self):
        self._fade_out_smooth()

    # -------------------------------------------------------------------------
    # Ultra-Compact 116x110 Meditation Human Form, 3D/4D/5D Sacred Geometry
    # -------------------------------------------------------------------------

    def _draw_meditation_frame(self):
        if not self.canvas:
            return

        self.canvas.delete("all")
        self._anim_timer += 0.04
        self._state_cycle_timer += 0.04
        t = self._anim_timer

        # Cycle state every 10 seconds
        if self._state_cycle_timer > 10.0:
            self._state_cycle_timer = 0.0
            self._state_idx = (self._state_idx + 1) % len(MEDITATION_PSYCHOLOGY_STATES)

        cur_state = MEDITATION_PSYCHOLOGY_STATES[self._state_idx]
        status = self.get_status()

        # Center coordinates with gentle vertical prana float
        cx = self.WIDTH // 2  # 76
        float_y = 1.2 * math.sin(t * 1.5)
        cy = (self.HEIGHT // 2) - 22 + float_y  # 59 + float_y

        primary = cur_state["primary_color"]
        secondary = cur_state["secondary_color"]
        aura_hue = cur_state["aura_hue"]

        # ---------------------------------------------------------------------
        # 1. Outer Ethereal Sacred Aura (4D/5D Rainbow Halo Fields)
        # ---------------------------------------------------------------------
        for layer in (2, 1):
            r_x = 36 + layer * 6 + math.sin(t * 2.0 + layer) * 2.0
            r_y = 33 + layer * 5 + math.sin(t * 2.0 + layer) * 2.0
            self.canvas.create_oval(
                cx - r_x, cy - r_y,
                cx + r_x, cy + r_y,
                outline=aura_hue if layer == 1 else primary,
                width=1.0,
                dash=(2, 2) if layer == 2 else None
            )

        # ---------------------------------------------------------------------
        # 2. 3D/4D Orbiting Gyroscope Rings (Merkaba Field)
        # ---------------------------------------------------------------------
        for tilt_angle, speed, orbit_r, col in [(0.4, 1.2, 42, primary), (-0.45, -1.0, 48, aura_hue)]:
            pts_ring = []
            steps = 20
            for s in range(steps + 1):
                ang = (s / steps) * 2.0 * math.pi + (t * speed)
                rx = cx + orbit_r * math.cos(ang)
                ry = cy + (orbit_r * 0.40 * math.sin(ang)) * math.cos(tilt_angle) + (orbit_r * 0.16 * math.sin(ang))
                pts_ring.extend([rx, ry])
            self.canvas.create_line(pts_ring, fill=col, width=1.0, dash=(3, 2))

            # Orbiting energy bead
            ang_bead = t * speed * 1.6
            bx = cx + orbit_r * math.cos(ang_bead)
            by = cy + (orbit_r * 0.40 * math.sin(ang_bead)) * math.cos(tilt_angle) + (orbit_r * 0.16 * math.sin(ang_bead))
            self.canvas.create_oval(bx - 1.5, by - 1.5, bx + 1.5, by + 1.5, fill="#ffffff", outline=col)

        # ---------------------------------------------------------------------
        # 3. Rising Prana Sparkles & Quantum Energy Particles
        # ---------------------------------------------------------------------
        for p in self._particles:
            p[1] -= p[2]  # Rise upward
            if p[1] < (cy - 45):
                p[1] = cy + 40 + random.uniform(0, 10)
                p[0] = random.uniform(-30, 30)

            px = cx + p[0] + 2.5 * math.sin(t * 2.0 + p[4])
            py = p[1]
            p_sz = p[3]
            p_color = primary if (p[4] < 2.0) else (secondary if p[4] < 4.5 else "#ffffff")
            self.canvas.create_oval(px - p_sz, py - p_sz, px + p_sz, py + p_sz, fill=p_color, outline="")

        # ---------------------------------------------------------------------
        # 4. Sacred Blossoming Lotus Pedestal (Padma Throne)
        # ---------------------------------------------------------------------
        base_y = cy + 28
        for i, (dx, dy, w_p, h_p) in enumerate([(-24, 0, 16, 7), (24, 0, 16, 7), (-12, 3, 14, 8), (12, 3, 14, 8), (0, 5, 18, 9)]):
            col_p = secondary if i % 2 == 0 else primary
            self.canvas.create_oval(
                cx + dx - w_p // 2, base_y + dy - h_p // 2,
                cx + dx + w_p // 2, base_y + dy + h_p // 2,
                fill="#061328", outline=col_p, width=1.0
            )

        # ---------------------------------------------------------------------
        # 5. Meditating Human Form Silhouette (Padmasana Lotus Pose) - Ultra-Smooth
        # ---------------------------------------------------------------------
        head_y = cy - 28

        # Ethereal Head Halo
        self.canvas.create_oval(cx - 10, head_y - 8, cx + 10, head_y + 12, outline=aura_hue, width=1.0, dash=(2, 1))

        # Sacred Head (Conscious Mind)
        self.canvas.create_oval(cx - 5.5, head_y - 2, cx + 5.5, head_y + 9, fill="#091833", outline=primary, width=1.2)

        # Torso & Shoulders (Sacred Geometry Padmasana)
        body_pts = [
            cx, head_y + 9,
            cx + 6, head_y + 11,
            cx + 15, head_y + 15,
            cx + 17, head_y + 24,
            cx + 11, head_y + 32,
            cx + 22, head_y + 36,
            cx + 20, head_y + 40,
            cx + 10, head_y + 42,
            cx, head_y + 43,
            cx - 10, head_y + 42,
            cx - 20, head_y + 40,
            cx - 22, head_y + 36,
            cx - 11, head_y + 32,
            cx - 17, head_y + 24,
            cx - 15, head_y + 15,
            cx - 6, head_y + 11
        ]
        self.canvas.create_polygon(body_pts, fill="#07142a", outline=secondary, width=1.2, smooth=True)

        # Crossed Lap & Dhyana Mudra (Meditating Hands)
        self.canvas.create_oval(cx - 18, head_y + 34, cx + 18, head_y + 43, fill="#050d1a", outline=primary, width=1.0)
        self.canvas.create_oval(cx - 4, head_y + 33, cx + 4, head_y + 37, fill="#00f59b", outline="#ffffff", width=0.5)

        # ---------------------------------------------------------------------
        # 6. 7 Luminous Chakras along the Spinal Energy Axis (Sushumna)
        # ---------------------------------------------------------------------
        chakras = [
            (head_y - 3, "#c084fc"),  # Sahasrara (Crown)
            (head_y + 3, "#818cf8"),  # Ajna (Third Eye)
            (head_y + 11, "#00f0ff"), # Vishuddha (Throat)
            (head_y + 19, "#10b981"), # Anahata (Heart)
            (head_y + 26, "#fbbf24"), # Manipura (Solar)
            (head_y + 32, "#fb923c"), # Svadhisthana (Sacral)
            (head_y + 38, "#f43f5e"), # Muladhara (Root)
        ]
        # Sushumna spine light line
        self.canvas.create_line(cx, head_y - 3, cx, head_y + 39, fill="#1e3a8a", width=1.0, dash=(1, 2))

        for c_y, c_col in chakras:
            pulse = 1.0 + 0.4 * math.sin(t * 3.0 + c_y * 0.1)
            self.canvas.create_oval(cx - pulse * 1.5, c_y - pulse * 1.5, cx + pulse * 1.5, c_y + pulse * 1.5, fill=c_col, outline="#ffffff", width=0.5)

        # ---------------------------------------------------------------------
        # 7. Action Pill: 3D Animated "Buy Now — Unlock Full Security" OR Clean Pro Active
        # ---------------------------------------------------------------------
        is_reg = status.get("is_registered", False)

        if not is_reg:
            # ANTIVIRUS NOT PURCHASED: Render Prominent 3D Animated "Buy Now" Button
            btn_w, btn_h = 138, 38
            btn_x1, btn_x2 = cx - (btn_w // 2), cx + (btn_w // 2)
            btn_y1 = 114
            btn_y2 = btn_y1 + btn_h

            # Dynamic 3D depth and hover elevation
            y_offset = -2 if self._hovered_buy_btn else 0

            # 3D Base Drop Shadow / Bottom Extrusion
            self.canvas.create_rectangle(
                btn_x1 + 1, btn_y1 + 4, btn_x2 - 1, btn_y2 + 4,
                fill="#010610", outline="#01040a", width=1.0
            )
            # 3D Mid Extrusion Layer
            self.canvas.create_rectangle(
                btn_x1, btn_y1 + 2, btn_x2, btn_y2 + 2,
                fill="#051f38", outline="#072d52", width=1.0
            )

            # 3D Front Face with Luminous Cyber Gradient
            face_fill = "#0284c7" if self._hovered_buy_btn else "#082544"
            border_col = "#fbbf24" if self._hovered_buy_btn else (
                "#00f0ff" if (int(t * 3) % 2 == 0) else "#38bdf8"
            )
            border_w = 2.0 if self._hovered_buy_btn else 1.5

            self.canvas.create_rectangle(
                btn_x1, btn_y1 + y_offset, btn_x2, btn_y2 + y_offset,
                fill=face_fill, outline=border_col, width=border_w
            )

            # Animated Shimmer / Light Beam across the 3D button face
            beam_rel = (t * 60.0) % (btn_w + 50) - 25
            beam_x = btn_x1 + beam_rel
            if btn_x1 <= beam_x <= btn_x2:
                self.canvas.create_line(
                    beam_x - 5, btn_y2 + y_offset - 1,
                    beam_x + 5, btn_y1 + y_offset + 1,
                    fill="#ffffff", width=2.0
                )

            # Luminous 3D Text: Line 1 (💎 BUY NOW) & Line 2 (⚡ UNLOCK FULL SECURITY)
            self.canvas.create_text(
                cx, btn_y1 + 12 + y_offset,
                text="💎 BUY NOW",
                font=("Segoe UI", 10, "bold"),
                fill="#ffffff"
            )
            self.canvas.create_text(
                cx, btn_y1 + 27 + y_offset,
                text="⚡ UNLOCK FULL SECURITY",
                font=("Segoe UI", 7, "bold"),
                fill="#fbbf24" if not self._hovered_buy_btn else "#ffffff"
            )

        else:
            # ANTIVIRUS ALREADY PURCHASED: DO NOT SHOW "Buy Now" Button!
            # Instead render subtle non-commercial status pill
            btn_w, btn_h = 100, 20
            btn_x1, btn_x2 = cx - (btn_w // 2), cx + (btn_w // 2)
            btn_y1 = 126
            btn_y2 = btn_y1 + btn_h

            if self._hovered_btn:
                self.canvas.create_rectangle(btn_x1, btn_y1, btn_x2, btn_y2, fill="#0d2b52", outline="#00f0ff", width=1.0)
                self.canvas.create_text(cx, btn_y1 + (btn_h // 2), text="🛡️ OPEN CONSOLE", font=("Segoe UI", 7, "bold"), fill="#ffffff")
            else:
                self.canvas.create_rectangle(btn_x1, btn_y1, btn_x2, btn_y2, fill="#050e1f", outline=secondary, width=1.0)
                self.canvas.create_text(cx, btn_y1 + (btn_h // 2), text=status.get("badge", "💎 PRO ACTIVE"), font=("Segoe UI", 7, "bold"), fill="#34d399")
                self.canvas.create_text(cx, btn_y1 + (btn_h // 2), text="💎 PRO ACTIVE", font=("Segoe UI", 6, "bold"), fill="#34d399")

        # Celestial Close Icon ✕ (Top Right Aura)
        self.canvas.create_text(
            self.WIDTH - 12, 10,
            text="✕",
            font=("Segoe UI", 7, "bold"),
            fill="#ffffff" if self._hovered_btn else "#64748b"
        )


_CURRENT_HUD_INSTANCE: Optional[XShieldTrayHUD] = None


def show_tray_hud(auth_manager=None, on_open_dashboard=None):
    """Module-level entry point to launch the Meditation Sentinel HUD and idle monitor."""
    global _CURRENT_HUD_INSTANCE
    if _CURRENT_HUD_INSTANCE is None:
        _CURRENT_HUD_INSTANCE = XShieldTrayHUD(auth_manager=auth_manager, on_open_dashboard=on_open_dashboard)
        _CURRENT_HUD_INSTANCE.show()
    return _CURRENT_HUD_INSTANCE


def trigger_hud_on_demand():
    """Explicitly trigger the Meditation HUD on demand from the tray menu."""
    global _CURRENT_HUD_INSTANCE
    if _CURRENT_HUD_INSTANCE and _CURRENT_HUD_INSTANCE.root:
        try:
            _CURRENT_HUD_INSTANCE._state = "IDLE_ANIMATING"
            _CURRENT_HUD_INSTANCE._state_idx = (_CURRENT_HUD_INSTANCE._state_idx + 1) % len(MEDITATION_PSYCHOLOGY_STATES)
            _CURRENT_HUD_INSTANCE.root.deiconify()
            _CURRENT_HUD_INSTANCE._fade_in_idle()
        except Exception:
            pass


if __name__ == "__main__":
    print("Launching XShield Meditation Sentinel Matrix (50% Compact Edition)...")
    hud = show_tray_hud()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("XShield Meditation Sentinel terminated.")
