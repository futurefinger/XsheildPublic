"""
XSHEILD System Tray Integration (Hardened Edition)
Owner: Future Finger Technologies
Windows Notification Area integration with quick-access security actions,
status monitoring, and non-intrusive background operation.
"""

import os
import sys
import threading
import tempfile
import contextlib
import time
from typing import Optional, Callable
from PIL import Image, ImageDraw
import pystray

# Windows 11 Shell Lock Hardening:
# Prevent WinError 32 when Windows Shell holds temporary tray .ico handles open
try:
    import pystray._util
    @contextlib.contextmanager
    def _safe_serialized_image(image, format, extension=None):
        fd, path = tempfile.mkstemp('.%s' % (extension or format.lower()))
        try:
            with os.fdopen(fd, 'wb') as f:
                image.save(f, format=format)
            yield path
        finally:
            def _async_cleanup(p):
                for _ in range(30):
                    try:
                        if os.path.exists(p):
                            os.unlink(p)
                        break
                    except Exception:
                        time.sleep(0.15)
            threading.Thread(target=_async_cleanup, args=(path,), daemon=True).start()

    pystray._util.serialized_image = _safe_serialized_image
    if hasattr(pystray, "_win32"):
        pystray._win32.serialized_image = _safe_serialized_image
except Exception:
    pass

from src.core.logger import get_logger
from src.core.notifications import gaming_mode_manager
from src.core.audio import sound_engine
from src.core.startup import is_windows_startup_enabled, enable_windows_startup, disable_windows_startup

logger = get_logger("ui.tray")


def _resolve_resource_dir() -> str:
    """Resolves root directory across development and PyInstaller frozen modes."""
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        candidates = [
            getattr(sys, "_MEIPASS", ""),
            os.path.join(exe_dir, "_internal"),
            exe_dir,
        ]
        for candidate in candidates:
            if candidate and os.path.exists(os.path.join(candidate, "assets", "branding", "tray_icon.png")):
                return candidate
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def get_tray_icon_image() -> Image.Image:
    """Finds and loads the high-contrast 32x32 / 16x16 system tray icon."""
    candidates = []
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        candidates.extend([
            os.path.join(getattr(sys, "_MEIPASS", ""), "assets", "branding", "tray_icon.png"),
            os.path.join(exe_dir, "assets", "branding", "tray_icon.png"),
            os.path.join(exe_dir, "_internal", "assets", "branding", "tray_icon.png"),
            os.path.join(exe_dir, "tray_icon.png"),
        ])

    dev_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidates.extend([
        os.path.join(dev_root, "assets", "branding", "tray_icon.png"),
        os.path.join(dev_root, "assets", "branding", "favicon.png"),
    ])

    for p in candidates:
        if p and os.path.isfile(p):
            try:
                img = Image.open(p)
                if img.mode != "RGBA":
                    img = img.convert("RGBA")
                return img
            except Exception as e:
                logger.warning(f"Error opening tray icon from {p}: {e}")

    logger.info("Using high-contrast procedural cyber shield for system tray.")
    return _generate_fallback_icon()


def _generate_fallback_icon() -> Image.Image:
    """Generates an ultra-crisp high-contrast 32x32 cyber-shield icon if asset file is missing."""
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # High-contrast electric cyan shield with pure white core
    shield_pts = [(16, 2), (28, 7), (27, 18), (16, 29), (5, 18), (4, 7)]
    draw.polygon(shield_pts, fill=(10, 28, 65, 255), outline=(0, 240, 255, 255), width=2)

    # Inner rich blue facet
    inner_pts = [(16, 5), (25, 9), (24, 17), (16, 26), (8, 17), (7, 9)]
    draw.polygon(inner_pts, fill=(14, 42, 92, 255), outline=(0, 180, 255, 200), width=1)

    # Bold "X" Crest
    draw.line([(10, 10), (22, 22)], fill=(0, 240, 255, 255), width=2)
    draw.line([(22, 10), (10, 22)], fill=(255, 255, 255, 255), width=2)
    draw.rectangle([(14, 14), (18, 18)], fill=(255, 255, 255, 255), outline=(0, 240, 255, 255))
    return img


def promote_tray_icon_in_windows_shell(exe_path: Optional[str] = None) -> bool:
    """
    On Windows 11/10, promotes the XSHEILD tray icon from the hidden overflow menu
    directly to the visible Taskbar Notification Area (next to clock).
    """
    if sys.platform != "win32":
        return False

    import winreg
    target_exe = (exe_path or sys.executable).lower()
    base_key_path = r"Control Panel\NotifyIconSettings"

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, base_key_path, 0, winreg.KEY_READ) as base_key:
            num_subkeys = winreg.QueryInfoKey(base_key)[0]
            for i in range(num_subkeys):
                try:
                    sub_name = winreg.EnumKey(base_key, i)
                    sub_path = f"{base_key_path}\\{sub_name}"
                    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub_path, 0, winreg.KEY_READ | winreg.KEY_WRITE) as sub_key:
                        try:
                            val, _ = winreg.QueryValueEx(sub_key, "ExecutablePath")
                            if val and ("xsheild" in val.lower() or val.lower() == target_exe):
                                winreg.SetValueEx(sub_key, "IsPromoted", 0, winreg.REG_DWORD, 1)
                                logger.info(f"Promoted tray icon to visible taskbar: {sub_path}")
                        except FileNotFoundError:
                            pass
                except Exception:
                    continue
        return True
    except Exception as e:
        logger.debug(f"Tray icon promotion check notice: {e}")
        return False


class XSheildTray:
    def __init__(
        self,
        on_open_callback: Optional[Callable[[], None]] = None,
        on_scan_callback: Optional[Callable[[], None]] = None,
        on_exit_callback: Optional[Callable[[], None]] = None
    ):
        self.on_open = on_open_callback
        self.on_scan = on_scan_callback
        self.on_exit = on_exit_callback
        self.icon = None

    def _is_gaming_active(self, item) -> bool:
        return gaming_mode_manager.is_active

    def _on_toggle_gaming(self, icon, item):
        new_state = gaming_mode_manager.toggle()
        logger.info(f"Tray: Gaming / Silent Mode set to {new_state}")

    def _is_sound_active(self, item) -> bool:
        return sound_engine.is_enabled

    def _on_toggle_sound(self, icon, item):
        new_state = sound_engine.toggle()
        logger.info(f"Tray: Cyber Audio Alerts set to {new_state}")

    def _is_startup_active(self, item) -> bool:
        return is_windows_startup_enabled()

    def _on_toggle_startup(self, icon, item):
        if is_windows_startup_enabled():
            disable_windows_startup()
            logger.info("Tray: Windows startup disabled.")
        else:
            enable_windows_startup(with_splash=True)
            logger.info("Tray: Windows startup enabled.")

    def _on_check_updates(self, icon, item):
        logger.info("Tray: Check updates requested.")
        try:
            from src.core.threat_updater import threat_intel_manager
            threat_intel_manager.poll_definitions_update()
            sound_engine.play_system_safe()
            if self.icon:
                try:
                    self.icon.notify(
                        "Threat definitions are up-to-date (Version 2026.11.07). All 14 surveillance shields active.",
                        "XSHEILD Update Center"
                    )
                except Exception:
                    pass
            try:
                from src.core.notifications import notification_service
                notification_service.show_notification(
                    title="XSHEILD Update Center",
                    message="Threat definitions are up-to-date (Version 2026.11.07). All 14 kernel surveillance shields active.",
                    urgency="normal"
                )
            except Exception:
                pass
            if self.on_open:
                self.on_open()
        except Exception as e:
            logger.warning(f"Error checking definitions from tray: {e}")

    def _create_menu(self):
        return pystray.Menu(
            pystray.MenuItem("🛡️ XSHEILD — AI Sentinel Active", lambda: None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Open Dashboard", self._on_open_clicked, default=True),
            pystray.MenuItem("Run Quick Scan", self._on_scan_clicked),
            pystray.MenuItem("Show Meditation Sentinel HUD", self._on_show_hud_clicked),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Gaming / Silent Mode", self._on_toggle_gaming, checked=self._is_gaming_active),
            pystray.MenuItem("Cyber Audio Alerts", self._on_toggle_sound, checked=self._is_sound_active),
            pystray.MenuItem("Start with Windows", self._on_toggle_startup, checked=self._is_startup_active),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Check for Updates", self._on_check_updates),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Exit XSHEILD", self._on_exit_clicked)
        )

    def _on_show_hud_clicked(self, icon, item):
        logger.info("Tray menu: 'Show 3D Security HUD' requested by user.")
        try:
            from src.ui.xshield_tray_hud import trigger_hud_on_demand
            trigger_hud_on_demand()
        except Exception as e:
            logger.debug(f"HUD on demand trigger error: {e}")

    def _on_open_clicked(self, icon, item):
        logger.info("Tray menu: 'Open Dashboard' requested.")
        if self.on_open:
            threading.Thread(target=self.on_open, daemon=True, name="TrayOpenWorker").start()

    def _on_scan_clicked(self, icon, item):
        logger.info("Tray menu: 'Run Quick Scan' requested.")
        if self.on_scan:
            threading.Thread(target=self.on_scan, daemon=True, name="TrayScanWorker").start()

    def _on_exit_clicked(self, icon, item):
        logger.info("Tray menu: 'Exit XSHEILD' initiated by user.")
        self.stop()
        if self.on_exit:
            self.on_exit()
        else:
            os._exit(0)

    def start(self, daemon: bool = False):
        try:
            image = get_tray_icon_image()

            self.icon = pystray.Icon(
                "XSHEILD",
                image,
                "XSHEILD — AI Sentinel Active (Protected)",
                menu=self._create_menu()
            )
            # Use pystray's built-in run_detached for Windows notification area integration
            self.icon.run_detached()

            # Launch Non-Intrusive 3D Cyber HUD Toast above system tray
            try:
                from src.ui.xshield_tray_hud import show_tray_hud
                threading.Thread(target=show_tray_hud, kwargs={'on_open_dashboard': self.on_open}, daemon=True).start()
            except Exception as e:
                logger.debug(f'XShield Cyber HUD startup notice: {e}')

            # Ensure Windows 11 taskbar promotes the icon to the main visible tray area
            threading.Thread(target=promote_tray_icon_in_windows_shell, daemon=True).start()

            logger.info("XSHEILD notification area system tray icon active.")
            return True
        except Exception as e:
            logger.error(f"Failed to start system tray icon: {e}")
            return None

    def stop(self):
        if self.icon:
            try:
                self.icon.stop()
            except Exception:
                pass
            self.icon = None
