"""
XSHEILD Autonomous AI Marketing & Growth Intelligence System
Publisher: Future Finger Technologies (futurefingerindia@gmail.com)

Contains enterprise multi-agent marketing subsystems:
- Outclaw: 21 specialized marketing team agents
- Loopmark: Marketing automation, email campaigns, social lead funnels
- UnifAPI: Deep SEO audits, GEO/AEO visibility, competitive intelligence
- AIMarketingSkills: Growth experimentation & sales pipeline automation
- MarketingAgentOS: 238-skill comprehensive marketing execution engine
- MeshPilotSocial: Multi-brand social content & video prompt workflows
- MarketingMCP: Standardized Model Context Protocol connectors for Google Ads, Meta, SEO, HubSpot, and CRO
"""

from src.marketing.orchestrator import marketing_orchestrator
from src.marketing.ai_sales_team import ai_sales_engine

__all__ = ["marketing_orchestrator", "ai_sales_engine"]
