"""
XSHEILD Super Admin Portal Authentication Module
Publisher: Future Finger Technologies
Provides sovereign administrative authorization and recovery keys.
"""

OWNER_CREDENTIALS = {
    "identities": [
        "futurefingerindia@gmail.com",
        "admin@futurefinger.com",
        "jitender.city@gmail.com"
    ],
    "passkeys": [
        "FFT@Owner#2026",
        "777888"
    ]
}
