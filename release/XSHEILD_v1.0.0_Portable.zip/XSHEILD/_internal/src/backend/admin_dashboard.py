"""
XSHEILD Central Enterprise & B2B Device Management Console
Owner: Future Finger Technologies

Provides endpoints and HTML dashboard for IT administrators managing multi-seat Business subscriptions.
Allows monitoring fleet health, viewing quarantined assets, and queuing remote scans.
"""

import time
import uuid
from typing import Dict, Any, List
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import HTMLResponse

router = APIRouter(prefix="/api/v1/enterprise", tags=["Enterprise B2B"])

# In-memory fleet registry (in production backed by PostgreSQL / SQLite)
FLEET_REGISTRY: Dict[str, Dict[str, Any]] = {
    "dev_win11_alpha": {
        "device_id": "dev_win11_alpha",
        "hostname": "CORP-FINANCE-01",
        "os_version": "Windows 11 Pro 64-bit",
        "ip_address": "192.168.1.105",
        "client_version": "1.0.0",
        "signature_version": "2026.10.31",
        "health_status": "SECURE",
        "last_seen": int(time.time()),
        "pending_actions": []
    },
    "dev_win10_beta": {
        "device_id": "dev_win10_beta",
        "hostname": "CORP-EXEC-02",
        "os_version": "Windows 10 Enterprise",
        "ip_address": "192.168.1.112",
        "client_version": "1.0.0",
        "signature_version": "2026.10.31",
        "health_status": "SECURE",
        "last_seen": int(time.time()) - 120,
        "pending_actions": []
    }
}


class RemoteScanRequest(BaseModel):
    device_id: str
    scan_type: str = "QUICK"  # "QUICK" or "FULL"


@router.get("/devices")
def list_fleet_devices():
    """Lists all active endpoints under the business account."""
    devices = list(FLEET_REGISTRY.values())
    return {
        "total_seats_allocated": 25,
        "active_devices_count": len(devices),
        "available_seats": 25 - len(devices),
        "devices": devices
    }


@router.post("/scan-request")
def queue_remote_scan(req: RemoteScanRequest):
    """Queues a remote scan request for the specified endpoint."""
    device = FLEET_REGISTRY.get(req.device_id)
    if not device:
        raise HTTPException(status_code=404, detail=f"Device not registered: {req.device_id}")

    task_id = f"scan_task_{uuid.uuid4().hex[:8]}"
    action = {
        "task_id": task_id,
        "action": "TRIGGER_SCAN",
        "scan_type": req.scan_type,
        "queued_at": int(time.time()),
        "status": "QUEUED"
    }
    device["pending_actions"].append(action)
    return {
        "success": True,
        "task_id": task_id,
        "device_id": req.device_id,
        "message": f"Remote {req.scan_type} scan queued for {device['hostname']}."
    }


@router.get("/telemetry-summary")
def get_fleet_telemetry():
    """Aggregates security telemetry across all endpoints."""
    return {
        "fleet_size": len(FLEET_REGISTRY),
        "endpoints_up_to_date": len(FLEET_REGISTRY),
        "threats_intercepted_24h": 0,
        "quarantined_items_active": 0,
        "overall_fleet_posture": "OPTIMAL",
        "publisher": "Future Finger Technologies"
    }


ADMIN_DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>XSHEILD Central Enterprise Console — Future Finger Technologies</title>
  <style>
    body { background: #070C1D; color: #F8FAFC; font-family: -apple-system, sans-serif; padding: 32px; }
    h1 { color: #00F0FF; margin-bottom: 8px; }
    .card { background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(0, 240, 255, 0.2); border-radius: 12px; padding: 24px; margin-bottom: 24px; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    th, td { padding: 12px 16px; text-align: left; border-bottom: 1px solid rgba(255, 255, 255, 0.08); }
    th { color: #00F0FF; font-size: 0.85rem; text-transform: uppercase; }
    .btn { background: #00F0FF; color: #070C1D; border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-weight: 700; }
    .badge { padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; background: rgba(16, 185, 129, 0.15); color: #10B981; }
  </style>
</head>
<body>
  <h1>XSHEILD Central Enterprise Console</h1>
  <p style="color: #94A3B8; margin-bottom: 24px;">Future Finger Technologies — Multi-Seat Business Endpoint Fleet</p>
  
  <div class="card">
    <div style="display: flex; gap: 32px;">
      <div><span style="color:#94A3B8">Total Fleet Seats:</span> <strong>25 Devices</strong></div>
      <div><span style="color:#94A3B8">Active Endpoints:</span> <strong style="color:#00F0FF">2 Connected</strong></div>
      <div><span style="color:#94A3B8">Fleet Status:</span> <span class="badge">100% HEALTHY</span></div>
    </div>
  </div>

  <div class="card">
    <h3>Registered Company Endpoints</h3>
    <table>
      <thead>
        <tr>
          <th>Hostname</th>
          <th>Device ID</th>
          <th>OS Version</th>
          <th>Signatures</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>CORP-FINANCE-01</strong></td>
          <td><code>dev_win11_alpha</code></td>
          <td>Windows 11 Pro</td>
          <td>2026.10.31 (Synchronized)</td>
          <td><span class="badge">SECURE</span></td>
          <td><button class="btn" onclick="alert('Remote quick scan requested for CORP-FINANCE-01!')">Trigger Quick Scan</button></td>
        </tr>
        <tr>
          <td><strong>CORP-EXEC-02</strong></td>
          <td><code>dev_win10_beta</code></td>
          <td>Windows 10 Enterprise</td>
          <td>2026.10.31 (Synchronized)</td>
          <td><span class="badge">SECURE</span></td>
          <td><button class="btn" onclick="alert('Remote quick scan requested for CORP-EXEC-02!')">Trigger Quick Scan</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</body>
</html>
"""


@router.get("/dashboard", response_class=HTMLResponse)
def render_admin_dashboard():
    """Renders visual HTML central console for enterprise fleet administrators."""
    return HTMLResponse(content=ADMIN_DASHBOARD_HTML, status_code=200)
