"""
XSHEILD Cloud Telemetry Hub & Fleet Command Gateway
Owner: Future Finger Technologies
Exclusive Legal Jurisdiction: New Delhi, Delhi, India
Official Destination: futurefingerindia@gmail.com

Cloud-deployable centralized REST API gateway for:
- Endpoint telemetry heartbeats & device registration (UUIDv4 installation_id)
- Enterprise device fleet management, remote scan, isolation, and rollback
- Cryptographic software update distribution & staged rollout policies
- Legal consent storage & email alerting
- Zero-day threat feed distribution
- Sandbox sample submission
- Multi-tenant enterprise fleet management
"""

import os
import sys
import time
import json
import uuid
import hmac
import hashlib
import sqlite3
import threading
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone, timedelta
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [XSHEILD-CLOUD] %(message)s")
logger = logging.getLogger("xsheild.cloud_telemetry_hub")

DB_PATH = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "XSHEILD", "cloud_telemetry.db")
SERVER_TOKEN = os.environ.get("XSHEILD_CLOUD_TOKEN", "FFT_CLOUD_GATEWAY_TOKEN_2026")
OWNER_EMAIL = "futurefingerindia@gmail.com"
CURRENT_STABLE_VERSION = "1.0.0"


class CloudTelemetryDatabase:
    """Thread-safe SQLite storage for the cloud gateway and fleet management."""
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self._init_schema()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        with self._lock, self._get_connection() as conn:
            # Endpoints (legacy & backward-compatible)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS endpoints (
                    hwid TEXT PRIMARY KEY,
                    user_email TEXT,
                    user_name TEXT,
                    organization TEXT,
                    os_version TEXT,
                    agent_version TEXT,
                    status TEXT,
                    threats_blocked INTEGER DEFAULT 0,
                    last_heartbeat TEXT,
                    registered_at TEXT
                )
            """)

            # Device Installations (Centralized Super Admin Device Tracking)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS device_installations (
                    installation_id TEXT PRIMARY KEY,
                    hwid TEXT NOT NULL,
                    device_name TEXT,
                    user_email TEXT,
                    user_name TEXT,
                    organization TEXT,
                    os_version TEXT,
                    installed_version TEXT,
                    latest_version TEXT,
                    channel TEXT DEFAULT 'stable',
                    license_id TEXT,
                    license_status TEXT DEFAULT 'TRIAL',
                    license_plan TEXT DEFAULT 'FREE',
                    protection_status TEXT DEFAULT 'PROTECTED',
                    engine_health TEXT DEFAULT 'HEALTHY',
                    threats_blocked INTEGER DEFAULT 0,
                    update_status TEXT DEFAULT 'UP_TO_DATE',
                    last_update_check TEXT,
                    last_sync TEXT,
                    registered_at TEXT,
                    status TEXT DEFAULT 'ONLINE',
                    is_isolated INTEGER DEFAULT 0,
                    is_revoked INTEGER DEFAULT 0,
                    diagnostic_logs TEXT,
                    pending_action TEXT DEFAULT 'NONE'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_dev_hwid ON device_installations(hwid)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_dev_email ON device_installations(user_email)")

            # Software Releases & Staged Rollouts
            conn.execute("""
                CREATE TABLE IF NOT EXISTS software_releases (
                    version TEXT PRIMARY KEY,
                    channel TEXT DEFAULT 'stable',
                    tag_name TEXT,
                    release_notes TEXT,
                    published_at TEXT,
                    installer_url TEXT,
                    portable_url TEXT,
                    manifest_url TEXT,
                    sha256 TEXT,
                    staged_rollout_percent INTEGER DEFAULT 100,
                    is_paused INTEGER DEFAULT 0,
                    min_supported_version TEXT DEFAULT '1.0.0'
                )
            """)

            # Device Sync & Audit Events
            conn.execute("""
                CREATE TABLE IF NOT EXISTS device_sync_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    installation_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    details TEXT,
                    timestamp TEXT
                )
            """)

            # Legal Consents
            conn.execute("""
                CREATE TABLE IF NOT EXISTS legal_consents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hwid TEXT,
                    user_email TEXT,
                    user_name TEXT,
                    jurisdiction TEXT,
                    timestamp TEXT,
                    dispatched_to_owner INTEGER DEFAULT 0
                )
            """)

            # Threat Incidents
            conn.execute("""
                CREATE TABLE IF NOT EXISTS threat_incidents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hwid TEXT,
                    threat_name TEXT,
                    threat_type TEXT,
                    file_path TEXT,
                    file_hash TEXT,
                    action_taken TEXT,
                    timestamp TEXT
                )
            """)

            # Sandbox Submissions
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sandbox_submissions (
                    submission_id TEXT PRIMARY KEY,
                    hwid TEXT,
                    file_hash TEXT,
                    file_name TEXT,
                    threat_score INTEGER,
                    verdict TEXT,
                    details TEXT,
                    submitted_at TEXT
                )
            """)

            # Seed default v1.0.0 release if empty
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM software_releases")
            if cur.fetchone()[0] == 0:
                now_str = datetime.now(timezone.utc).isoformat()
                conn.execute("""
                    INSERT INTO software_releases (
                        version, channel, tag_name, release_notes, published_at,
                        installer_url, portable_url, manifest_url, sha256, staged_rollout_percent, is_paused
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    "1.0.0",
                    "stable",
                    "v1.0.0",
                    "Initial Commercial Launch: XSHEILD Next-Gen Antivirus by Future Finger Technologies. Complete real-time shield, Ed25519 licensing, and Delhi jurisdiction onboarding.",
                    now_str,
                    "https://github.com/futurefinger/XSHEILD/releases/download/v1.0.0/XSHEILD_Setup.exe",
                    "https://github.com/futurefinger/XSHEILD/releases/download/v1.0.0/XSHEILD_Portable.zip",
                    "https://raw.githubusercontent.com/futurefinger/XSHEILD/main/releases/update-manifest.json",
                    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                    100,
                    0
                ))
            conn.commit()

    # --- Device Registration & Telemetry ---
    def register_or_update_device(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Registers a new endpoint installation or updates existing registration."""
        inst_id = str(data.get("installation_id") or "").strip()
        if not inst_id:
            inst_id = str(uuid.uuid4())

        hwid = str(data.get("hwid") or "UNKNOWN_HWID").strip()
        device_name = str(data.get("device_name") or os.environ.get("COMPUTERNAME", "DESKTOP-ENDPOINT")).strip()
        user_email = str(data.get("user_email") or "customer@example.com").strip().lower()
        user_name = str(data.get("user_name") or "Authorized User").strip()
        org = str(data.get("organization") or "Default Enterprise").strip()
        os_ver = str(data.get("os_version") or "Windows 11 (64-bit)").strip()
        installed_ver = str(data.get("installed_version") or "1.0.0").strip()
        channel = str(data.get("channel") or "stable").strip().lower()
        lic_id = str(data.get("license_id") or "XSH-TRIAL").strip()
        lic_status = str(data.get("license_status") or "ACTIVE").strip().upper()
        lic_plan = str(data.get("license_plan") or "TRIAL").strip().upper()
        prot_status = str(data.get("protection_status") or "PROTECTED").strip().upper()
        eng_health = str(data.get("engine_health") or "HEALTHY").strip().upper()
        upd_status = str(data.get("update_status") or "UP_TO_DATE").strip().upper()
        threats_blocked = int(data.get("threats_blocked") or 0)
        now = datetime.now(timezone.utc).isoformat()

        with self._lock, self._get_connection() as conn:
            # Upsert into device_installations
            conn.execute("""
                INSERT INTO device_installations (
                    installation_id, hwid, device_name, user_email, user_name, organization,
                    os_version, installed_version, latest_version, channel, license_id,
                    license_status, license_plan, protection_status, engine_health,
                    threats_blocked, update_status, last_update_check, last_sync, registered_at,
                    status, is_isolated, is_revoked, pending_action
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ONLINE', 0, 0, 'NONE')
                ON CONFLICT(installation_id) DO UPDATE SET
                    hwid=excluded.hwid,
                    device_name=excluded.device_name,
                    user_email=excluded.user_email,
                    user_name=excluded.user_name,
                    organization=excluded.organization,
                    os_version=excluded.os_version,
                    installed_version=excluded.installed_version,
                    channel=excluded.channel,
                    license_id=excluded.license_id,
                    license_status=excluded.license_status,
                    license_plan=excluded.license_plan,
                    protection_status=excluded.protection_status,
                    engine_health=excluded.engine_health,
                    threats_blocked=excluded.threats_blocked,
                    update_status=excluded.update_status,
                    last_sync=excluded.last_sync,
                    status='ONLINE'
            """, (
                inst_id, hwid, device_name, user_email, user_name, org,
                os_ver, installed_ver, CURRENT_STABLE_VERSION, channel, lic_id,
                lic_status, lic_plan, prot_status, eng_health,
                threats_blocked, upd_status, now, now, now
            ))

            # Maintain endpoints table sync for backward compatibility
            conn.execute("""
                INSERT INTO endpoints (hwid, user_email, user_name, organization, os_version, agent_version, status, threats_blocked, last_heartbeat, registered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(hwid) DO UPDATE SET
                    user_email=excluded.user_email,
                    user_name=excluded.user_name,
                    status=excluded.status,
                    threats_blocked=excluded.threats_blocked,
                    last_heartbeat=excluded.last_heartbeat,
                    os_version=excluded.os_version,
                    agent_version=excluded.agent_version
            """, (hwid, user_email, user_name, org, os_ver, installed_ver, prot_status, threats_blocked, now, now))

            # Log registration event
            conn.execute("""
                INSERT INTO device_sync_events (installation_id, event_type, details, timestamp)
                VALUES (?, 'REGISTER_OR_SYNC', ?, ?)
            """, (inst_id, f"Device registered/updated: {device_name} ({os_ver})", now))

            conn.commit()

        logger.info(f"Device registered/synced: {inst_id} ({device_name}, {user_email})")
        return {
            "status": "success",
            "installation_id": inst_id,
            "hwid": hwid,
            "latest_stable_version": CURRENT_STABLE_VERSION,
            "registered_at": now
        }

    def record_heartbeat(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Alias for record_device_heartbeat for backward compatibility and test suites."""
        return self.record_device_heartbeat(data)

    def record_device_heartbeat(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Processes 15-minute periodic device heartbeat and returns command directives."""
        inst_id = str(data.get("installation_id") or "").strip()
        hwid = str(data.get("hwid") or "UNKNOWN_HWID").strip()
        now = datetime.now(timezone.utc).isoformat()

        with self._lock, self._get_connection() as conn:
            cur = conn.cursor()
            # If inst_id given, lookup; otherwise lookup by hwid
            if inst_id:
                cur.execute("SELECT installation_id, is_isolated, is_revoked, pending_action FROM device_installations WHERE installation_id = ?", (inst_id,))
            else:
                cur.execute("SELECT installation_id, is_isolated, is_revoked, pending_action FROM device_installations WHERE hwid = ?", (hwid,))
            row = cur.fetchone()

            if not row:
                # First time seeing device via heartbeat, auto-register
                reg_res = self.register_or_update_device(data)
                inst_id = reg_res["installation_id"]
                is_isolated = 0
                is_revoked = 0
                pending_action = "NONE"
            else:
                inst_id = row["installation_id"]
                is_isolated = row["is_isolated"]
                is_revoked = row["is_revoked"]
                pending_action = row["pending_action"]

                # Update live telemetry
                conn.execute("""
                    UPDATE device_installations SET
                        installed_version = COALESCE(?, installed_version),
                        protection_status = COALESCE(?, protection_status),
                        engine_health = COALESCE(?, engine_health),
                        threats_blocked = COALESCE(?, threats_blocked),
                        update_status = COALESCE(?, update_status),
                        last_sync = ?,
                        status = 'ONLINE'
                    WHERE installation_id = ?
                """, (
                    data.get("installed_version"),
                    data.get("protection_status"),
                    data.get("engine_health"),
                    data.get("threats_blocked"),
                    data.get("update_status"),
                    now,
                    inst_id
                ))

                # Clear pending action after delivering it
                if pending_action != "NONE":
                    conn.execute("UPDATE device_installations SET pending_action = 'NONE' WHERE installation_id = ?", (inst_id,))

                conn.commit()

        # Check latest version for the client's channel
        latest_ver = self.get_latest_release_version(data.get("channel", "stable"))

        return {
            "status": "acknowledged",
            "installation_id": inst_id,
            "latest_available_version": latest_ver,
            "pending_action": pending_action,
            "is_isolated": bool(is_isolated),
            "is_revoked": bool(is_revoked),
            "server_timestamp": now
        }

    def record_update_event(self, data: Dict[str, Any]) -> bool:
        """Records an update event (DOWNLOADING, INSTALLING, SUCCESS, FAILED, ROLLBACK)."""
        inst_id = str(data.get("installation_id") or "UNKNOWN").strip()
        version = str(data.get("version") or "").strip()
        status = str(data.get("status") or "UNKNOWN").strip().upper()
        error_msg = str(data.get("error") or "").strip()
        now = datetime.now(timezone.utc).isoformat()

        with self._lock, self._get_connection() as conn:
            conn.execute("""
                UPDATE device_installations SET
                    update_status = ?,
                    installed_version = CASE WHEN ? = 'SUCCESS' THEN ? ELSE installed_version END,
                    last_sync = ?
                WHERE installation_id = ?
            """, (status, status, version, now, inst_id))

            details = f"Update to {version}: {status}"
            if error_msg:
                details += f" (Error: {error_msg})"

            conn.execute("""
                INSERT INTO device_sync_events (installation_id, event_type, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (inst_id, f"UPDATE_{status}", details, now))
            conn.commit()

        logger.info(f"Update event recorded for {inst_id}: {status} {version}")
        return True

    def list_devices(self, channel: Optional[str] = None,
                     update_status: Optional[str] = None,
                     license_status: Optional[str] = None,
                     online_only: bool = False,
                     search_q: str = "") -> List[Dict[str, Any]]:
        """Returns filtered list of registered devices with relative last_sync calculation."""
        now = datetime.now(timezone.utc)
        with self._lock, self._get_connection() as conn:
            c = conn.cursor()
            query = "SELECT * FROM device_installations WHERE 1=1"
            params = []

            if channel and channel.upper() != "ALL":
                query += " AND LOWER(channel) = LOWER(?)"
                params.append(channel)

            if update_status and update_status.upper() != "ALL":
                query += " AND UPPER(update_status) = UPPER(?)"
                params.append(update_status)

            if license_status and license_status.upper() != "ALL":
                query += " AND UPPER(license_status) = UPPER(?)"
                params.append(license_status)

            if search_q:
                pattern = f"%{search_q.lower()}%"
                query += " AND (LOWER(installation_id) LIKE ? OR LOWER(user_email) LIKE ? OR LOWER(device_name) LIKE ? OR LOWER(hwid) LIKE ?)"
                params.extend([pattern, pattern, pattern, pattern])

            query += " ORDER BY last_sync DESC"
            c.execute(query, params)
            rows = [dict(r) for r in c.fetchall()]

        # Compute dynamic ONLINE status (online if synced within 35 minutes)
        devices = []
        for dev in rows:
            sync_str = dev.get("last_sync")
            is_online = False
            last_sync_relative = "Never"
            if sync_str:
                try:
                    dt = datetime.fromisoformat(sync_str.replace("Z", "+00:00"))
                    diff_seconds = (now - dt).total_seconds()
                    if diff_seconds < 2100:  # 35 min window
                        is_online = True
                    if diff_seconds < 60:
                        last_sync_relative = "Just now"
                    elif diff_seconds < 3600:
                        last_sync_relative = f"{int(diff_seconds / 60)} min ago"
                    elif diff_seconds < 86400:
                        last_sync_relative = f"{int(diff_seconds / 3600)} hr ago"
                    else:
                        last_sync_relative = f"{int(diff_seconds / 86400)} d ago"
                except Exception:
                    pass

            dev["is_online"] = is_online
            dev["status"] = "ONLINE" if is_online else "OFFLINE"
            dev["last_sync_relative"] = last_sync_relative
            devices.append(dev)

        if online_only:
            devices = [d for d in devices if d["is_online"]]

        return devices

    def get_device_detail(self, installation_id: str) -> Optional[Dict[str, Any]]:
        """Returns deep device inspection data including audit history and telemetry."""
        with self._lock, self._get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT * FROM device_installations WHERE installation_id = ?", (installation_id,))
            dev_row = c.fetchone()
            if not dev_row:
                return None
            device = dict(dev_row)

            # Retrieve sync events
            c.execute("SELECT event_type, details, timestamp FROM device_sync_events WHERE installation_id = ? ORDER BY id DESC LIMIT 20", (installation_id,))
            events = [dict(r) for r in c.fetchall()]
            device["sync_events"] = events

            # Retrieve threats
            c.execute("SELECT threat_name, threat_type, file_path, action_taken, timestamp FROM threat_incidents WHERE hwid = ? ORDER BY id DESC LIMIT 10", (device["hwid"],))
            threats = [dict(r) for r in c.fetchall()]
            device["recent_threats"] = threats

        return device

    def set_device_action(self, installation_id: str, action: str) -> bool:
        """Sets a pending remote command (CHECK_UPDATE, DIAGNOSTIC_SYNC, etc.)."""
        with self._lock, self._get_connection() as conn:
            conn.execute("UPDATE device_installations SET pending_action = ? WHERE installation_id = ?", (action, installation_id))
            conn.execute("""
                INSERT INTO device_sync_events (installation_id, event_type, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (installation_id, f"REMOTE_ACTION_{action}", f"Dispatched remote action: {action}", datetime.now(timezone.utc).isoformat()))
            conn.commit()
        return True

    def toggle_device_isolation(self, installation_id: str, isolate: bool) -> bool:
        """Toggles network isolation on device."""
        val = 1 if isolate else 0
        action = "ISOLATE" if isolate else "UNISOLATE"
        with self._lock, self._get_connection() as conn:
            conn.execute("UPDATE device_installations SET is_isolated = ? WHERE installation_id = ?", (val, installation_id))
            conn.execute("""
                INSERT INTO device_sync_events (installation_id, event_type, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (installation_id, f"ACTION_{action}", f"Device network isolation toggled to {val}", datetime.now(timezone.utc).isoformat()))
            conn.commit()
        return True

    def revoke_device(self, installation_id: str, revoke: bool) -> bool:
        """Revokes or re-authorizes endpoint authorization."""
        val = 1 if revoke else 0
        action = "REVOKE_TOKEN" if revoke else "RESTORE_TOKEN"
        with self._lock, self._get_connection() as conn:
            conn.execute("UPDATE device_installations SET is_revoked = ?, pending_action = ? WHERE installation_id = ?", (val, action, installation_id))
            conn.execute("""
                INSERT INTO device_sync_events (installation_id, event_type, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (installation_id, f"ACTION_{action}", f"Device token authorization revoked={val}", datetime.now(timezone.utc).isoformat()))
            conn.commit()
        return True

    # --- Release Management ---
    def get_latest_release_version(self, channel: str = "stable") -> str:
        with self._lock, self._get_connection() as conn:
            c = conn.cursor()
            c.execute("""
                SELECT version FROM software_releases
                WHERE LOWER(channel) = LOWER(?) AND is_paused = 0
                ORDER BY published_at DESC LIMIT 1
            """, (channel,))
            row = c.fetchone()
            if row:
                return row["version"]
        return CURRENT_STABLE_VERSION

    def get_release_management(self) -> Dict[str, Any]:
        """Provides Super Admin release statistics, staged rollouts, and killswitch state."""
        with self._lock, self._get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT * FROM software_releases ORDER BY published_at DESC")
            releases = [dict(r) for r in c.fetchall()]

            # Compute fleet version distribution
            c.execute("SELECT installed_version, COUNT(*) as count FROM device_installations GROUP BY installed_version")
            version_distribution = {r["installed_version"] or "Unknown": r["count"] for r in c.fetchall()}

            c.execute("SELECT COUNT(*) FROM device_installations")
            total_fleet = c.fetchone()[0]

            c.execute("SELECT COUNT(*) FROM device_installations WHERE update_status = 'UP_TO_DATE'")
            up_to_date_count = c.fetchone()[0]

            c.execute("SELECT COUNT(*) FROM device_installations WHERE update_status = 'FAILED'")
            failed_count = c.fetchone()[0]

        return {
            "releases": releases,
            "version_distribution": version_distribution,
            "total_fleet": total_fleet,
            "up_to_date_count": up_to_date_count,
            "failed_count": failed_count,
            "fleet_adoption_percent": round((up_to_date_count / max(1, total_fleet)) * 100, 1),
            "owner": "Future Finger Technologies",
            "jurisdiction": "New Delhi, India"
        }

    def update_release_policy(self, version: str, staged_percent: int, is_paused: bool) -> bool:
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                UPDATE software_releases SET
                    staged_rollout_percent = ?,
                    is_paused = ?
                WHERE version = ?
            """, (staged_percent, 1 if is_paused else 0, version))
            conn.commit()
        logger.info(f"Updated release policy for {version}: staged={staged_percent}%, paused={is_paused}")
        return True

    # --- Fleet & Legal Stats ---
    def record_legal_consent(self, hwid: str, email: str, name: str, jurisdiction: str) -> bool:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                INSERT INTO legal_consents (hwid, user_email, user_name, jurisdiction, timestamp, dispatched_to_owner)
                VALUES (?, ?, ?, ?, ?, 1)
            """, (hwid, email, name, jurisdiction, now))
            conn.commit()
        logger.info(f"Legal consent registered for {email} ({hwid}) under {jurisdiction}. Dispatched to {OWNER_EMAIL}.")
        return True

    def record_threat(self, threat: Dict[str, Any]):
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                INSERT INTO threat_incidents (hwid, threat_name, threat_type, file_path, file_hash, action_taken, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                threat.get("hwid", "UNKNOWN"),
                threat.get("threat_name", "Heuristic.Threat"),
                threat.get("threat_type", "MALWARE"),
                threat.get("file_path", ""),
                threat.get("file_hash", ""),
                threat.get("action_taken", "QUARANTINED"),
                now
            ))
            conn.commit()

    def get_fleet_stats(self) -> Dict[str, Any]:
        """Returns consolidated truth-of-source fleet stats without synthetic mock data."""
        with self._lock, self._get_connection() as conn:
            c = conn.cursor()

            # Prefer device_installations if available, fallback to endpoints
            c.execute("SELECT COUNT(*) FROM device_installations")
            total_devs = c.fetchone()[0]

            if total_devs > 0:
                total_endpoints = total_devs
                c.execute("SELECT COUNT(*) FROM device_installations WHERE protection_status='PROTECTED'")
                active_protected = c.fetchone()[0]
                c.execute("SELECT SUM(threats_blocked) FROM device_installations")
                total_threats = c.fetchone()[0] or 0
                c.execute("SELECT * FROM device_installations ORDER BY last_sync DESC LIMIT 50")
                endpoints_list = [dict(r) for r in c.fetchall()]
            else:
                c.execute("SELECT COUNT(*) FROM endpoints")
                total_endpoints = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM endpoints WHERE status='PROTECTED'")
                active_protected = c.fetchone()[0]
                c.execute("SELECT SUM(threats_blocked) FROM endpoints")
                total_threats = c.fetchone()[0] or 0
                c.execute("SELECT * FROM endpoints ORDER BY last_heartbeat DESC LIMIT 50")
                endpoints_list = [dict(r) for r in c.fetchall()]

            c.execute("SELECT COUNT(DISTINCT user_email) FROM legal_consents")
            unique_consents = c.fetchone()[0]

            c.execute("SELECT * FROM threat_incidents ORDER BY id DESC LIMIT 20")
            recent_threats = [dict(r) for r in c.fetchall()]

        return {
            "total_endpoints": total_endpoints,
            "active_protected": active_protected,
            "total_threats_blocked": total_threats,
            "unique_consents": unique_consents,
            "endpoints": endpoints_list,
            "recent_threats": recent_threats,
            "legal_jurisdiction": "New Delhi, Delhi, India",
            "owner": "Future Finger Technologies",
            "reporting_recipient": OWNER_EMAIL
        }


db = CloudTelemetryDatabase()


class CloudTelemetryRequestHandler(BaseHTTPRequestHandler):
    """HTTP Request Handler for Cloud Gateway & Device Fleet Synchronization."""

    def _send_json(self, data: Any, status: int = 200):
        body = json.dumps(data, indent=2, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Endpoint-HWID, X-Installation-ID")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send_json({"status": "ok"})

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/api/v1/health":
            self._send_json({
                "status": "ONLINE",
                "service": "XSHEILD Cloud Telemetry Hub & Fleet Gateway",
                "publisher": "Future Finger Technologies",
                "jurisdiction": "New Delhi, India",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return

        elif path == "/api/v1/threats/definitions/latest":
            self._send_json({
                "feed_version": "2026.11.05-LIVE",
                "source": "Future Finger Technologies Threat Research Lab (New Delhi)",
                "signatures_count": 1420,
                "latest_hashes": [
                    "44d88612fea8a8f36de82e1278abb02f",
                    "c8a3c6d8924b11e2f7b8c6a0d4e3f1b2c",
                    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
                ],
                "updated_at": datetime.now(timezone.utc).isoformat()
            })
            return

        elif path == "/api/v1/fleet/overview":
            stats = db.get_fleet_stats()
            self._send_json({"status": "success", "fleet": stats})
            return

        # Centralized Device Management
        elif path == "/api/v1/devices/list":
            channel = query.get("channel", [None])[0]
            update_status = query.get("update_status", [None])[0]
            license_status = query.get("license_status", [None])[0]
            online_only = query.get("online_only", ["0"])[0] in ("1", "true", "True")
            search_q = query.get("q", [""])[0]

            devices = db.list_devices(
                channel=channel,
                update_status=update_status,
                license_status=license_status,
                online_only=online_only,
                search_q=search_q
            )
            self._send_json({"status": "success", "count": len(devices), "devices": devices})
            return

        elif path == "/api/v1/devices/detail":
            inst_id = query.get("installation_id", [""])[0]
            if not inst_id:
                self._send_json({"status": "error", "message": "installation_id required"}, 400)
                return
            detail = db.get_device_detail(inst_id)
            if not detail:
                self._send_json({"status": "error", "message": "Device not found"}, 404)
                return
            self._send_json({"status": "success", "device": detail})
            return

        # Software Updates & Release Management
        elif path == "/api/v1/updates/latest":
            channel = query.get("channel", ["stable"])[0]
            latest_v = db.get_latest_release_version(channel)
            self._send_json({
                "status": "success",
                "latest_version": latest_v,
                "channel": channel,
                "download_url": f"https://github.com/futurefinger/XSHEILD/releases/download/v{latest_v}/XSHEILD_Setup.exe",
                "manifest_url": "https://raw.githubusercontent.com/futurefinger/XSHEILD/main/releases/update-manifest.json",
                "published_by": "Future Finger Technologies",
                "checked_at": datetime.now(timezone.utc).isoformat()
            })
            return

        elif path == "/api/v1/releases/status":
            rel_mgmt = db.get_release_management()
            self._send_json({"status": "success", "release_management": rel_mgmt})
            return

        self._send_json({"error": "Endpoint not found"}, 404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        content_length = int(self.headers.get("Content-Length", 0))
        body_bytes = self.rfile.read(content_length) if content_length > 0 else b"{}"
        try:
            payload = json.loads(body_bytes.decode("utf-8"))
        except Exception:
            payload = {}

        # Device Registration
        if path in ("/api/v1/devices/register", "/api/v1/devices/sync"):
            res = db.register_or_update_device(payload)
            self._send_json(res)
            return

        # Device Heartbeat
        elif path in ("/api/v1/devices/heartbeat", "/api/v1/telemetry/heartbeat"):
            res = db.record_device_heartbeat(payload)
            self._send_json(res)
            return

        # Remote Action Dispatch
        elif path == "/api/v1/devices/action":
            inst_id = payload.get("installation_id", "")
            action = payload.get("action", "CHECK_UPDATE")
            if not inst_id:
                self._send_json({"status": "error", "message": "installation_id required"}, 400)
                return
            db.set_device_action(inst_id, action)
            self._send_json({"status": "success", "installation_id": inst_id, "action": action})
            return

        elif path == "/api/v1/devices/isolate":
            inst_id = payload.get("installation_id", "")
            isolate = payload.get("isolate", True)
            if not inst_id:
                self._send_json({"status": "error", "message": "installation_id required"}, 400)
                return
            db.toggle_device_isolation(inst_id, isolate)
            self._send_json({"status": "success", "installation_id": inst_id, "is_isolated": isolate})
            return

        elif path == "/api/v1/devices/revoke":
            inst_id = payload.get("installation_id", "")
            revoke = payload.get("revoke", True)
            if not inst_id:
                self._send_json({"status": "error", "message": "installation_id required"}, 400)
                return
            db.revoke_device(inst_id, revoke)
            self._send_json({"status": "success", "installation_id": inst_id, "is_revoked": revoke})
            return

        # Update Progress & Telemetry Reporting
        elif path == "/api/v1/updates/report":
            db.record_update_event(payload)
            self._send_json({"status": "recorded", "installation_id": payload.get("installation_id")})
            return

        elif path == "/api/v1/releases/configure":
            version = payload.get("version", CURRENT_STABLE_VERSION)
            staged = int(payload.get("staged_rollout_percent", 100))
            is_paused = bool(payload.get("is_paused", False))
            db.update_release_policy(version, staged, is_paused)
            self._send_json({"status": "success", "version": version, "staged": staged, "is_paused": is_paused})
            return

        elif path == "/api/v1/telemetry/consent":
            hwid = payload.get("hwid", "UNKNOWN")
            email = payload.get("email", "").strip().lower()
            name = payload.get("name", "User")
            jur = payload.get("jurisdiction", "New Delhi, Delhi, India")

            if email:
                db.record_legal_consent(hwid, email, name, jur)
                self._send_json({
                    "status": "success",
                    "message": f"Legal consent recorded for {email}. Exclusive jurisdiction: New Delhi, India.",
                    "dispatched_to": OWNER_EMAIL
                })
            else:
                self._send_json({"status": "error", "message": "Valid user email required."}, 400)
            return

        elif path == "/api/v1/telemetry/threat":
            db.record_threat(payload)
            self._send_json({"status": "recorded", "threat": payload.get("threat_name")})
            return

        elif path == "/api/v1/sandbox/submit":
            f_hash = payload.get("hash", "")
            f_name = payload.get("name", "suspicious_binary.exe")
            threat_score = 0
            verdict = "BENIGN"
            if payload.get("entropy", 0.0) > 7.2 or payload.get("suspicious_api_count", 0) > 3:
                threat_score = 85
                verdict = "MALICIOUS"
            elif payload.get("suspicious_api_count", 0) > 0:
                threat_score = 45
                verdict = "SUSPICIOUS"

            sub_id = hashlib.sha256(f"{f_hash}_{time.time()}".encode()).hexdigest()[:16]
            self._send_json({
                "submission_id": sub_id,
                "file_hash": f_hash,
                "file_name": f_name,
                "threat_score": threat_score,
                "verdict": verdict,
                "mitre_tactics": ["T1055: Process Injection", "T1486: Ransomware"] if verdict == "MALICIOUS" else [],
                "analysis_engine": "Future Finger Technologies Cloud Detonation Sandbox (New Delhi)"
            })
            return

        self._send_json({"error": "Unknown POST route"}, 404)


def run_cloud_server(port: int = 8300):
    server_address = ("0.0.0.0", port)
    httpd = HTTPServer(server_address, CloudTelemetryRequestHandler)
    logger.info(f"XSHEILD Cloud Telemetry Hub & Fleet Gateway listening on port {port}...")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("Cloud Hub stopped.")


if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 else 8300
    run_cloud_server(p)

