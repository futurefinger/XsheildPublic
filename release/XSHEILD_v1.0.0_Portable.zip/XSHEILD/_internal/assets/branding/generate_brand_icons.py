"""
XSHEILD Master Logo & Multi-Resolution Windows Icon Generator
Publisher: Future Finger Technologies (New Delhi, India)
Generates:
1. Ultra-high-resolution 1024x1024 3D Celestial Shield Master Logo with Golden/Cyan Bevel.
2. Windows Multi-Resolution ICO (256, 128, 64, 48, 32, 16) for Application and Installer.
3. Setup Wizard Header Branding Banner and Logo PNGs.
"""

import os
import math
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


def create_celestial_shield_logo(size: int = 1024) -> Image.Image:
    """Creates a high-resolution, futuristic celestial shield emblem."""
    # Create RGBA canvas
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    cx = size // 2
    cy = int(size * 0.48)
    scale = size / 512.0

    # 1. Outer Ambient Cyan & Violet Glow Layer
    glow_img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow_img)

    for r in range(int(220 * scale), int(80 * scale), -int(15 * scale)):
        alpha = int(45 * (1.0 - (r / (220 * scale))))
        glow_draw.ellipse(
            [cx - r, cy - r, cx + r, cy + r],
            fill=(0, 240, 255, alpha)
        )
    # Golden inner pulse
    for r in range(int(140 * scale), int(40 * scale), -int(10 * scale)):
        alpha = int(35 * (1.0 - (r / (140 * scale))))
        glow_draw.ellipse(
            [cx - r, cy - r, cx + r, cy + r],
            fill=(245, 158, 11, alpha)
        )

    glow_img = glow_img.filter(ImageFilter.GaussianBlur(radius=int(25 * scale)))
    img = Image.alpha_composite(img, glow_img)
    draw = ImageDraw.Draw(img)

    # Helper for polygon coordinates
    def s(x, y):
        return (int(x * scale), int(y * scale))

    # 2. Outer Shield Crest Coordinates
    # Center-top notch, top wings, mid flank, lower taper, bottom point
    shield_pts = [
        s(256, 45),   # Top center notch
        s(380, 55),   # Top right outer
        s(450, 110),  # Upper right flank
        s(440, 270),  # Mid right flank
        s(380, 370),  # Lower right taper
        s(256, 475),  # Bottom center spike
        s(132, 370),  # Lower left taper
        s(72, 270),   # Mid left flank
        s(62, 110),   # Upper left flank
        s(132, 55),   # Top left outer
    ]

    # Outer Dark Titanium Frame with Gold / Cyan Edge
    draw.polygon(shield_pts, fill=(11, 21, 40, 255), outline=(0, 240, 255, 255), width=max(2, int(6 * scale)))

    # Outer Golden Bevel Accent
    gold_pts = [
        s(256, 55),
        s(370, 64),
        s(436, 115),
        s(426, 265),
        s(370, 360),
        s(256, 460),
        s(142, 360),
        s(86, 265),
        s(76, 115),
        s(142, 64),
    ]
    draw.polygon(gold_pts, fill=(7, 14, 28, 255), outline=(245, 158, 11, 230), width=max(2, int(4 * scale)))

    # 3. Inner Split Facets (Left = Electric Cyan, Right = Deep Royal Violet/Navy)
    left_facet = [
        s(256, 62),
        s(146, 70),
        s(85, 120),
        s(95, 260),
        s(146, 350),
        s(256, 450),
    ]
    draw.polygon(left_facet, fill=(10, 35, 55, 255))

    right_facet = [
        s(256, 62),
        s(366, 70),
        s(427, 120),
        s(417, 260),
        s(366, 350),
        s(256, 450),
    ]
    draw.polygon(right_facet, fill=(14, 25, 48, 255))

    # 4. Central Futuristic Titanium "X" Emblem
    # Arm 1: Top-Left to Bottom-Right
    x_arm1 = [
        s(155, 145), s(195, 145),
        s(355, 365), s(315, 365)
    ]
    draw.polygon(x_arm1, fill=(240, 246, 252, 255))

    # Arm 2: Top-Right to Bottom-Left
    x_arm2 = [
        s(355, 145), s(315, 145),
        s(155, 365), s(195, 365)
    ]
    draw.polygon(x_arm2, fill=(203, 213, 225, 255))

    # Center Energy Core Gem (Cyan Neon Diamond)
    core_pts = [
        s(256, 230), # Top
        s(285, 255), # Right
        s(256, 280), # Bottom
        s(227, 255), # Left
    ]
    draw.polygon(core_pts, fill=(0, 240, 255, 255), outline=(255, 255, 255, 255), width=max(1, int(3 * scale)))

    # Golden central accent ring
    draw.ellipse(
        [s(246, 245)[0], s(246, 245)[1], s(266, 265)[0], s(266, 265)[1]],
        fill=(255, 255, 255, 255)
    )

    # 5. Fine Cyan Circuit Lines on Wings
    circuit_color = (0, 240, 255, 180)
    w = max(1, int(2.5 * scale))
    draw.line([s(140, 110), s(190, 150), s(190, 200)], fill=circuit_color, width=w)
    draw.line([s(372, 110), s(322, 150), s(322, 200)], fill=circuit_color, width=w)
    draw.line([s(160, 310), s(210, 350)], fill=circuit_color, width=w)
    draw.line([s(352, 310), s(302, 350)], fill=circuit_color, width=w)

    return img


def export_branding_suite():
    """Generates all resolutions and multi-size Windows .ico files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print("[BRANDING] Generating 1024x1024 Master Celestial Shield Logo...")
    master = create_celestial_shield_logo(1024)

    # Save Master PNG
    master_png = os.path.join(OUTPUT_DIR, "xsheild_master_logo.png")
    master.save(master_png, "PNG", optimize=True)
    print(f"[BRANDING] Saved master logo: {master_png}")

    # Standard PNG icons
    sizes = [512, 256, 128, 64, 48, 32, 16]
    for sz in sizes:
        resized = master.resize((sz, sz), Image.Resampling.LANCZOS)
        out_path = os.path.join(OUTPUT_DIR, f"xsheild_{sz}x{sz}.png")
        resized.save(out_path, "PNG", optimize=True)

    # Generate Windows Multi-Resolution ICO files
    ico_sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)]

    xsheild_ico_path = os.path.join(OUTPUT_DIR, "xsheild.ico")
    master.save(xsheild_ico_path, format="ICO", sizes=ico_sizes)
    print(f"[BRANDING] Generated multi-size application icon: {xsheild_ico_path}")

    installer_ico_path = os.path.join(OUTPUT_DIR, "installer.ico")
    master.save(installer_ico_path, format="ICO", sizes=ico_sizes)
    print(f"[BRANDING] Generated multi-size installer icon: {installer_ico_path}")

    # Create Setup Wizard Header Banner (680 x 85)
    banner = Image.new("RGBA", (680, 85), (11, 21, 40, 255))
    b_draw = ImageDraw.Draw(banner)

    # Right side ambient gradient
    for x in range(350, 680):
        alpha = int(45 * ((x - 350) / 330.0))
        b_draw.line([(x, 0), (x, 85)], fill=(0, 240, 255, alpha))

    # Place small logo on the right side of the header banner
    logo_small = master.resize((70, 70), Image.Resampling.LANCZOS)
    banner.paste(logo_small, (590, 8), logo_small)

    banner_path = os.path.join(OUTPUT_DIR, "installer_banner.png")
    banner.save(banner_path, "PNG", optimize=True)
    print(f"[BRANDING] Saved installer header banner: {banner_path}")


if __name__ == "__main__":
    export_branding_suite()
